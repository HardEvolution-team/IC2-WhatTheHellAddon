package com.ded.icwth.blocks.molecularassembler.based;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.logging.log4j.Level;

/**
 * Рендерер для TileEntity молекулярного сборщика.
 * Отображает выходной предмет в центре блока с эффектом свечения.
 */
@SideOnly(Side.CLIENT)
public class TESRMolecularAssembler extends TileEntitySpecialRenderer<TileEntityMolecularAssembler> {
    
    @Override
    public void render(TileEntityMolecularAssembler te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
        FMLLog.log(Level.INFO, "[MolecularAssembler] Начало рендера TESR на координатах: x=%f, y=%f, z=%f", x, y, z);
        
        // Рендерим основную модель блока
        renderModel(x, y, z);
        
        // Проверяем активность и наличие выходного предмета
        if (!te.isActive() || te.getStackInSlot(1).isEmpty()) {
            FMLLog.log(Level.INFO, "[MolecularAssembler] Блок неактивен или слот пуст, рендерим только модель");
            return;
        }
        
        // Получаем выходной предмет из слота 1
        ItemStack stack = te.getStackInSlot(1);
        FMLLog.log(Level.INFO, "[MolecularAssembler] Рендерим предмет: %s", stack.getDisplayName());
        
        GlStateManager.pushMatrix();
        GlStateManager.translate(x + 0.5, y + 0.5, z + 0.5);
        
        // Вращение предмета
        float angle = (float) ((System.currentTimeMillis() % 3600) / 10.0);
        GlStateManager.rotate(angle, 0, 1, 0);
        
        // Эффект свечения
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        
        // Рендер предмета
        float scale = 0.5f;
        GlStateManager.scale(scale, scale, scale);
        RenderHelper.enableStandardItemLighting();
        Minecraft.getMinecraft().getRenderItem().renderItem(stack, ItemCameraTransforms.TransformType.FIXED);
        RenderHelper.disableStandardItemLighting();
        
        // Возвращаем состояние рендера
        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
        
        FMLLog.log(Level.INFO, "[MolecularAssembler] Завершение рендера TESR");
    }
    
    private void renderModel(double x, double y, double z) {
        FMLLog.log(Level.INFO, "[MolecularAssembler] Рендерим основную модель блока");
        
        GlStateManager.pushMatrix();
        GlStateManager.translate(x + 0.5, y + 0.5, z + 0.5);
        
        // Здесь должен быть код для рендера основной модели блока
        // Можно использовать Minecraft.getMinecraft().getTextureManager().bindTexture() для привязки текстуры
        // и затем отрисовать модель
        
        GlStateManager.popMatrix();
    }
}
