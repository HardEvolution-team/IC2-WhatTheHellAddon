package com.ded.icwth;

import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

/**
 * Общий прокси для клиентской и серверной стороны
 */
public class CommonProxy {
    public void preInit(FMLPreInitializationEvent event) {
        // Общая инициализация для клиента и сервера
    }

    public void init(FMLInitializationEvent event) {
        // Общая инициализация для клиента и сервера
    }

    public void postInit(FMLPostInitializationEvent event) {
        // Общая инициализация для клиента и сервера
    }
}
