package com.ded.icwth;

import com.ded.icwth.blocks.ModBlocks;
import com.ded.icwth.blocks.molecularassembler.based.TESRMolecularAssembler;
import com.ded.icwth.blocks.molecularassembler.based.TileEntityMolecularAssembler;
import com.ded.icwth.items.ModItems;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.apache.logging.log4j.Level;

@Mod.EventBusSubscriber(Side.CLIENT)
public class ClientProxy extends CommonProxy {
    @Override
    public void preInit(FMLPreInitializationEvent event) {
        super.preInit(event);
        FMLLog.log(Level.INFO, "[MolecularAssembler] ClientProxy.preInit вызван");
    }
    
    @Override
    public void init(FMLInitializationEvent event) {
        super.init(event);
        FMLLog.log(Level.INFO, "[MolecularAssembler] ClientProxy.init вызван");
        
        // Регистрируем TESR для MolecularAssembler
        FMLLog.log(Level.INFO, "[MolecularAssembler] Регистрация TESR для TileEntityMolecularAssembler");
        ClientRegistry.bindTileEntitySpecialRenderer(TileEntityMolecularAssembler.class, new TESRMolecularAssembler());
    }
    
    @Override
    public void postInit(FMLPostInitializationEvent event) {
        super.postInit(event);
        FMLLog.log(Level.INFO, "[MolecularAssembler] ClientProxy.postInit вызван");
    }

    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent event) {
        FMLLog.log(Level.INFO, "[MolecularAssembler] Регистрация моделей в ClientProxy");
        ModItems.initModels();
    }

    @SubscribeEvent
    public static void registerRenders() {
        FMLLog.log(Level.INFO, "[MolecularAssembler] Вызов registerRenders в ClientProxy");
        ModBlocks.Render();
    }
}
