package com.ded.icwth.api.multiblock;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Block for the Fluid IO multiblock part.
 */
public class BlockFluidIO extends BlockMultiblockPart {

    public BlockFluidIO() {
        super(Material.IRON);
        // Set appropriate block name, creative tab, etc.
        // this.setRegistryName("fluid_io_port");
        // this.setUnlocalizedName(this.getRegistryName().toString());
        // this.setCreativeTab(YourCreativeTab.INSTANCE);
    }

    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileEntityFluidIO(); // Creates the specific TileEntity
    }

    // Optional: Handle fluid when broken? Usually not necessary as it's in the TE.
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        // Fluid is stored in the TileEntity, which is removed.
        // No special dropping logic needed usually.
        super.breakBlock(worldIn, pos, state); // Calls invalidate and notifies controller
    }
}

