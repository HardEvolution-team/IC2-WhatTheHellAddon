package com.ded.icwth.api.multiblock;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;

import java.util.HashMap;
import java.util.Map;

/**
 * Defines the structure (shape and components) of a specific multiblock type.
 * Uses a map of relative positions to StructurePiece definitions.
 */
public class MultiblockStructureDefinition {
    private final String name; // Unique name for this multiblock type
    private final Map<BlockPos, StructurePiece> structureMap; // Relative positions to structure pieces
    private final BlockPos controllerRelativePos; // Position of the controller relative to the structure origin (min corner)
    private final Vec3i dimensions; // Calculated dimensions (width, height, depth)

    private MultiblockStructureDefinition(String name, Map<BlockPos, StructurePiece> structureMap, BlockPos controllerRelativePos, Vec3i dimensions) {
        this.name = name;
        this.structureMap = structureMap;
        this.controllerRelativePos = controllerRelativePos;
        this.dimensions = dimensions;
    }

    public String getName() {
        return name;
    }

    public Map<BlockPos, StructurePiece> getStructureMap() {
        return structureMap;
    }

    public BlockPos getControllerRelativePos() {
        return controllerRelativePos;
    }

    public Vec3i getDimensions() {
        return dimensions;
    }

    /**
     * Builder class for creating MultiblockStructureDefinition instances.
     */
    public static class Builder {
        private final String name;
        private final Map<BlockPos, StructurePiece> structureMap = new HashMap<>();
        private BlockPos controllerRelativePos = null;

        public Builder(String name) {
            this.name = name;
        }

        /**
         * Adds a structure piece at a relative position.
         * The first piece added defines the origin (0,0,0) implicitly if not set otherwise.
         * @param relativePos Position relative to the structure origin.
         * @param piece The StructurePiece definition.
         * @return this builder
         */
        public Builder addPiece(BlockPos relativePos, StructurePiece piece) {
            if (structureMap.containsKey(relativePos)) {
                throw new IllegalArgumentException("Duplicate position in structure definition: " + relativePos);
            }
            structureMap.put(relativePos, piece);
            return this;
        }

        /**
         * Sets the relative position of the controller block within the structure.
         * This position MUST also have a piece defined via addPiece.
         * @param controllerRelativePos The controller's relative position.
         * @return this builder
         */
        public Builder setControllerRelativePos(BlockPos controllerRelativePos) {
            this.controllerRelativePos = controllerRelativePos;
            return this;
        }

        public MultiblockStructureDefinition build() {
            if (name == null || name.isEmpty()) {
                throw new IllegalStateException("Multiblock structure name cannot be null or empty.");
            }
            if (structureMap.isEmpty()) {
                throw new IllegalStateException("Multiblock structure cannot be empty.");
            }
            if (controllerRelativePos == null) {
                throw new IllegalStateException("Controller relative position must be set.");
            }
            if (!structureMap.containsKey(controllerRelativePos)) {
                throw new IllegalStateException("Controller position " + controllerRelativePos + " must be part of the defined structure pieces.");
            }

            // Calculate dimensions based on min/max relative coordinates
            int minX = 0, minY = 0, minZ = 0;
            int maxX = 0, maxY = 0, maxZ = 0;
            for (BlockPos pos : structureMap.keySet()) {
                minX = Math.min(minX, pos.getX());
                minY = Math.min(minY, pos.getY());
                minZ = Math.min(minZ, pos.getZ());
                maxX = Math.max(maxX, pos.getX());
                maxY = Math.max(maxY, pos.getY());
                maxZ = Math.max(maxZ, pos.getZ());
            }
            // Dimensions are max - min + 1
            Vec3i dimensions = new Vec3i(maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1);

            // Adjust relative positions and controller position to be relative to the min corner (0,0,0)
            Map<BlockPos, StructurePiece> adjustedMap = new HashMap<>();
            BlockPos offset = new BlockPos(-minX, -minY, -minZ);
            for (Map.Entry<BlockPos, StructurePiece> entry : structureMap.entrySet()) {
                adjustedMap.put(entry.getKey().add(offset), entry.getValue());
            }
            BlockPos adjustedControllerPos = controllerRelativePos.add(offset);

            return new MultiblockStructureDefinition(name, adjustedMap, adjustedControllerPos, dimensions);
        }
    }
}

