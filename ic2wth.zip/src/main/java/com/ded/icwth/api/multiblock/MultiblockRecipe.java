package com.ded.icwth.api.multiblock;

import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.FluidStack;

import java.util.List;

/**
 * Represents a recipe that can be processed by a multiblock machine.
 * This is a basic example; can be extended with more complex matching (NBT, oreDict), multiple outputs, etc.
 */
public class MultiblockRecipe {
    private final String recipeId; // Unique ID for the recipe within its machine
    private final List<ItemStack> itemInputs;
    private final List<FluidStack> fluidInputs;
    private final List<ItemStack> itemOutputs;
    private final List<FluidStack> fluidOutputs;
    private final int durationTicks;
    private final int energyPerTick;

    public MultiblockRecipe(String recipeId,
                            List<ItemStack> itemInputs,
                            List<FluidStack> fluidInputs,
                            List<ItemStack> itemOutputs,
                            List<FluidStack> fluidOutputs,
                            int durationTicks,
                            int energyPerTick) {
        this.recipeId = recipeId;
        this.itemInputs = itemInputs;
        this.fluidInputs = fluidInputs;
        this.itemOutputs = itemOutputs;
        this.fluidOutputs = fluidOutputs;
        this.durationTicks = durationTicks;
        this.energyPerTick = energyPerTick;
    }

    public String getRecipeId() {
        return recipeId;
    }

    public List<ItemStack> getItemInputs() {
        return itemInputs;
    }

    public List<FluidStack> getFluidInputs() {
        return fluidInputs;
    }

    public List<ItemStack> getItemOutputs() {
        return itemOutputs;
    }

    public List<FluidStack> getFluidOutputs() {
        return fluidOutputs;
    }

    public int getDurationTicks() {
        return durationTicks;
    }

    public int getEnergyPerTick() {
        return energyPerTick;
    }

    // TODO: Add methods for matching inputs against available resources
    // boolean matches(IItemHandler itemInv, IFluidHandler fluidInv) { ... }
}

