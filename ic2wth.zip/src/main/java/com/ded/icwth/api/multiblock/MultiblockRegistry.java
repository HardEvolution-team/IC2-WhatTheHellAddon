package com.ded.icwth.api.multiblock;

import com.google.common.collect.Maps;
import net.minecraft.item.ItemStack;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;

/**
 * Central registry for multiblock definitions.
 * Populated during mod initialization by scanning for IMultiblockController implementations.
 */
public class MultiblockRegistry {

    private static final Logger LOGGER = LogManager.getLogger("IC2WTH-MultiblockRegistry");
    private static final Map<String, MultiblockDefinition> registry = Maps.newHashMap();

    /**
     * Registers a multiblock definition.
     * Should be called during mod initialization (e.g., preInit or relevant registry events).
     *
     * @param definition The MultiblockDefinition to register.
     */
    public static void registerMultiblock(@Nonnull MultiblockDefinition definition) {
        if (registry.containsKey(definition.getUniqueId())) {
            LOGGER.warn("Duplicate multiblock registration attempt for ID: {}. Overwriting.", definition.getUniqueId());
        }
        registry.put(definition.getUniqueId(), definition);
        LOGGER.debug("Registered multiblock: {}", definition.getUniqueId());
    }

    /**
     * Retrieves a multiblock definition by its unique ID.
     *
     * @param uniqueId The unique identifier of the multiblock.
     * @return The MultiblockDefinition, or null if not found.
     */
    @Nullable
    public static MultiblockDefinition getDefinitionById(@Nonnull String uniqueId) {
        return registry.get(uniqueId);
    }

    /**
     * Retrieves a multiblock definition associated with a specific controller ItemStack.
     * This iterates through the registry, so it might be less performant than getDefinitionById.
     * It compares Item and meta/damage value.
     *
     * @param controllerStack The ItemStack representing the controller.
     * @return The MultiblockDefinition, or null if not found.
     */
    @Nullable
    public static MultiblockDefinition getDefinitionByController(@Nonnull ItemStack controllerStack) {
        if (controllerStack.isEmpty()) {
            return null;
        }
        for (MultiblockDefinition definition : registry.values()) {
            ItemStack defController = definition.getControllerStack();
            if (!defController.isEmpty() &&
                defController.getItem() == controllerStack.getItem() &&
                defController.getMetadata() == controllerStack.getMetadata()) {
                // Basic check, could be enhanced to check NBT if necessary
                return definition;
            }
        }
        return null;
    }

    /**
     * Gets an unmodifiable view of all registered multiblock definitions.
     *
     * @return An unmodifiable collection of MultiblockDefinition.
     */
    @Nonnull
    public static Collection<MultiblockDefinition> getAllDefinitions() {
        return Collections.unmodifiableCollection(registry.values());
    }

    // Prevent instantiation
    private MultiblockRegistry() {}
}

