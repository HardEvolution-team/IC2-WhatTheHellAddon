package com.ded.icwth.api.multiblock;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.function.Predicate;

/**
 * Represents a single piece (block) within a multiblock structure definition.
 * Used to define what block should be at a specific relative position.
 */
public class StructurePiece {
    private final Predicate<IBlockState> stateMatcher;
    private final Predicate<IMultiblockPart> tileMatcher; // Optional: for matching specific TileEntity types
    private final IBlockState jeiRenderState; // State to use for JEI rendering

    public StructurePiece(Predicate<IBlockState> stateMatcher, @Nullable Predicate<IMultiblockPart> tileMatcher, IBlockState jeiRenderState) {
        this.stateMatcher = stateMatcher;
        this.tileMatcher = tileMatcher;
        this.jeiRenderState = jeiRenderState;
    }

    public StructurePiece(Predicate<IBlockState> stateMatcher, IBlockState jeiRenderState) {
        this(stateMatcher, null, jeiRenderState);
    }

    /**
     * Gets the block state to be used for rendering this piece in JEI.
     * @return The representative IBlockState for JEI.
     */
    public IBlockState getJEIRenderState() {
        return jeiRenderState;
    }

    /**
     * Checks if the given block state matches the definition for this piece.
     * @param state The block state to check.
     * @return true if it matches, false otherwise.
     */
    public boolean matchesState(IBlockState state) {
        return stateMatcher.test(state);
    }

    /**
     * Checks if the given TileEntity (if present) matches the definition for this piece.
     * @param part The IMultiblockPart TileEntity to check.
     * @return true if it matches or if no tile matcher is defined, false otherwise.
     */
    public boolean matchesTile(@Nullable IMultiblockPart part) {
        if (tileMatcher == null) {
            return true; // No specific tile required
        }
        return part != null && tileMatcher.test(part);
    }

    /**
     * Checks if the block at the given position in the world matches this structure piece definition.
     * @param world The world.
     * @param pos The absolute position of the block.
     * @return true if the block state and (optionally) the tile entity match.
     */
    public boolean matchesWorld(World world, BlockPos pos) {
        IBlockState state = world.getBlockState(pos);
        if (!matchesState(state)) {
            return false;
        }
        if (tileMatcher != null) {
            net.minecraft.tileentity.TileEntity te = world.getTileEntity(pos);
            if (!(te instanceof IMultiblockPart)) {
                return false;
            }
            return matchesTile((IMultiblockPart) te);
        }
        return true;
    }
}

