package com.ded.icwth.api.multiblock;

import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Base class for multiblock controller blocks.
 */
public abstract class BlockMultiblockController extends BlockContainer {

    protected BlockMultiblockController(Material materialIn) {
        super(materialIn);
        this.setHardness(5.0F);
        this.setResistance(10.0F);
        // Controllers might have different properties than parts
    }

    @Override
    public EnumBlockRenderType getRenderType(IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }

    // Notify Controller about neighbor changes
    @Override
    public void neighborChanged(IBlockState state, World worldIn, BlockPos pos, net.minecraft.block.Block blockIn, BlockPos fromPos) {
        super.neighborChanged(state, worldIn, pos, blockIn, fromPos);
        if (!worldIn.isRemote) {
            TileEntity te = worldIn.getTileEntity(pos);
            // Check if it's an AbstractMultiblockController
            if (te instanceof AbstractMultiblockController) {
                AbstractMultiblockController controller = (AbstractMultiblockController) te;
                // Notify the controller to check its structure
                controller.markForStructureCheck();
            }
        }
    }

    // Controller breaking should trigger deform
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        // TileEntity invalidation handles notifying parts and cleanup
        super.breakBlock(worldIn, pos, state);
    }

    // Abstract method to create the associated TileEntity
    @Nullable
    @Override
    public abstract TileEntity createNewTileEntity(World worldIn, int meta);
}

