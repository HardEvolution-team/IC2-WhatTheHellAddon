package com.ded.icwth.api.multiblock;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Basic implementation of IMultiblockPart for common TileEntities within a multiblock.
 * Implements ITickable to allow subclasses to have an update loop.
 */
public abstract class TileEntityMultiblockPart extends TileEntity implements IMultiblockPart, ITickable {

    protected AbstractMultiblockController controller = null;
    protected boolean isConnectedToController = false;

    // --- ITickable ---
    /**
     * Basic update method. Subclasses can override this for their own logic.
     * Remember to call super.update() if you override it, although the base implementation is empty.
     */
    @Override
    public void update() {
        // Base implementation is empty, subclasses add their logic here.
    }

    // --- IMultiblockPart ---

    @Override
    public AbstractMultiblockController getController() {
        return controller;
    }

    @Override
    public void setController(AbstractMultiblockController controller) {
        this.controller = controller;
        this.isConnectedToController = (controller != null);
    }

    @Override
    public void onStructureFormed(AbstractMultiblockController controller) {
        // Default implementation: Mark block for render update if needed
        if (world != null && world.isRemote) {
            world.markBlockRangeForRenderUpdate(pos, pos);
        }
    }

    @Override
    public void onStructureBroken() {
        // Default implementation: Mark block for render update if needed
        if (world != null && world.isRemote) {
            world.markBlockRangeForRenderUpdate(pos, pos);
        }
    }

    @Override
    public World getPartWorld() {
        return getWorld();
    }

    @Override
    public BlockPos getPartPos() {
        return getPos();
    }

    @Override
    public boolean isConnected() {
        return isConnectedToController && controller != null && !controller.isInvalid() && controller.isAssembled();
    }

    // --- Default NBT Handling (Controller link is managed by controller) ---
    // Parts generally don't need to save controller reference, it's rebuilt on load/check

    @Override
    public NBTTagCompound getUpdateTag() {
        // Include basic info if needed for client
        return writeToNBT(new NBTTagCompound());
    }

    @Nullable
    @Override
    public SPacketUpdateTileEntity getUpdatePacket() {
        // Only send update if needed (e.g., state change)
        NBTTagCompound nbt = new NBTTagCompound();
        // Add relevant sync data here if the part has visual state
        writeSyncableNBT(nbt);
        if (nbt.isEmpty()) {
            return null;
        }
        return new SPacketUpdateTileEntity(pos, 0, nbt);
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readSyncableNBT(pkt.getNbtCompound());
        // Trigger client updates if needed
    }

    /**
     * Write data needed only for client synchronization (e.g., visual state).
     * Called by getUpdatePacket.
     * @param nbt NBT compound to write to.
     */
    protected void writeSyncableNBT(NBTTagCompound nbt) {
        // Override in subclasses if visual state needs syncing
    }

    /**
     * Read data needed only for client synchronization.
     * Called by onDataPacket.
     * @param nbt NBT compound to read from.
     */
    protected void readSyncableNBT(NBTTagCompound nbt) {
        // Override in subclasses if visual state needs syncing
    }

    // --- Lifecycle Callbacks (Called by Controller) ---

    @Override
    public void onMachineAssembled(AbstractMultiblockController controller) {
        // Override in subclasses to perform actions when the machine is first assembled
    }

    @Override
    public void onMachineLoaded(AbstractMultiblockController controller) {
        // Override in subclasses to perform actions when the machine is loaded from NBT
        this.controller = controller; // Re-establish link on load
        this.isConnectedToController = true;
    }

    @Override
    public void onMachineBroken() {
        // Override in subclasses to perform actions when the machine breaks
        this.controller = null;
        this.isConnectedToController = false;
    }

    @Override
    public void onMachinePaused() {
        // Override in subclasses if needed
    }

    @Override
    public void onMachineResumed() {
        // Override in subclasses if needed
    }

    // --- Invalidation Handling ---

    @Override
    public void invalidate() {
        super.invalidate();
        // Notify controller if this part is invalidated while formed
        if (controller != null && isConnectedToController) {
            // Corrected call to the method added in AbstractMultiblockController
            controller.markForStructureCheck(); // Trigger a structure check
        }
        setController(null); // Ensure link is broken
    }

    // Removed onNeighborBlockChange() - This logic belongs in the Block class,
    // which should get the TileEntity and call controller.markForStructureCheck() if needed.

}

