package com.ded.icwth.api.multiblock;

import net.minecraft.item.ItemStack;

/**
 * Interface to be implemented by Tile Entities or potentially Items
 * that act as the controller for a multiblock structure.
 */
public interface IMultiblockController {

    /**
     * Retrieves the definition of the multiblock structure associated with this controller.
     *
     * @return The MultiblockDefinition object containing structure details.
     */
    MultiblockDefinition getMultiblockDefinition();

    /**
     * Gets the ItemStack representing this controller, used for JEI catalyst registration.
     * This might return the block's item form or a specific item if the controller isn't a block.
     *
     * @return ItemStack representing the controller.
     */
    ItemStack getControllerItemStack();

}

