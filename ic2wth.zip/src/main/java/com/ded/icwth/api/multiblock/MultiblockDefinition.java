package com.ded.icwth.api.multiblock;

import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

import javax.annotation.Nonnull;
import java.util.Collections;
import java.util.List;

/**
 * Defines the structure and properties of a multiblock machine.
 * This version uses a constructor accepting all final properties.
 */
public class MultiblockDefinition {

    private final String uniqueId;
    private final ItemStack controllerStack;
    private final List<StructurePart> parts; // Relative to structure min corner
    private final BlockPos controllerOffset; // Controller position relative to the structure's min corner
    private final BlockPos dimensions; // Width, Height, Depth

    /**
     * Creates a new Multiblock Definition.
     * @param uniqueId A unique identifier string for this multiblock type.
     * @param controllerStack The ItemStack representing the controller block (for JEI).
     * @param parts A list of StructurePart objects defining the blocks and their positions relative to the structure's minimum corner.
     * @param controllerOffset The position of the controller block relative to the structure's minimum corner.
     * @param dimensions The overall dimensions (Width, Height, Depth) of the structure.
     */
    public MultiblockDefinition(@Nonnull String uniqueId,
                                @Nonnull ItemStack controllerStack,
                                @Nonnull List<StructurePart> parts,
                                @Nonnull BlockPos controllerOffset,
                                @Nonnull BlockPos dimensions) {
        this.uniqueId = uniqueId;
        this.controllerStack = controllerStack;
        // Ensure the list is immutable to prevent outside modification after creation
        this.parts = Collections.unmodifiableList(parts);
        this.controllerOffset = controllerOffset;
        this.dimensions = dimensions;
    }

    @Nonnull
    public String getUniqueId() {
        return uniqueId;
    }

    @Nonnull
    public ItemStack getControllerStack() {
        return controllerStack;
    }

    /**
     * Gets an unmodifiable list of the structure parts.
     * Each part defines a block state and its position relative to the structure's minimum corner (0,0,0).
     * The controller itself IS included in this list at its relative position.
     * @return Unmodifiable list of StructurePart.
     */
    @Nonnull
    public List<StructurePart> getParts() {
        return parts;
    }

    /**
     * Gets the offset of the controller block relative to the minimum coordinate corner of the structure's bounding box.
     * Useful for centering the structure during rendering.
     * @return BlockPos offset.
     */
    @Nonnull
    public BlockPos getControllerOffset() {
        return controllerOffset;
    }

    /**
     * Gets the overall dimensions (Width, Height, Depth) of the multiblock structure.
     * @return BlockPos representing dimensions (X=width, Y=height, Z=depth).
     */
    @Nonnull
    public BlockPos getDimensions() {
        return dimensions;
    }
}

