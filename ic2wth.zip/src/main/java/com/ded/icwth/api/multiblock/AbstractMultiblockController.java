package com.ded.icwth.api.multiblock;

import ic2.api.energy.tile.IEnergySink;
import ic2.api.energy.tile.IEnergySource;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.util.Constants;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.*;

/**
 * Base class for all multiblock controller TileEntities.
 * Manages the formation, state, and operation of a multiblock structure.
 * Implements IMultiblockController for JEI integration.
 */
public abstract class AbstractMultiblockController extends TileEntity implements ITickable, IMultiblockPart, IMultiblockController {

    private static final Logger LOGGER = LogManager.getLogger("AbstractMultiblockController");

    protected enum AssemblyState { DISASSEMBLED, ASSEMBLED, PAUSED }

    protected AssemblyState assemblyState = AssemblyState.DISASSEMBLED;
    protected MultiblockDefinition currentStructureDefinition = null;
    protected Set<BlockPos> connectedParts = new HashSet<>();
    protected BlockPos minCoord = null; // Relative to controller
    protected BlockPos maxCoord = null; // Relative to controller

    // IO Caches (populated during assembly)
    protected List<TileEntityItemIO> itemIOs = new ArrayList<>();
    protected List<TileEntityFluidIO> fluidIOs = new ArrayList<>();
    protected List<TileEntityEnergyIO> energyIOs = new ArrayList<>();

    protected boolean needsStructureCheck = true; // Changed to protected
    protected int ticksSinceLastCheck = 0; // Changed to protected
    protected static final int STRUCTURE_CHECK_INTERVAL = 20; // Changed to protected

    public AbstractMultiblockController() {
        // NOOP
    }

    // --- Abstract Methods for Subclasses ---

    @Nonnull
    public abstract String getStructureDefinitionId();

    protected abstract boolean onAssemble();

    protected abstract void onDisassemble();

    protected abstract void updateServer();

    protected abstract void onMachineStateChanged();

    // --- ITickable ---

    @Override
    public void update() {
        if (world == null || world.isRemote) {
            return;
        }

        ticksSinceLastCheck++;

        if (assemblyState == AssemblyState.DISASSEMBLED) {
            if (needsStructureCheck && ticksSinceLastCheck >= STRUCTURE_CHECK_INTERVAL) {
                checkForStructure();
                ticksSinceLastCheck = 0;
            }
        } else { // ASSEMBLED or PAUSED
            if (needsStructureCheck && ticksSinceLastCheck >= STRUCTURE_CHECK_INTERVAL) {
                checkIfStructureIsValid();
                ticksSinceLastCheck = 0;
            }

            if (assemblyState == AssemblyState.ASSEMBLED) {
                updateServer();
            }
        }
    }

    // --- Structure Management ---

    protected void checkForStructure() {
        if (world == null || world.isRemote) return;
        needsStructureCheck = false;

        MultiblockDefinition definition = getMultiblockDefinition();
        if (definition == null) {
            return;
        }

        boolean structureValid = true;
        Set<BlockPos> potentialParts = new HashSet<>();

        for (StructurePart partDef : definition.getParts()) {
            BlockPos relativePos = partDef.getRelativePos();
            BlockPos worldPos = pos.add(relativePos);

            if (!world.isBlockLoaded(worldPos)) {
                structureValid = false;
                break;
            }

            IBlockState worldState = world.getBlockState(worldPos);
            if (!worldState.equals(partDef.getBlockState())) { // TODO: Add support for block substitutions
                structureValid = false;
                break;
            }

            potentialParts.add(worldPos);
        }

        if (structureValid) {
            potentialParts.add(pos);
            formStructure(definition, potentialParts);
        }
    }

    protected void checkIfStructureIsValid() {
        if (world == null || world.isRemote || currentStructureDefinition == null || assemblyState == AssemblyState.DISASSEMBLED) {
            return;
        }
        needsStructureCheck = false;

        for (BlockPos partPos : connectedParts) {
            if (!world.isBlockLoaded(partPos)) {
                pauseStructure();
                return;
            }

            TileEntity te = world.getTileEntity(partPos);
            if (!(te instanceof IMultiblockPart) || ((IMultiblockPart) te).getController() != this) {
                deformStructure();
                return;
            }
        }

        if (assemblyState == AssemblyState.PAUSED) {
            resumeStructure();
        }
    }

    protected void formStructure(MultiblockDefinition definition, Set<BlockPos> potentialParts) {
        if (assemblyState != AssemblyState.DISASSEMBLED) {
            return;
        }

        this.currentStructureDefinition = definition;
        this.connectedParts.clear();
        this.itemIOs.clear();
        this.fluidIOs.clear();
        this.energyIOs.clear();

        Vec3i dimensions = definition.getDimensions();
        BlockPos controllerOffset = definition.getControllerOffset();
        minCoord = new BlockPos(0, 0, 0).subtract(controllerOffset);
        maxCoord = minCoord.add(dimensions.getX() - 1, dimensions.getY() - 1, dimensions.getZ() - 1);

        Set<IMultiblockPart> partsToNotify = new HashSet<>();

        for (BlockPos partPos : potentialParts) {
            TileEntity te = world.getTileEntity(partPos);
            if (te instanceof IMultiblockPart) {
                IMultiblockPart part = (IMultiblockPart) te;
                if (part.getController() != null && part.getController() != this) {
                    LOGGER.warn("Multiblock formation failed at {}: Part at {} already belongs to another controller.", pos, partPos);
                    deformStructure();
                    return;
                }
                connectedParts.add(partPos);
                partsToNotify.add(part);

                if (part instanceof TileEntityItemIO) itemIOs.add((TileEntityItemIO) part);
                if (part instanceof TileEntityFluidIO) fluidIOs.add((TileEntityFluidIO) part);
                if (part instanceof TileEntityEnergyIO) energyIOs.add((TileEntityEnergyIO) part);

            } else if (partPos.equals(pos)) {
                 partsToNotify.add(this);
            } else {
                LOGGER.error("Error forming multiblock at {}: TileEntity at {} is not IMultiblockPart!", pos, partPos);
                deformStructure();
                return;
            }
        }

        for (IMultiblockPart part : partsToNotify) {
            part.setController(this);
            part.onStructureFormed(this);
            part.onMachineAssembled(this);
        }

        if (onAssemble()) {
            setAssemblyState(AssemblyState.ASSEMBLED);
            markDirtyClient();
            LOGGER.info("Multiblock {} formed successfully at {}.", definition.getUniqueId(), pos);
        } else {
            LOGGER.warn("Multiblock {} onAssemble() returned false at {}. Deforming.", definition.getUniqueId(), pos);
            deformStructure();
        }
    }

    protected void deformStructure() {
        if (assemblyState == AssemblyState.DISASSEMBLED) {
            return;
        }
        LOGGER.info("Deforming multiblock {} at {}.", currentStructureDefinition != null ? currentStructureDefinition.getUniqueId() : "unknown", pos);

        onDisassemble();

        Set<BlockPos> partsToClear = new HashSet<>(connectedParts);
        this.connectedParts.clear();

        for (BlockPos partPos : partsToClear) {
            if (world.isBlockLoaded(partPos)) {
                TileEntity te = world.getTileEntity(partPos);
                if (te instanceof IMultiblockPart) {
                    IMultiblockPart part = (IMultiblockPart) te;
                    if (part.getController() == this) {
                        part.onStructureBroken();
                        part.onMachineBroken();
                        part.setController(null);
                    }
                }
            }
        }

        this.currentStructureDefinition = null;
        this.minCoord = null;
        this.maxCoord = null;
        this.itemIOs.clear();
        this.fluidIOs.clear();
        this.energyIOs.clear();
        setAssemblyState(AssemblyState.DISASSEMBLED);
        markDirtyClient();
    }

    protected void pauseStructure() {
        if (assemblyState != AssemblyState.ASSEMBLED) return;
        LOGGER.info("Pausing multiblock {} at {}.", currentStructureDefinition != null ? currentStructureDefinition.getUniqueId() : "unknown", pos);

        for (BlockPos partPos : connectedParts) {
            if (world.isBlockLoaded(partPos)) {
                TileEntity te = world.getTileEntity(partPos);
                if (te instanceof IMultiblockPart && ((IMultiblockPart) te).getController() == this) {
                    ((IMultiblockPart) te).onMachinePaused();
                }
            }
        }
        setAssemblyState(AssemblyState.PAUSED);
        markDirtyClient();
    }

    protected void resumeStructure() {
        if (assemblyState != AssemblyState.PAUSED) return;
        LOGGER.info("Resuming multiblock {} at {}.", currentStructureDefinition != null ? currentStructureDefinition.getUniqueId() : "unknown", pos);

        for (BlockPos partPos : connectedParts) {
            if (world.isBlockLoaded(partPos)) {
                TileEntity te = world.getTileEntity(partPos);
                if (te instanceof IMultiblockPart && ((IMultiblockPart) te).getController() == this) {
                    ((IMultiblockPart) te).onMachineResumed();
                }
            } else {
                LOGGER.warn("Failed to resume multiblock at {}: Part at {} unloaded. Re-pausing.", pos, partPos);
                pauseStructure();
                return;
            }
        }
        setAssemblyState(AssemblyState.ASSEMBLED);
        markDirtyClient();
    }

    private void setAssemblyState(AssemblyState newState) {
        if (this.assemblyState != newState) {
            AssemblyState oldState = this.assemblyState;
            this.assemblyState = newState;
            onMachineStateChanged();
            LOGGER.debug("Multiblock at {} changed state from {} to {}.", pos, oldState, newState);
        }
    }

    public boolean isAssembled() {
        return assemblyState == AssemblyState.ASSEMBLED || assemblyState == AssemblyState.PAUSED;
    }

    public AssemblyState getAssemblyState() {
        return assemblyState;
    }

    @Nullable
    public MultiblockDefinition getCurrentStructureDefinition() {
        return currentStructureDefinition;
    }

    // --- Handle Part Breaking / Placement ---

    public void notifyPartBroken(IMultiblockPart part) {
        if (isAssembled()) {
            BlockPos partPos = part.getPartPos();
            if (connectedParts.contains(partPos)) {
                LOGGER.debug("Multiblock part broken at {}. Deforming structure at {}.", partPos, pos);
                deformStructure();
            } else {
                 LOGGER.warn("notifyPartBroken called for unknown part {} at controller {}.", partPos, pos);
            }
        } else {
             markForStructureCheck(); // Mark for check if disassembled
        }
    }

    public void notifyPartAdded(IMultiblockPart part) {
        if (!isAssembled()) {
            markForStructureCheck(); // Mark for check if disassembled
        }
    }

    /**
     * Called by the controller's Block class (in its neighborChanged method)
     * to indicate that a neighbor block change occurred that might affect the structure.
     */
    public void markForStructureCheck() {
        if (world != null && !world.isRemote) {
            this.needsStructureCheck = true;
            // Optional: Force check sooner than interval
            // this.ticksSinceLastCheck = Math.max(this.ticksSinceLastCheck, STRUCTURE_CHECK_INTERVAL - 1);
        }
    }

    // --- IMultiblockPart Implementation (for Controller) ---

    @Override
    public AbstractMultiblockController getController() {
        return this;
    }

    @Override
    public void setController(AbstractMultiblockController controller) {
        if (controller != this && controller != null) {
            LOGGER.warn("Attempted to set a controller ({}) on the controller itself ({})!", controller.getPos(), pos);
        }
    }

    @Override
    public void onStructureFormed(AbstractMultiblockController controller) { }

    @Override
    public void onStructureBroken() { }

    @Override
    public World getPartWorld() {
        return getWorld();
    }

    @Override
    public BlockPos getPartPos() {
        return getPos();
    }

    @Override
    public boolean isConnected() {
        return isAssembled();
    }

    @Override
    public void onMachineAssembled(AbstractMultiblockController controller) { }

    @Override
    public void onMachineLoaded(AbstractMultiblockController controller) { }

    @Override
    public void onMachineBroken() { }

    @Override
    public void onMachinePaused() { }

    @Override
    public void onMachineResumed() { }

    // --- IMultiblockController Implementation (for JEI) ---

    @Override
    @Nullable
    public MultiblockDefinition getMultiblockDefinition() {
        MultiblockDefinition def = MultiblockRegistry.getDefinitionById(getStructureDefinitionId());
        if (def == null) {
             LOGGER.error("JEI Integration Error: Multiblock definition not found in registry for ID: {}", getStructureDefinitionId());
        }
        return def;
    }

    @Nonnull
    @Override
    public ItemStack getControllerItemStack() {
        Block block = getBlockType();
        if (block != null) {
            return new ItemStack(block, 1, getBlockMetadata());
        }
        return ItemStack.EMPTY;
    }

    // --- NBT & Syncing ---

    protected void markDirtyClient() {
        markDirty();
        if (world != null && !world.isRemote) {
            IBlockState state = world.getBlockState(pos);
            world.notifyBlockUpdate(pos, state, state, Constants.BlockFlags.DEFAULT_AND_RERENDER);
        }
    }

    @Override
    public NBTTagCompound getUpdateTag() {
        NBTTagCompound nbt = super.getUpdateTag();
        writeSyncableNBT(nbt);
        return nbt;
    }

    @Nullable
    @Override
    public SPacketUpdateTileEntity getUpdatePacket() {
        NBTTagCompound nbt = new NBTTagCompound();
        writeSyncableNBT(nbt);
        return new SPacketUpdateTileEntity(pos, 0, nbt);
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readSyncableNBT(pkt.getNbtCompound());
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        super.handleUpdateTag(tag);
        readSyncableNBT(tag);
    }

    protected void writeSyncableNBT(NBTTagCompound nbt) {
        nbt.setInteger("assemblyState", assemblyState.ordinal());
        if (currentStructureDefinition != null) {
            nbt.setString("structureId", currentStructureDefinition.getUniqueId());
        }
    }

    protected void readSyncableNBT(NBTTagCompound nbt) {
        AssemblyState prevState = this.assemblyState;
        int stateOrdinal = nbt.getInteger("assemblyState");
        if (stateOrdinal >= 0 && stateOrdinal < AssemblyState.values().length) {
            this.assemblyState = AssemblyState.values()[stateOrdinal];
        } else {
            this.assemblyState = AssemblyState.DISASSEMBLED;
        }

        if (nbt.hasKey("structureId", Constants.NBT.TAG_STRING)) {
            String structureId = nbt.getString("structureId");
            this.currentStructureDefinition = MultiblockRegistry.getDefinitionById(structureId);
        } else {
            this.currentStructureDefinition = null;
        }

        if (prevState != this.assemblyState && world != null && world.isRemote) {
            world.markBlockRangeForRenderUpdate(pos, pos);
        }
    }

    @Override
    public void readFromNBT(NBTTagCompound nbt) {
        super.readFromNBT(nbt);
        readSyncableNBT(nbt);

        connectedParts.clear();
        if (nbt.hasKey("connectedParts", Constants.NBT.TAG_LIST)) {
            NBTTagList partsList = nbt.getTagList("connectedParts", Constants.NBT.TAG_COMPOUND);
            for (int i = 0; i < partsList.tagCount(); i++) {
                connectedParts.add(NBTUtil.getPosFromTag(partsList.getCompoundTagAt(i)));
            }
        }

        if (assemblyState != AssemblyState.DISASSEMBLED) {
            needsStructureCheck = true;
            ticksSinceLastCheck = 0;
        }
    }

    @Nonnull
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound nbt) {
        super.writeToNBT(nbt);
        writeSyncableNBT(nbt);

        NBTTagList partsList = new NBTTagList();
        for (BlockPos partPos : connectedParts) {
            partsList.appendTag(NBTUtil.createPosTag(partPos));
        }
        nbt.setTag("connectedParts", partsList);

        return nbt;
    }

    // --- Capability Handling ---

    @Override
    public boolean hasCapability(@Nonnull Capability<?> capability, @Nullable EnumFacing facing) {
        if (isAssembled()) {
            // Delegate to specific implementations or cached handlers
        }
        return super.hasCapability(capability, facing);
    }

    @Nullable
    @Override
    public <T> T getCapability(@Nonnull Capability<T> capability, @Nullable EnumFacing facing) {
        if (isAssembled()) {
            // Delegate to specific implementations or cached handlers
        }
        return super.getCapability(capability, facing);
    }

    // --- World Loading/Unloading & Block Updates ---

    @Override
    public void onLoad() {
        super.onLoad();
        if (world != null && !world.isRemote) {
            if (isAssembled()) {
                needsStructureCheck = true;
                ticksSinceLastCheck = 0;
                for (BlockPos partPos : connectedParts) {
                    if (world.isBlockLoaded(partPos)) {
                        TileEntity te = world.getTileEntity(partPos);
                        if (te instanceof IMultiblockPart && ((IMultiblockPart) te).getController() == this) {
                            ((IMultiblockPart) te).onMachineLoaded(this);
                        }
                    }
                }
            } else {
                needsStructureCheck = true;
                ticksSinceLastCheck = STRUCTURE_CHECK_INTERVAL -1;
            }
        }
    }

    @Override
    public void invalidate() {
        super.invalidate();
        if (world != null && !world.isRemote) {
            deformStructure();
        }
    }

    @Override
    public void onChunkUnload() {
        super.onChunkUnload();
        // No deformStructure here, allow saving assembled state
    }

    @Override
    public boolean shouldRefresh(World world, BlockPos pos, @Nonnull IBlockState oldState, @Nonnull IBlockState newState) {
        // Prevent TE invalidation when only block state changes (e.g., active/inactive)
        return oldState.getBlock() != newState.getBlock();
    }

    // Removed incorrect neighborChanged override
    // Removed isPosRelevant method

    @Nonnull
    @Override
    public AxisAlignedBB getRenderBoundingBox() {
        if (isAssembled() && minCoord != null && maxCoord != null) {
            // Expand bounds slightly to ensure rendering even if controller is at edge
            return new AxisAlignedBB(pos.add(minCoord).add(-1, -1, -1), pos.add(maxCoord).add(2, 2, 2));
        } else {
            return super.getRenderBoundingBox();
        }
    }
}

