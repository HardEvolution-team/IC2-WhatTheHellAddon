package com.ded.icwth.api.multiblock;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fluids.FluidTank;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler; // Import specific interface

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * A basic multiblock part TileEntity that provides a fluid handler capability.
 */
public class TileEntityFluidIO extends TileEntityMultiblockPart {

    // Example: Simple 16000mB tank
    protected FluidTank tank = createFluidTank();

    /**
     * Override this to change the size or behavior of the internal tank.
     * @return A new FluidTank instance.
     */
    protected FluidTank createFluidTank() {
        return new FluidTank(16000) {
            @Override
            protected void onContentsChanged() {
                // Mark the TE as dirty when the tank changes
                TileEntityFluidIO.this.markDirty();
                // Optional: Notify controller if needed
                // if (getController() != null) {
                //     getController().onInputChanged();
                // }
            }
        };
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        if (compound.hasKey("Tank")) {
            tank.readFromNBT(compound.getCompoundTag("Tank"));
        }
    }

    @Nonnull
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        NBTTagCompound tankNbt = new NBTTagCompound();
        tank.writeToNBT(tankNbt);
        compound.setTag("Tank", tankNbt);
        return compound;
    }

    @Override
    public boolean hasCapability(@Nonnull Capability<?> capability, @Nullable EnumFacing facing) {
        // Expose fluid handler capability on all sides when connected, or allow configuration
        if (capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY && isConnected()) {
            return true;
        }
        return super.hasCapability(capability, facing);
    }

    @Nullable
    @Override
    public <T> T getCapability(@Nonnull Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY && isConnected()) {
            // Return the internal tank handler, explicitly cast to the interface type expected by the capability
            // Although Capability.cast should handle this, this makes it clearer.
            return (T) tank; // Cast to T, compiler knows T must be IFluidHandler here
        }
        return super.getCapability(capability, facing);
    }

    // --- Multiblock Lifecycle --- 

    @Override
    public void onMachineBroken() {
        super.onMachineBroken();
        // Optional: Handle fluid when the multiblock breaks?
    }
}

