package com.ded.icwth.api.multiblock;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;

import javax.annotation.Nonnull;

/**
 * Represents a single block part within a multiblock structure definition.
 */
public class StructurePart {
    private final BlockPos relativePos;
    private final IBlockState blockState;
    // Could add optional fields for substitutions, etc.

    public StructurePart(@Nonnull BlockPos relativePos, @Nonnull IBlockState blockState) {
        this.relativePos = relativePos;
        this.blockState = blockState;
    }

    @Nonnull
    public BlockPos getRelativePos() {
        return relativePos;
    }

    @Nonnull
    public IBlockState getBlockState() {
        return blockState;
    }

    // Optional: equals and hashCode if used in sets/maps
}

