package com.ded.icwth.api.multiblock;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;

import javax.annotation.Nullable;

/**
 * Block for the Item IO multiblock part.
 */
public class BlockItemIO extends BlockMultiblockPart {

    public BlockItemIO() {
        super(Material.IRON);
        // Set appropriate block name, creative tab, etc.
        // this.setRegistryName("item_io_port");
        // this.setUnlocalizedName(this.getRegistryName().toString());
        // this.setCreativeTab(YourCreativeTab.INSTANCE);
    }

    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileEntityItemIO(); // Creates the specific TileEntity
    }

    // Optional: Drop inventory contents when broken
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        TileEntity te = worldIn.getTileEntity(pos);
        if (te instanceof TileEntityItemIO) {
            IItemHandler itemHandler = te.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
            if (itemHandler != null) {
                for (int i = 0; i < itemHandler.getSlots(); ++i) {
                    net.minecraft.inventory.InventoryHelper.spawnItemStack(worldIn, pos.getX(), pos.getY(), pos.getZ(), itemHandler.getStackInSlot(i));
                }
            }
        }
        super.breakBlock(worldIn, pos, state); // Calls invalidate and notifies controller
    }
}

