package com.ded.icwth.api.multiblock;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Block for the Energy IO (IC2 EU) multiblock part.
 */
public class BlockEnergyIO extends BlockMultiblockPart {

    public BlockEnergyIO() {
        super(Material.IRON);
        // Set appropriate block name, creative tab, etc.
        // this.setRegistryName("energy_io_port");
        // this.setUnlocalizedName(this.getRegistryName().toString());
        // this.setCreativeTab(YourCreativeTab.INSTANCE);
    }

    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileEntityEnergyIO(); // Creates the specific TileEntity
    }

    // Energy is stored in the TileEntity, which is removed.
    // No special dropping logic needed usually.
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        // Ensure energy net cleanup happens
        super.breakBlock(worldIn, pos, state); // Calls invalidate which handles energy net unload
    }
}

