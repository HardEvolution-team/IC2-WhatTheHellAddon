package com.ded.icwth.api.multiblock;

import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;

/**
 * Base class for blocks that are part of a multiblock structure (excluding the controller).
 */
public abstract class BlockMultiblockPart extends BlockContainer {

    protected BlockMultiblockPart(Material materialIn) {
        super(materialIn);
        // Basic properties, potentially set hardness/resistance
        this.setHardness(5.0F);
        this.setResistance(10.0F);
    }

    // Ensure it's a TileEntity container
    @Override
    public EnumBlockRenderType getRenderType(IBlockState state) {
        return EnumBlockRenderType.MODEL;
    }

    // Notify Controller about neighbor changes via the TileEntity
    @Override
    public void neighborChanged(IBlockState state, World worldIn, BlockPos pos, net.minecraft.block.Block blockIn, BlockPos fromPos) {
        super.neighborChanged(state, worldIn, pos, blockIn, fromPos);
        if (!worldIn.isRemote) {
            TileEntity te = worldIn.getTileEntity(pos);
            if (te instanceof IMultiblockPart) {
                IMultiblockPart part = (IMultiblockPart) te;
                AbstractMultiblockController controller = part.getController();
                // If the part is connected to a controller, notify the controller to check structure
                if (controller != null) {
                    // Optional: Add a check here to see if the change at 'fromPos' is relevant
                    // before marking for check, similar to the logic previously in AbstractMultiblockController.
                    // For simplicity, we mark for check on any neighbor change for now.
                    controller.markForStructureCheck();
                }
            }
        }
    }

    // Ensure controller is notified when a part is broken
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        // TileEntity invalidation handles notifying the controller
        super.breakBlock(worldIn, pos, state);
    }

    // Abstract method to create the associated TileEntity
    @Nullable
    @Override
    public abstract TileEntity createNewTileEntity(World worldIn, int meta);
}

