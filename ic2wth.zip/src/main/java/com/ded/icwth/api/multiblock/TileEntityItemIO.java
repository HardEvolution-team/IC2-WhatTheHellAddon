package com.ded.icwth.api.multiblock;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler; // Import specific interface
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * A basic multiblock part TileEntity that provides an item handler capability.
 */
public class TileEntityItemIO extends TileEntityMultiblockPart {

    // Example: Simple 1-slot inventory
    protected ItemStackHandler inventory = createInventoryHandler();

    /**
     * Override this to change the size or behavior of the internal inventory.
     * @return A new ItemStackHandler instance.
     */
    protected ItemStackHandler createInventoryHandler() {
        return new ItemStackHandler(1) {
            @Override
            protected void onContentsChanged(int slot) {
                // Mark the TE as dirty when the inventory changes
                TileEntityItemIO.this.markDirty();
                // Optional: Notify controller if needed
                // if (getController() != null) {
                //     getController().onInputChanged();
                // }
            }
        };
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        if (compound.hasKey("Inventory")) {
            inventory.deserializeNBT(compound.getCompoundTag("Inventory"));
        }
    }

    @Nonnull
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setTag("Inventory", inventory.serializeNBT());
        return compound;
    }

    @Override
    public boolean hasCapability(@Nonnull Capability<?> capability, @Nullable EnumFacing facing) {
        // Expose item handler capability on all sides when connected, or allow configuration
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY && isConnected()) {
            return true;
        }
        return super.hasCapability(capability, facing);
    }

    @Nullable
    @Override
    public <T> T getCapability(@Nonnull Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY && isConnected()) {
            // Return the internal handler, explicitly cast to the interface type expected by the capability
            // Although Capability.cast should handle this, this makes it clearer.
            return (T) inventory; // Cast to T, compiler knows T must be IItemHandler here
        }
        return super.getCapability(capability, facing);
    }

    // --- Multiblock Lifecycle --- 

    @Override
    public void onMachineBroken() {
        super.onMachineBroken();
        // Optional: Drop inventory contents when the multiblock breaks?
        // Or rely on the block break event?
    }
}

