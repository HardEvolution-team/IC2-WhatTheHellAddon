package com.ded.icwth.api.multiblock;

import ic2.api.energy.event.EnergyTileLoadEvent;
import ic2.api.energy.event.EnergyTileUnloadEvent;
import ic2.api.energy.tile.IEnergyAcceptor;
import ic2.api.energy.tile.IEnergyEmitter;
import ic2.api.energy.tile.IEnergySink;
import ic2.api.energy.tile.IEnergySource;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;

import javax.annotation.Nonnull;

/**
 * A basic multiblock part TileEntity that acts as an IC2 Energy Sink and/or Source.
 * Configuration (Sink/Source, Tier) should be handled by subclasses or block state.
 */
public class TileEntityEnergyIO extends TileEntityMultiblockPart implements IEnergySink, IEnergySource {

    protected boolean addedToEnergyNet = false;
    public boolean allowInput = true; // Default: Sink
    public boolean allowOutput = false; // Default: Not a source
    public int sinkTier = 1;
    protected int sourceTier = 1;
    public double energyStored = 0;
    protected double capacity = 10000; // Example capacity

    // --- Energy Net Handling ---

    @Override
    public void onChunkUnload() {
        super.onChunkUnload();
        unloadFromEnergyNet();
    }

    @Override
    public void invalidate() {
        super.invalidate();
        unloadFromEnergyNet();
    }

    @Override
    public void update() {
        super.update(); // Handles controller connection checks etc.
        if (!world.isRemote && !addedToEnergyNet) {
            loadToEnergyNet();
        }
        // Energy distribution logic might be handled by the controller
    }

    protected void loadToEnergyNet() {
        if (!world.isRemote && !addedToEnergyNet) {
            MinecraftForge.EVENT_BUS.post(new EnergyTileLoadEvent(this));
            addedToEnergyNet = true;
        }
    }

    protected void unloadFromEnergyNet() {
        if (!world.isRemote && addedToEnergyNet) {
            MinecraftForge.EVENT_BUS.post(new EnergyTileUnloadEvent(this));
            addedToEnergyNet = false;
        }
    }

    // --- IEnergySink --- 

    @Override
    public boolean acceptsEnergyFrom(IEnergyEmitter emitter, EnumFacing side) {
        // Accept only when connected and configured as input
        return isConnected() && allowInput;
    }

    @Override
    public double getDemandedEnergy() {
        // Demand energy only if connected, configured as input, and has space
        if (!isConnected() || !allowInput) {
            return 0;
        }
        return Math.max(0, capacity - energyStored);
    }

    @Override
    public int getSinkTier() {
        return sinkTier;
    }

    @Override
    public double injectEnergy(EnumFacing directionFrom, double amount, double voltage) {
        if (!isConnected() || !allowInput) {
            return amount; // Cannot accept
        }
        // Check tier
        if (voltage > ic2.api.energy.EnergyNet.instance.getPowerFromTier(this.sinkTier)) {
            // TODO: Handle explosion/overvoltage? For now, just refuse.
            // world.createExplosion(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 0.1f, true);
            return amount;
        }

        double accepted = Math.min(amount, capacity - energyStored);
        energyStored += accepted;
        markDirty(); // Mark dirty when energy level changes
        // Optional: Notify controller
        // if (getController() != null) {
        //     getController().onEnergyInputChanged();
        // }
        return amount - accepted; // Return leftover energy
    }

    // --- IEnergySource --- 

    @Override
    public boolean emitsEnergyTo(IEnergyAcceptor receiver, EnumFacing side) {
        // Emit only when connected and configured as output
        return isConnected() && allowOutput;
    }

    @Override
    public double getOfferedEnergy() {
        // Offer energy only if connected, configured as output, and has energy
        if (!isConnected() || !allowOutput) {
            return 0;
        }
        // Offer up to tier voltage
        return Math.min(energyStored, ic2.api.energy.EnergyNet.instance.getPowerFromTier(this.sourceTier));
    }

    @Override
    public void drawEnergy(double amount) {
        if (!isConnected() || !allowOutput) {
            return;
        }
        energyStored -= amount;
        if (energyStored < 0) energyStored = 0;
        markDirty(); // Mark dirty when energy level changes
        // Optional: Notify controller
        // if (getController() != null) {
        //     getController().onEnergyOutputChanged();
        // }
    }

    @Override
    public int getSourceTier() {
        return sourceTier;
    }

    // --- NBT --- 

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        this.energyStored = compound.getDouble("energyStored");
        // Load config if stored here (allowInput, allowOutput, tiers, capacity)
        // Example:
        // this.allowInput = compound.getBoolean("allowInput");
        // this.allowOutput = compound.getBoolean("allowOutput");
        // this.sinkTier = compound.getInteger("sinkTier");
        // this.sourceTier = compound.getInteger("sourceTier");
        // this.capacity = compound.getDouble("capacity");
    }

    @Nonnull
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setDouble("energyStored", this.energyStored);
        // Save config if stored here
        // compound.setBoolean("allowInput", this.allowInput);
        // compound.setBoolean("allowOutput", this.allowOutput);
        // compound.setInteger("sinkTier", this.sinkTier);
        // compound.setInteger("sourceTier", this.sourceTier);
        // compound.setDouble("capacity", this.capacity);
        return compound;
    }

    // --- Multiblock Lifecycle --- 

    @Override
    public void onMachineLoaded(AbstractMultiblockController controller) {
        super.onMachineLoaded(controller);
        // Ensure energy net registration on load if connected
        if (!addedToEnergyNet) {
            loadToEnergyNet();
        }
    }

    @Override
    public void onMachineBroken() {
        super.onMachineBroken();
        // Keep energy stored, but might want to unload from net if not already handled by invalidate
        unloadFromEnergyNet();
    }
}

