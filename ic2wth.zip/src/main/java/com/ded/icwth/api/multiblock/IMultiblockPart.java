package com.ded.icwth.api.multiblock;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Interface implemented by TileEntities that can be part of a multiblock structure.
 */
public interface IMultiblockPart {

    /**
     * @return The controller TileEntity this part belongs to, or null if not formed.
     */
    AbstractMultiblockController getController();

    /**
     * Sets the controller for this part.
     * @param controller The controller TileEntity.
     */
    void setController(AbstractMultiblockController controller);

    /**
     * Called when the multiblock structure is formed.
     * @param controller The controller TileEntity.
     */
    void onStructureFormed(AbstractMultiblockController controller);

    /**
     * Called when the multiblock structure is broken/deformed.
     */
    void onStructureBroken();

    /**
     * @return The world this part exists in.
     */
    World getPartWorld();

    /**
     * @return The position of this part.
     */
    BlockPos getPartPos();

    /**
     * Checks if this part is connected to a controller.
     * @return true if connected, false otherwise.
     */
    boolean isConnected();

    /**
     * Called by the controller when the multiblock structure is saved.
     * Can be used to save part-specific data related to the multiblock.
     */
    void onMachineAssembled(AbstractMultiblockController controller);

    /**
     * Called by the controller when the multiblock structure is loaded.
     * Can be used to load part-specific data related to the multiblock.
     */
    void onMachineLoaded(AbstractMultiblockController controller);

    /**
     * Called by the controller when the multiblock structure is broken.
     */
    void onMachineBroken();

    /**
     * Called by the controller when the multiblock structure is paused (e.g., chunk unload).
     */
    void onMachinePaused();

    /**
     * Called by the controller when the multiblock structure is resumed (e.g., chunk load).
     */
    void onMachineResumed();
}

