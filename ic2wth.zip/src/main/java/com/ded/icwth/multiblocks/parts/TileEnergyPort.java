package com.ded.icwth.multiblocks.parts;

import com.ded.icwth.api.multiblock.AbstractMultiblockController;
import com.ded.icwth.api.multiblock.IMultiblockPart;
import ic2.api.energy.EnergyNet;
import ic2.api.energy.tile.*;
import ic2.core.ExplosionIC2;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.FMLCommonHandler;

import javax.annotation.Nullable;

public class TileEnergyPort extends TileEntity implements IMultiblockPart, IEnergySink, IEnergySource, ITickable {

    private AbstractMultiblockController controller;
    private BlockPos controllerPos; // Store controller position for re-linking
    private boolean isFormed = false;
    private boolean addedToEnergyNet = false;

    // Configuration (can be set via NBT or block state)
    private EnergyPortMode mode = EnergyPortMode.INPUT; // Default to input
    private int tier = 1; // Example tier

    // Internal buffer (optional, can be removed if direct interaction with controller is preferred)
    private double buffer = 0;
    private double capacity = 10000; // Example buffer capacity

    public enum EnergyPortMode {
        INPUT, OUTPUT
    }

    public TileEnergyPort() {
        // Default constructor for NBT loading
    }

    public TileEnergyPort(EnergyPortMode mode, int tier) {
        this.mode = mode;
        this.tier = tier;
    }

    // Utility method to map IC2 energy tiers to EU/t values
    private double getPowerFromTier(int tier) {
        switch (tier) {
            case 1: return 32.0;   // LV (Low Voltage)
            case 2: return 128.0;  // MV (Medium Voltage)
            case 3: return 512.0;  // HV (High Voltage)
            case 4: return 2048.0; // EV (Extreme Voltage)
            case 5: return 8192.0; // IV (Insane Voltage, optional)
            default: return 0.0;   // Invalid tier
        }
    }

    // --- IMultiblockPart Implementation ---

    @Override
    public void setController(AbstractMultiblockController controller) {
        this.controller = controller;
        this.controllerPos = (controller != null) ? controller.getPos() : null;
        boolean previouslyFormed = this.isFormed;
        this.isFormed = (controller != null);

        if (this.isFormed != previouslyFormed) {
            if (this.isFormed) {
                addToEnergyNet(); // Add to network when formed
            } else {
                removeFromEnergyNet(); // Remove from network when broken
            }
            markDirty();
            if (world != null && !world.isRemote) {
                world.notifyBlockUpdate(pos, world.getBlockState(pos), world.getBlockState(pos), 3); // Sync client
            }
        }
    }

    @Override
    public AbstractMultiblockController getController() {
        if (controller == null && controllerPos != null && world != null && !world.isRemote && world.isBlockLoaded(controllerPos)) {
            TileEntity te = world.getTileEntity(controllerPos);
            if (te instanceof AbstractMultiblockController) {
                AbstractMultiblockController loadedController = (AbstractMultiblockController) te;
                if (loadedController.isAssembled()) { // Check if the controller thinks it's assembled
                    this.controller = loadedController;
                } else {
                    // Controller exists but is not assembled, invalidate our state
                    this.controllerPos = null;
                    this.isFormed = false;
                    removeFromEnergyNet(); // Ensure removal from network
                }
            } else {
                // Controller position points to a wrong TE or null, invalidate our state
                this.controllerPos = null;
                this.isFormed = false;
                removeFromEnergyNet(); // Ensure removal from network
            }
        } else if (controller != null && (!controller.isAssembled() || controller.isInvalid())) {
            // Controller reference exists but structure is broken or TE is invalid
            this.controller = null;
            this.controllerPos = null;
            this.isFormed = false;
            removeFromEnergyNet(); // Ensure removal from network
        }
        return this.controller;
    }

    @Override
    public void onStructureFormed(AbstractMultiblockController controller) {
        setController(controller);
        // Add to EnergyNet now that structure is confirmed formed
        addToEnergyNet();
    }

    @Override
    public void onStructureBroken() {
        setController(null);
        // Remove from EnergyNet
        removeFromEnergyNet();
    }

    @Override
    public World getPartWorld() {
        return this.world;
    }

    @Override
    public BlockPos getPartPos() {
        return this.pos;
    }

    @Override
    public boolean isConnected() {
        // Check controller existence and assembly state
        return getController() != null; // Relies on getController() to validate assembly state
    }

    @Override
    public void onMachineAssembled(AbstractMultiblockController controller) {
        // Called when structure is saved or formed. Ensure controller is set and add to network.
        setController(controller);
        addToEnergyNet();
    }

    @Override
    public void onMachineLoaded(AbstractMultiblockController controller) {
        // Called when structure is loaded from NBT. Ensure controller is set and add to network.
        setController(controller);
        // Schedule adding to EnergyNet to ensure world is ready
        if (world != null && !world.isRemote) {
            FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(this::addToEnergyNet); // Use scheduled task
        }
    }

    @Override
    public void onMachineBroken() {
        // Called when structure is broken or unloaded.
        setController(null);
        removeFromEnergyNet();
    }

    @Override
    public void onMachinePaused() {
        // Called on chunk unload. Remove from EnergyNet.
        removeFromEnergyNet();
    }

    @Override
    public void onMachineResumed() {
        // Called on chunk load. Add back to EnergyNet if connected.
        if (isConnected()) {
            addToEnergyNet();
        }
    }

    // --- EnergyNet Handling ---
    private void addToEnergyNet() {
        if (world != null && !world.isRemote && !addedToEnergyNet && isConnected()) { // Check isConnected here
            EnergyNet.instance.addTile(this);
            addedToEnergyNet = true;
        }
    }

    private void removeFromEnergyNet() {
        if (world != null && !world.isRemote && addedToEnergyNet) {
            EnergyNet.instance.removeTile(this);
            addedToEnergyNet = false;
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        // Defer adding to EnergyNet until onMachineLoaded or onMachineResumed is called by controller
        // Or if loaded state indicates it should be formed
        if (isFormed && controllerPos != null && world != null && !world.isRemote) {
            FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(() -> {
                if (isConnected()) { // Re-check in case structure broke between load and task execution
                    addToEnergyNet();
                }
            });
        }
    }

    @Override
    public void invalidate() {
        super.invalidate();
        removeFromEnergyNet();
    }

    @Override
    public void onChunkUnload() {
        super.onChunkUnload();
        // onMachinePaused should handle removal now
        // removeFromEnergyNet();
    }

    // --- ITickable Implementation ---
    @Override
    public void update() {
        if (world == null || world.isRemote) return;

        // Ensure controller reference is valid
        AbstractMultiblockController currentController = getController();
        if (currentController == null) return; // Do nothing if not connected
    }

    // --- IEnergySink Implementation (Receiving Energy from Network) ---

    @Override
    public double getDemandedEnergy() {
        if (!isConnected() || mode != EnergyPortMode.INPUT) {
            return 0; // Only demand if connected and in input mode
        }
        // Demand energy to fill the internal buffer
        double spaceInBuffer = capacity - buffer;
        return Math.max(0, spaceInBuffer);
    }

    @Override
    public int getSinkTier() {
        // Use the port's tier. Controller tier check happens on injection.
        return this.tier;
    }

    @Override
    public double injectEnergy(EnumFacing directionFrom, double amount, double voltage) {
        if (!isConnected() || mode != EnergyPortMode.INPUT) {
            return amount; // Cannot accept energy
        }

        // Check voltage against the port's tier
        if (voltage > getPowerFromTier(getSinkTier())) {
            // Trigger IC2 explosion for overvoltage
            ExplosionIC2 explosion = new ExplosionIC2(world, null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 0.5f, 0.5f, ExplosionIC2.Type.Normal, null, 0);
            explosion.doExplosion();
            return amount; // Reject all energy due to overvoltage
        }

        // Using internal buffer
        double spaceInBuffer = capacity - buffer;
        double accepted = Math.min(amount, spaceInBuffer);
        if (accepted > 0) {
            buffer += accepted;
            markDirty(); // Mark tile entity as changed to save state
            return amount - accepted; // Return unaccepted amount
        }
        return amount; // Buffer full, reject all energy
    }

    @Override
    public boolean acceptsEnergyFrom(IEnergyEmitter emitter, EnumFacing side) {
        // Accept from any side if connected and in input mode
        return isConnected() && mode == EnergyPortMode.INPUT;
    }

    // --- IEnergySource Implementation (Sending Energy to Network) ---

    @Override
    public double getOfferedEnergy() {
        if (!isConnected() || mode != EnergyPortMode.OUTPUT) {
            return 0; // Cannot offer energy
        }

        // Using internal buffer
        double maxTransferThisTick = getPowerFromTier(getSourceTier());
        return Math.min(buffer, maxTransferThisTick); // Offer up to buffer or tier limit
    }

    @Override
    public void drawEnergy(double amount) {
        if (!isConnected() || mode != EnergyPortMode.OUTPUT) {
            return; // Should not happen
        }

        // Using internal buffer
        if (amount <= buffer) {
            buffer -= amount;
            markDirty();
        } else {
            // Should not happen if offeredEnergy is correct
            buffer = 0;
            markDirty();
        }
    }

    @Override
    public int getSourceTier() {
        // Use the port's tier. Receiver should check its own tier.
        return this.tier;
    }

    @Override
    public boolean emitsEnergyTo(IEnergyAcceptor receiver, EnumFacing side) {
        // Emit to any side if connected and in output mode
        return isConnected() && mode == EnergyPortMode.OUTPUT;
    }

    // --- NBT --- (Added network sync tags)

    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound); // Handles pos
        writeSyncableDataToNBT(compound);
        compound.setDouble("Buffer", buffer); // Save buffer
        return compound;
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        readSyncableDataFromNBT(compound);
        buffer = compound.getDouble("Buffer"); // Load buffer
    }

    // Separate methods for data synced to client vs saved data
    private NBTTagCompound writeSyncableDataToNBT(NBTTagCompound compound) {
        compound.setInteger("Mode", mode.ordinal());
        compound.setInteger("Tier", tier);
        compound.setBoolean("IsFormed", isFormed);
        if (controllerPos != null) {
            // Store controller position as long for NBT
            compound.setLong("ControllerPos", controllerPos.toLong());
        }
        return compound;
    }

    private void readSyncableDataFromNBT(NBTTagCompound compound) {
        mode = EnergyPortMode.values()[compound.getInteger("Mode")];
        tier = compound.getInteger("Tier");
        isFormed = compound.getBoolean("IsFormed");
        if (compound.hasKey("ControllerPos")) {
            // Read controller position from long
            controllerPos = BlockPos.fromLong(compound.getLong("ControllerPos"));
        } else {
            controllerPos = null;
        }
        // Clear controller reference on load
        this.controller = null;
    }

    // --- Network Updates --- Used for client sync (e.g., rendering formed state)
    @Override
    @Nullable
    public SPacketUpdateTileEntity getUpdatePacket() {
        NBTTagCompound nbtTag = new NBTTagCompound();
        writeSyncableDataToNBT(nbtTag); // Write only synced data
        return new SPacketUpdateTileEntity(this.pos, 1, nbtTag);
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readSyncableDataFromNBT(pkt.getNbtCompound());
        // Optionally trigger a block re-render
        world.markBlockRangeForRenderUpdate(pos, pos);
    }

    @Override
    public NBTTagCompound getUpdateTag() {
        // Used for initial chunk data sync
        return writeToNBT(new NBTTagCompound()); // Send all data initially
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        // Handles the initial chunk data sync
        this.readFromNBT(tag);
    }

    // Method for potential GUI or other access
    public EnergyPortMode getMode() {
        return mode;
    }
}