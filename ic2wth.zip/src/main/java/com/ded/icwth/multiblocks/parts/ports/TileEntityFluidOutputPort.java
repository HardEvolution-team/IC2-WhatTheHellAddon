package com.ded.icwth.multiblocks.parts.ports;

import com.ded.icwth.api.multiblock.AbstractMultiblockController;
import com.ded.icwth.api.multiblock.TileEntityMultiblockPart;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidTank;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.IFluidTankProperties;

import javax.annotation.Nullable;

public class TileEntityFluidOutputPort extends TileEntityMultiblockPart implements ITickable, IFluidHandler {

    // Internal buffer tank
    protected FluidTank tank = new FluidTank(Fluid.BUCKET_VOLUME * 16); // Example: 16 Buckets capacity
    private String customName;

    // Capability handler (self)
    private final IFluidHandler capabilityHandler = this; // The TE itself is the handler

    public TileEntityFluidOutputPort() {
        super();
        tank.setTileEntity(this);
    }

    // Constructor for setting capacity (optional)
    public TileEntityFluidOutputPort(int capacity) {
        super();
        this.tank = new FluidTank(capacity);
        tank.setTileEntity(this);
    }

    // --- ITickable Implementation ---
    @Override
    public void update() {
        if (!world.isRemote && isConnected() && getController() != null) {
            // Logic for pulling fluids from controller to internal tank
            if (tank.getFluidAmount() < tank.getCapacity()) {
                IFluidHandler controllerHandler = getController().getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null);
                if (controllerHandler != null) {
                    int space = tank.getCapacity() - tank.getFluidAmount();
                    if (space > 0) {
                        // Try to drain *something* from the controller that can fit in our tank
                        IFluidTankProperties[] controllerProps = controllerHandler.getTankProperties();
                        for (IFluidTankProperties props : controllerProps) {
                            FluidStack fluidInController = props.getContents();
                            if (fluidInController != null && fluidInController.amount > 0 && props.canDrain()) {
                                // Check if the fluid can be filled into our tank
                                if (tank.fill(fluidInController, false) > 0) { // Simulate fill
                                    // Drain from controller up to the available space in our tank
                                    FluidStack drained = controllerHandler.drain(new FluidStack(fluidInController.getFluid(), space), true); // doDrain=true
                                    if (drained != null && drained.amount > 0) {
                                        int filled = tank.fill(drained, true); // Fill internal tank (doFill=true)
                                        // tank.fill handles marking dirty
                                        if (filled > 0) {
                                            break; // Drained and filled one fluid type this tick
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- IFluidHandler Implementation (Wraps internal tank) ---
    @Override
    public IFluidTankProperties[] getTankProperties() {
        return tank.getTankProperties();
    }

    @Override
    public int fill(FluidStack resource, boolean doFill) {
        // Prevent filling into output port
        return 0;
    }

    @Nullable
    @Override
    public FluidStack drain(FluidStack resource, boolean doDrain) {
        // Allow draining from external sources
        FluidStack drained = tank.drain(resource, doDrain);
        // tank.drain handles marking dirty
        return drained;
    }

    @Nullable
    @Override
    public FluidStack drain(int maxDrain, boolean doDrain) {
        // Allow draining from external sources
        FluidStack drained = tank.drain(maxDrain, doDrain);
        // tank.drain handles marking dirty
        return drained;
    }

    // --- NBT & Network ---
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound); // Handles controllerPos, isFormed etc.
        NBTTagCompound tankNBT = new NBTTagCompound();
        tank.writeToNBT(tankNBT);
        compound.setTag("Tank", tankNBT);
        if (this.customName != null) {
            compound.setString("CustomName", this.customName);
        }
        return compound;
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        if (compound.hasKey("Tank")) {
            tank.readFromNBT(compound.getCompoundTag("Tank"));
            tank.setTileEntity(this); // Re-link tank to TE after loading
        }
        if (compound.hasKey("CustomName", 8)) {
            this.customName = compound.getString("CustomName");
        }
    }

    // Sync tank contents for GUI and client rendering if needed
    @Override
    public NBTTagCompound getUpdateTag() {
        NBTTagCompound nbt = super.getUpdateTag();
        NBTTagCompound tankNBT = new NBTTagCompound();
        tank.writeToNBT(tankNBT);
        nbt.setTag("Tank", tankNBT);
        return nbt;
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        super.handleUpdateTag(tag);
        if (tag.hasKey("Tank")) {
            tank.readFromNBT(tag.getCompoundTag("Tank"));
            tank.setTileEntity(this);
        }
    }

    @Nullable
    @Override
    public SPacketUpdateTileEntity getUpdatePacket() {
        NBTTagCompound nbt = super.getUpdatePacketNBT();
        NBTTagCompound tankNBT = new NBTTagCompound();
        tank.writeToNBT(tankNBT);
        nbt.setTag("Tank", tankNBT);
        return new SPacketUpdateTileEntity(this.pos, 4, nbt); // Use a unique desc packet id (e.g., 4)
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        super.onDataPacket(net, pkt);
        NBTTagCompound tag = pkt.getNbtCompound();
        if (tag.hasKey("Tank")) {
            tank.readFromNBT(tag.getCompoundTag("Tank"));
            tank.setTileEntity(this);
            world.markBlockRangeForRenderUpdate(pos, pos);
        }
    }

    // --- Capabilities ---
    @Override
    public boolean hasCapability(Capability<?> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY || super.hasCapability(capability, facing);
    }

    @SuppressWarnings("unchecked")
    @Nullable
    @Override
    public <T> T getCapability(Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY) {
            return (T) capabilityHandler; // Return self as the handler (allows draining, prevents filling)
        }
        return super.getCapability(capability, facing);
    }

    // --- GUI Related Methods (if GUI is needed) ---
    public boolean isUsableByPlayer(net.minecraft.entity.player.EntityPlayer player) {
        return this.world != null && this.world.getTileEntity(this.pos) == this && player.getDistanceSq(this.pos.add(0.5, 0.5, 0.5)) <= 64.0D;
    }

    public String getName() {
        return this.hasCustomName() ? this.customName : "container.icwth.fluid_output_port"; // Default name key
    }

    public boolean hasCustomName() {
        return this.customName != null && !this.customName.isEmpty();
    }

    public net.minecraft.util.text.ITextComponent getDisplayName() {
        return this.hasCustomName() ? new net.minecraft.util.text.TextComponentString(this.getName()) : new net.minecraft.util.text.TextComponentTranslation(this.getName());
    }

    public FluidTank getTank() {
        return tank;
    }
}

