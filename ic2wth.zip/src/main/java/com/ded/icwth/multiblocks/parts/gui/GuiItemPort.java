package com.ded.icwth.multiblocks.parts.gui; // Assuming a gui subpackage

import com.ded.icwth.MyMod; // Assuming MyMod has MODID
import com.ded.icwth.Tags;
import com.ded.icwth.multiblocks.parts.TileItemPort;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiItemPort extends GuiContainer {

    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation(Tags.MODID, "textures/gui/gui_item_port.png"); // Path to your GUI texture
    private final InventoryPlayer playerInventory;
    private final TileItemPort tileEntity;

    public GuiItemPort(InventoryPlayer playerInventory, TileItemPort tileEntity) {
        super(new ContainerItemPort(playerInventory, tileEntity));
        this.playerInventory = playerInventory;
        this.tileEntity = tileEntity;

        // Set GUI size (standard chest size)
        this.xSize = 176;
        this.ySize = 166;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground(); // Draw the dark background behind the GUI
        super.drawScreen(mouseX, mouseY, partialTicks);
        this.renderHoveredToolTip(mouseX, mouseY); // Draw tooltips (like item names)
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F); // Reset color
        this.mc.getTextureManager().bindTexture(GUI_TEXTURE);
        int guiLeft = (this.width - this.xSize) / 2;
        int guiTop = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(guiLeft, guiTop, 0, 0, this.xSize, this.ySize);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        // Draw the title of the container
        String title = this.tileEntity.getDisplayName().getUnformattedText();
        this.fontRenderer.drawString(title, (this.xSize / 2 - this.fontRenderer.getStringWidth(title) / 2), 6, 4210752); // 4210752 is dark gray

        // Draw the player inventory label
        this.fontRenderer.drawString(this.playerInventory.getDisplayName().getUnformattedText(), 8, this.ySize - 96 + 2, 4210752);

        // Optionally, draw info about the port mode (Input/Output/Both)
        String modeString = "Mode: " + tileEntity.getMode().name(); // Assuming getMode() exists in TileItemPort
        this.fontRenderer.drawString(modeString, 8, 18, 4210752);
    }
}

