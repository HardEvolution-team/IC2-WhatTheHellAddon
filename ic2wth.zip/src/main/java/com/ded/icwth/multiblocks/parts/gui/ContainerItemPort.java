package com.ded.icwth.multiblocks.parts.gui; // Assuming a gui subpackage

import com.ded.icwth.multiblocks.parts.TileItemPort;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class ContainerItemPort extends Container {

    private final TileItemPort tileEntity;
    private final int inventorySize;

    public ContainerItemPort(InventoryPlayer playerInventory, TileItemPort tileEntity) {
        this.tileEntity = tileEntity;
        this.inventorySize = tileEntity.getSizeInventory(); // Should be 1 for our TileItemPort

        // Get the capability handler
        IItemHandler itemHandler = this.tileEntity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);

        // Tile Entity Inventory Slot(s)
        // Assuming a single slot at coordinates (80, 35) in the GUI
        this.addSlotToContainer(new SlotItemHandler(itemHandler, 0, 80, 35));

        // Player Inventory Slots
        int playerInvY = 84;
        int playerInvX = 8;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlotToContainer(new Slot(playerInventory, j + i * 9 + 9, playerInvX + j * 18, playerInvY + i * 18));
            }
        }

        // Player Hotbar Slots
        int hotbarY = 142;
        for (int k = 0; k < 9; ++k) {
            this.addSlotToContainer(new Slot(playerInventory, k, playerInvX + k * 18, hotbarY));
        }
    }

    @Override
    public boolean canInteractWith(EntityPlayer playerIn) {
        return this.tileEntity.isUsableByPlayer(playerIn);
    }

    @Override
    public ItemStack transferStackInSlot(EntityPlayer playerIn, int index) {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = this.inventorySlots.get(index);

        if (slot != null && slot.getHasStack()) {
            ItemStack itemstack1 = slot.getStack();
            itemstack = itemstack1.copy();

            // Index 0 is the TileEntity slot, others are player inventory
            if (index < this.inventorySize) {
                // Try merging from TileEntity to player inventory (indices inventorySize to inventorySize + 35)
                if (!this.mergeItemStack(itemstack1, this.inventorySize, this.inventorySize + 36, true)) {
                    return ItemStack.EMPTY;
                }
            } else {
                // Try merging from player inventory to TileEntity slot (index 0)
                // Check if item is valid for the slot (respecting input/output mode)
                if (tileEntity.isItemValidForSlot(0, itemstack1)) {
                    if (!this.mergeItemStack(itemstack1, 0, this.inventorySize, false)) {
                         // If merge to TE fails, try merging within player inventory
                         if (index < this.inventorySize + 27) { // Player main inventory
                             if (!this.mergeItemStack(itemstack1, this.inventorySize + 27, this.inventorySize + 36, false)) {
                                 return ItemStack.EMPTY;
                             }
                         } else { // Player hotbar
                             if (!this.mergeItemStack(itemstack1, this.inventorySize, this.inventorySize + 27, false)) {
                                 return ItemStack.EMPTY;
                             }
                         }
                         // Return empty if merge to TE failed but merge within player inv might succeed
                         // return ItemStack.EMPTY; // Original logic might be better here
                    }
                } else {
                    // If not valid for TE, merge within player inventory
                    if (index < this.inventorySize + 27) { // Player main inventory
                        if (!this.mergeItemStack(itemstack1, this.inventorySize + 27, this.inventorySize + 36, false)) {
                            return ItemStack.EMPTY;
                        }
                    } else { // Player hotbar
                        if (!this.mergeItemStack(itemstack1, this.inventorySize, this.inventorySize + 27, false)) {
                            return ItemStack.EMPTY;
                        }
                    }
                }
            }

            if (itemstack1.isEmpty()) {
                slot.putStack(ItemStack.EMPTY);
            } else {
                slot.onSlotChanged();
            }

            if (itemstack1.getCount() == itemstack.getCount()) {
                return ItemStack.EMPTY;
            }

            slot.onTake(playerIn, itemstack1);
        }

        return itemstack;
    }
}

