package com.ded.icwth.multiblocks.parts.gui; // Assuming a gui subpackage

import com.ded.icwth.MyMod; // Assuming MyMod has MODID
import com.ded.icwth.Tags;
import com.ded.icwth.multiblocks.parts.TileFluidPort;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidTank;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import java.util.ArrayList;
import java.util.List;

@SideOnly(Side.CLIENT)
public class GuiFluidPort extends GuiContainer {

    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation(Tags.MODID, "textures/gui/gui_fluid_port.png"); // Path to your GUI texture
    private final InventoryPlayer playerInventory;
    private final TileFluidPort tileEntity;

    // Define tank position and size within the GUI texture
    private final int tankX = 80;
    private final int tankY = 20;
    private final int tankWidth = 16;
    private final int tankHeight = 50;

    public GuiFluidPort(InventoryPlayer playerInventory, TileFluidPort tileEntity) {
        super(new ContainerFluidPort(playerInventory, tileEntity));
        this.playerInventory = playerInventory;
        this.tileEntity = tileEntity;

        // Set GUI size (adjust if needed)
        this.xSize = 176;
        this.ySize = 166;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawDefaultBackground();
        super.drawScreen(mouseX, mouseY, partialTicks);
        this.renderHoveredToolTip(mouseX, mouseY);

        // Render fluid tank tooltip
        if (isPointInRegion(tankX, tankY, tankWidth, tankHeight, mouseX, mouseY)) {
            drawTankTooltip(mouseX, mouseY);
        }
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        this.mc.getTextureManager().bindTexture(GUI_TEXTURE);
        int guiLeft = (this.width - this.xSize) / 2;
        int guiTop = (this.height - this.ySize) / 2;
        this.drawTexturedModalRect(guiLeft, guiTop, 0, 0, this.xSize, this.ySize);

        // Draw fluid in tank
        drawFluidTank(guiLeft, guiTop);
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        // Draw the title
        String title = this.tileEntity.getDisplayName().getUnformattedText();
        this.fontRenderer.drawString(title, (this.xSize / 2 - this.fontRenderer.getStringWidth(title) / 2), 6, 4210752);

        // Draw player inventory label
        this.fontRenderer.drawString(this.playerInventory.getDisplayName().getUnformattedText(), 8, this.ySize - 96 + 2, 4210752);

        // Draw port mode
        String modeString = "Mode: " + tileEntity.getMode().name();
        this.fontRenderer.drawString(modeString, 8, 72, 4210752); // Adjust position
    }

    private void drawFluidTank(int guiLeft, int guiTop) {
        FluidTank tank = tileEntity.getTank();
        FluidStack fluidStack = tank.getFluid();

        if (fluidStack != null && fluidStack.amount > 0) {
            TextureAtlasSprite fluidSprite = getFluidSprite(fluidStack);
            if (fluidSprite != null) {
                this.mc.getTextureManager().bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);

                int fluidAmount = fluidStack.amount;
                int tankCapacity = tank.getCapacity();
                int fluidHeight = (int) ((float) fluidAmount / tankCapacity * tankHeight);

                int color = fluidStack.getFluid().getColor(fluidStack);
                float r = (color >> 16 & 0xFF) / 255.0F;
                float g = (color >> 8 & 0xFF) / 255.0F;
                float b = (color & 0xFF) / 255.0F;
                GlStateManager.color(r, g, b, 1.0F);

                int drawX = guiLeft + tankX;
                int drawY = guiTop + tankY + tankHeight - fluidHeight;

                // Draw the fluid sprite repeatedly to fill the height
                int fullTextureHeight = 16;
                int fullTextureWidth = 16;
                int drawnHeight = 0;
                while (drawnHeight < fluidHeight) {
                    int heightToDraw = Math.min(fluidHeight - drawnHeight, fullTextureHeight);
                    drawTexturedModalRect(drawX, drawY + drawnHeight, fluidSprite, tankWidth, heightToDraw);
                    drawnHeight += heightToDraw;
                }

                // Reset color
                GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

                // Re-bind GUI texture if tank overlay is part of it
                // this.mc.getTextureManager().bindTexture(GUI_TEXTURE);
                // Draw tank overlay (e.g., glass texture) over the fluid
                // this.drawTexturedModalRect(guiLeft + tankX, guiTop + tankY, textureX, textureY, tankWidth, tankHeight);
            }
        }
    }

    private TextureAtlasSprite getFluidSprite(FluidStack fluidStack) {
        if (fluidStack == null || fluidStack.getFluid() == null) {
            return null;
        }
        ResourceLocation fluidLocation = fluidStack.getFluid().getStill(fluidStack);
        if (fluidLocation != null) {
            return this.mc.getTextureMapBlocks().getAtlasSprite(fluidLocation.toString());
        }
        return null;
    }

    private void drawTankTooltip(int mouseX, int mouseY) {
        FluidTank tank = tileEntity.getTank();
        FluidStack fluidStack = tank.getFluid();
        List<String> tooltip = new ArrayList<>();

        if (fluidStack != null && fluidStack.amount > 0) {
            tooltip.add(fluidStack.getLocalizedName());
            tooltip.add(I18n.format("icwth.gui.fluid.amount", fluidStack.amount, tank.getCapacity()));
        } else {
            tooltip.add(I18n.format("icwth.gui.fluid.empty"));
            tooltip.add(I18n.format("icwth.gui.fluid.capacity", tank.getCapacity()));
        }

        this.drawHoveringText(tooltip, mouseX, mouseY);
    }
}

