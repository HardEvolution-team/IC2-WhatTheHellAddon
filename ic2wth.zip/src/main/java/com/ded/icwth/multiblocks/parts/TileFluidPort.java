package com.ded.icwth.multiblocks.parts;

import com.ded.icwth.api.multiblock.AbstractMultiblockController;
import com.ded.icwth.api.multiblock.IMultiblockPart;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidTank;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.IFluidTankProperties;

import javax.annotation.Nullable;

// Note: This class seems to implement IMultiblockPart but also TileEntityMultiblockPart logic.
// Consider extending TileEntityMultiblockPart instead if appropriate.
public class TileFluidPort extends TileEntity implements IMultiblockPart, ITickable, IFluidHandler {

    @Nullable // Use Nullable annotation
    private AbstractMultiblockController controller;
    @Nullable // Use Nullable annotation
    private BlockPos controllerPos; // Store controller position for re-linking
    private boolean isFormed = false;

    // Configuration
    private FluidPortMode mode = FluidPortMode.INPUT; // Default to input
    protected FluidTank tank = new FluidTank(Fluid.BUCKET_VOLUME * 16); // Example: 16 Buckets capacity
    private String customName;

    // Capability handler (self)
    private final IFluidHandler capabilityHandler = this; // The TE itself is the handler

    public enum FluidPortMode {
        INPUT, OUTPUT, BOTH
    }

    public TileFluidPort() {
        // Default constructor
        tank.setTileEntity(this);
    }

    // Constructor for setting mode and capacity
    public TileFluidPort(FluidPortMode mode, int capacity) {
        this.mode = mode;
        this.tank = new FluidTank(capacity);
        tank.setTileEntity(this);
    }

    // --- IMultiblockPart Implementation ---
    @Override
    public void setController(@Nullable AbstractMultiblockController controller) {
        this.controller = controller;
        this.controllerPos = (controller != null) ? controller.getPos() : null;
        boolean previouslyFormed = this.isFormed;
        this.isFormed = (controller != null);
        if (this.isFormed != previouslyFormed) {
            markDirtyClient(); // Use helper method
        }
    }

    @Override
    @Nullable
    public AbstractMultiblockController getController() {
        // Simplified logic: rely on controller check/invalidation
        if (controller != null && (!controller.isAssembled() || controller.isInvalid())) {
            setController(null); // Clear if controller is invalid
        }
        // Attempt re-link on server if controller is null but pos exists
        if (controller == null && controllerPos != null && world != null && !world.isRemote && world.isBlockLoaded(controllerPos)) {
            TileEntity te = world.getTileEntity(controllerPos);
            if (te instanceof AbstractMultiblockController) {
                AbstractMultiblockController potentialController = (AbstractMultiblockController) te;
                if (potentialController.isAssembled()) { // Check assembly state
                    setController(potentialController);
                }
            }
        }
        return this.controller;
    }

    // --- Invalidation Logic (Similar to TileEntityMultiblockPart) ---
    @Override
    public void invalidate() {
        super.invalidate();
        if (world != null && !world.isRemote && controllerPos != null) {
            AbstractMultiblockController currentController = getController(); // Use getter to ensure valid controller
            if (currentController != null) {
                // Notify the controller that this part is being removed
                // Use the method signature from the user's AbstractMultiblockController: notifyPartBroken(IMultiblockPart part)
                currentController.notifyPartBroken(this); // Corrected method call
            }
        }
        setController(null); // Ensure controller link is cleared
    }

    // --- ITickable Implementation ---
    @Override
    public void update() {
        if (!world.isRemote && isConnected()) {
            AbstractMultiblockController currentController = getController(); // Use getter
            if (currentController != null) {
                // Logic for transferring fluids between internal tank and controller
                IFluidHandler controllerHandler = currentController.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null); // Adjust facing?

                if (controllerHandler != null) {
                    // Push from internal tank to controller if INPUT mode
                    if ((mode == FluidPortMode.INPUT || mode == FluidPortMode.BOTH) && tank.getFluidAmount() > 0) {
                        FluidStack toTransfer = tank.getFluid().copy();
                        int filled = controllerHandler.fill(toTransfer, true); // Simulate=false
                        if (filled > 0) {
                            tank.drain(filled, true); // Actually drain from internal tank
                        }
                    }

                    // Pull from controller to internal tank if OUTPUT mode
                    if ((mode == FluidPortMode.OUTPUT || mode == FluidPortMode.BOTH) && tank.getFluidAmount() < tank.getCapacity()) {
                        int space = tank.getCapacity() - tank.getFluidAmount();
                        if (space > 0) {
                            // Try to drain *something* from the controller
                            IFluidTankProperties[] controllerProps = controllerHandler.getTankProperties();
                            for (IFluidTankProperties props : controllerProps) {
                                FluidStack fluidInController = props.getContents();
                                if (fluidInController != null && fluidInController.amount > 0 && props.canDrain()) {
                                    // Can we fill this into our tank?
                                    if (tank.fill(fluidInController, false) > 0) { // Check if compatible
                                        FluidStack drained = controllerHandler.drain(new FluidStack(fluidInController.getFluid(), space), true); // Drain up to available space
                                        if (drained != null && drained.amount > 0) {
                                            tank.fill(drained, true); // Fill internal tank
                                            break; // Drained one fluid type this tick
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- IFluidHandler Implementation (Wraps internal tank) ---
    @Override
    public IFluidTankProperties[] getTankProperties() {
        return tank.getTankProperties();
    }

    @Override
    public int fill(FluidStack resource, boolean doFill) {
        // Allow filling only in INPUT mode (or BOTH)
        if (mode == FluidPortMode.INPUT || mode == FluidPortMode.BOTH) {
            int filled = tank.fill(resource, doFill);
            // tank.fill handles marking dirty
            return filled;
        }
        return 0;
    }

    @Nullable
    @Override
    public FluidStack drain(FluidStack resource, boolean doDrain) {
        // Allow draining only in OUTPUT mode (or BOTH)
        if (mode == FluidPortMode.OUTPUT || mode == FluidPortMode.BOTH) {
            FluidStack drained = tank.drain(resource, doDrain);
            // tank.drain handles marking dirty
            return drained;
        }
        return null;
    }

    @Nullable
    @Override
    public FluidStack drain(int maxDrain, boolean doDrain) {
        // Allow draining only in OUTPUT mode (or BOTH)
        if (mode == FluidPortMode.OUTPUT || mode == FluidPortMode.BOTH) {
            FluidStack drained = tank.drain(maxDrain, doDrain);
            // tank.drain handles marking dirty
            return drained;
        }
        return null;
    }

    // --- NBT & Network ---
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        writeSyncableDataToNBT(compound); // Include sync data in main save
        NBTTagCompound tankNBT = new NBTTagCompound();
        tank.writeToNBT(tankNBT);
        compound.setTag("Tank", tankNBT);
        if (this.customName != null) {
            compound.setString("CustomName", this.customName);
        }
        return compound;
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        readSyncableDataFromNBT(compound);
        if (compound.hasKey("Tank")) {
            tank.readFromNBT(compound.getCompoundTag("Tank"));
            tank.setTileEntity(this); // Re-link tank to TE after loading
        }
        if (compound.hasKey("CustomName", 8)) {
            this.customName = compound.getString("CustomName");
        }
    }

    private NBTTagCompound writeSyncableDataToNBT(NBTTagCompound compound) {
        compound.setInteger("Mode", mode.ordinal());
        compound.setBoolean("IsFormed", isFormed);
        if (controllerPos != null) {
            compound.setLong("ControllerPos", controllerPos.toLong());
        }
        // Sync tank contents for GUI
        NBTTagCompound tankNBT = new NBTTagCompound();
        tank.writeToNBT(tankNBT);
        compound.setTag("TankSync", tankNBT);
        return compound;
    }

    private void readSyncableDataFromNBT(NBTTagCompound compound) {
        mode = FluidPortMode.values()[compound.getInteger("Mode")];
        isFormed = compound.getBoolean("IsFormed");
        if (compound.hasKey("ControllerPos")) {
            controllerPos = BlockPos.fromLong(compound.getLong("ControllerPos"));
        } else {
            controllerPos = null;
        }
        // Read synced tank contents
        if (compound.hasKey("TankSync")) {
            tank.readFromNBT(compound.getCompoundTag("TankSync"));
            tank.setTileEntity(this); // Re-link tank
        }
        // Clear controller reference on load, rely on getController() to re-link
        this.controller = null;
    }

    protected void markDirtyClient() {
        if (world != null) {
            net.minecraft.block.state.IBlockState state = world.getBlockState(pos);
            world.notifyBlockUpdate(pos, state, state, 3);
            markDirty();
        }
    }

    @Override
    @Nullable
    public SPacketUpdateTileEntity getUpdatePacket() {
        NBTTagCompound nbtTag = new NBTTagCompound();
        writeSyncableDataToNBT(nbtTag);
        return new SPacketUpdateTileEntity(this.pos, 3, nbtTag); // Use a desc packet id (e.g., 3)
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readSyncableDataFromNBT(pkt.getNbtCompound());
        if (world != null) {
            world.markBlockRangeForRenderUpdate(pos, pos);
        }
    }

    @Override
    public NBTTagCompound getUpdateTag() {
        // Called for initial chunk data
        return writeToNBT(new NBTTagCompound());
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        // Handles initial chunk data
        this.readFromNBT(tag);
    }

    // --- Capabilities ---
    @Override
    public boolean hasCapability(Capability<?> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY || super.hasCapability(capability, facing);
    }

    @SuppressWarnings("unchecked")
    @Nullable
    @Override
    public <T> T getCapability(Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY) {
            return (T) capabilityHandler; // Return self as the handler
        }
        return super.getCapability(capability, facing);
    }

    // --- GUI Related Methods ---
    public boolean isUsableByPlayer(net.minecraft.entity.player.EntityPlayer player) {
        return this.world != null && this.world.getTileEntity(this.pos) == this && player.getDistanceSq((double)this.pos.getX() + 0.5D, (double)this.pos.getY() + 0.5D, (double)this.pos.getZ() + 0.5D) <= 64.0D;
    }

    public String getName() {
        return this.hasCustomName() ? this.customName : "container.icwth.fluid_port"; // Default name key
    }

    public boolean hasCustomName() {
        return this.customName != null && !this.customName.isEmpty();
    }

    public net.minecraft.util.text.ITextComponent getDisplayName() {
        return this.hasCustomName() ? new net.minecraft.util.text.TextComponentString(this.getName()) : new net.minecraft.util.text.TextComponentTranslation(this.getName());
    }

    public FluidTank getTank() {
        return tank;
    }

    public FluidPortMode getMode() {
        return mode;
    }

    // --- IMultiblockPart Stubs (Remove if extending TileEntityMultiblockPart) ---
    @Override
    public void onStructureFormed(AbstractMultiblockController controller) { setController(controller); }
    @Override
    public void onStructureBroken() { setController(null); }
    @Override
    public World getPartWorld() { return this.world; }
    @Override
    public BlockPos getPartPos() { return this.pos; }
    @Override
    public boolean isConnected() { return getController() != null; }
    @Override
    public void onMachineAssembled(AbstractMultiblockController controller) { setController(controller); }
    @Override
    public void onMachineLoaded(AbstractMultiblockController controller) { setController(controller); }
    @Override
    public void onMachineBroken() { setController(null); }
    @Override
    public void onMachinePaused() { }
    @Override
    public void onMachineResumed() { }

    // Remove onBreakBlock if extending TileEntityMultiblockPart, as invalidate handles it
    // public void onBreakBlock(World world, BlockPos pos, net.minecraft.block.state.IBlockState state) { ... }
}

