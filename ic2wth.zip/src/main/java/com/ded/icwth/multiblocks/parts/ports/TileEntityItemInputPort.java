package com.ded.icwth.multiblocks.parts.ports;

import com.ded.icwth.api.multiblock.AbstractMultiblockController;
import com.ded.icwth.api.multiblock.IMultiblockPart;
import com.ded.icwth.api.multiblock.TileEntityMultiblockPart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.wrapper.SidedInvWrapper;

import javax.annotation.Nullable;

// Extend TileEntityMultiblockPart if it exists and is suitable, otherwise implement IMultiblockPart directly
// Assuming TileEntityMultiblockPart exists based on the API structure seen in the tree output
public class TileEntityItemInputPort extends TileEntityMultiblockPart implements ISidedInventory, ITickable {

    // Use a small buffer inventory (e.g., 1 slot) to accept items before pushing to controller
    protected NonNullList<ItemStack> inventory = NonNullList.withSize(1, ItemStack.EMPTY);
    private String customName;

    // Capability handlers for external interaction
    private final IItemHandler handlerInput = new SidedInvWrapper(this, null); // Allow input from any side

    public TileEntityItemInputPort() {
        super();
    }

    // --- ITickable Implementation ---
    @Override
    public void update() {
        if (!world.isRemote && isConnected() && getController() != null) {
            // Logic for transferring items from internal slot to controller
            if (!inventory.get(0).isEmpty()) {
                IItemHandler controllerHandler = getController().getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null); // Get controller's handler
                if (controllerHandler != null) {
                    ItemStack internalStack = inventory.get(0);
                    ItemStack remaining = ItemHandlerHelper.insertItemStacked(controllerHandler, internalStack, false); // Try to insert into controller
                    setInventorySlotContents(0, remaining); // Update internal slot with what couldn't be inserted
                }
            }
        }
    }

    // --- IInventory Implementation ---
    @Override
    public int getSizeInventory() {
        return inventory.size();
    }

    @Override
    public boolean isEmpty() {
        return inventory.get(0).isEmpty();
    }

    @Override
    public ItemStack getStackInSlot(int index) {
        return inventory.get(index);
    }

    @Override
    public ItemStack decrStackSize(int index, int count) {
        return ItemStackHelper.getAndSplit(inventory, index, count);
    }

    @Override
    public ItemStack removeStackFromSlot(int index) {
        return ItemStackHelper.getAndRemove(inventory, index);
    }

    @Override
    public void setInventorySlotContents(int index, ItemStack stack) {
        inventory.set(index, stack);
        if (stack.getCount() > this.getInventoryStackLimit()) {
            stack.setCount(this.getInventoryStackLimit());
        }
        markDirty();
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    @Override
    public boolean isUsableByPlayer(EntityPlayer player) {
        return this.world.getTileEntity(this.pos) == this && player.getDistanceSq(this.pos.add(0.5, 0.5, 0.5)) <= 64.0D;
    }

    @Override
    public void openInventory(EntityPlayer player) {}

    @Override
    public void closeInventory(EntityPlayer player) {}

    @Override
    public boolean isItemValidForSlot(int index, ItemStack stack) {
        // Always accept items into the input buffer
        return true;
    }

    @Override
    public int getField(int id) { return 0; }

    @Override
    public void setField(int id, int value) {}

    @Override
    public int getFieldCount() { return 0; }

    @Override
    public void clear() {
        inventory.clear();
    }

    // --- ISidedInventory Implementation ---
    @Override
    public int[] getSlotsForFace(EnumFacing side) {
        // Allow access to the slot from all sides
        return new int[]{0};
    }

    @Override
    public boolean canInsertItem(int index, ItemStack itemStackIn, EnumFacing direction) {
        // Allow insertion from any direction
        return isItemValidForSlot(index, itemStackIn);
    }

    @Override
    public boolean canExtractItem(int index, ItemStack stack, EnumFacing direction) {
        // Prevent extraction from input port
        return false;
    }

    // --- NBT & Network ---
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound); // Handles controllerPos, isFormed etc. from TileEntityMultiblockPart
        ItemStackHelper.saveAllItems(compound, this.inventory);
        if (this.customName != null) {
            compound.setString("CustomName", this.customName);
        }
        return compound;
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        this.inventory = NonNullList.<ItemStack>withSize(this.getSizeInventory(), ItemStack.EMPTY);
        ItemStackHelper.loadAllItems(compound, this.inventory);
        if (compound.hasKey("CustomName", 8)) {
            this.customName = compound.getString("CustomName");
        }
    }

    // Override sync methods if TileEntityMultiblockPart doesn't handle inventory sync
    // Assuming TileEntityMultiblockPart handles basic sync (isFormed, controllerPos)

    // Helper for dropping inventory (called from Block)
    public void dropInventory() {
        if (!world.isRemote) {
            IItemHandler handler = getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
            if (handler != null) {
                for (int i = 0; i < handler.getSlots(); ++i) {
                    ItemStack itemstack = handler.getStackInSlot(i);
                    if (!itemstack.isEmpty()) {
                        InventoryHelper.spawnItemStack(world, pos.getX(), pos.getY(), pos.getZ(), itemstack);
                    }
                }
            }
        }
        clear(); // Clear inventory after dropping
    }

    // --- IWorldNameable Implementation (for GUI title) ---
    @Override
    public String getName() {
        return this.hasCustomName() ? this.customName : "container.icwth.item_input_port"; // Default name key
    }

    @Override
    public boolean hasCustomName() {
        return this.customName != null && !this.customName.isEmpty();
    }

    public void setCustomName(String name) {
        this.customName = name;
    }

    @Override
    public ITextComponent getDisplayName() {
        return this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName());
    }

    // --- Capabilities ---
    @Override
    public boolean hasCapability(Capability<?> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability(capability, facing);
    }

    @SuppressWarnings("unchecked")
    @Nullable
    @Override
    public <T> T getCapability(Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            // Provide the wrapper that allows insertion but not extraction
            return (T) handlerInput;
        }
        return super.getCapability(capability, facing);
    }
}

