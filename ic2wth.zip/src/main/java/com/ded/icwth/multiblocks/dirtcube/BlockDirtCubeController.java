package com.ded.icwth.multiblocks.dirtcube;

import com.ded.icwth.api.multiblock.BlockMultiblockController;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

import javax.annotation.Nullable;

public class BlockDirtCubeController extends BlockMultiblockController {

    public static final String NAME = "dirt_cube_controller";

    public BlockDirtCubeController() {
        // Pass only the Material to the super constructor
        super(Material.IRON);
        // Set registry and unlocalized names
        setRegistryName(NAME);
        setTranslationKey(NAME);
        // Set hardness, resistance, etc.
        setHardness(5.0F);
        setResistance(10.0F);
        // setCreativeTab(...); // TODO: Add to appropriate creative tab
    }

    // Implement the required method from the custom API
    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileDirtCubeController();
    }

    // Remove the standard Forge method if not needed by the custom base class
    /*
    @Nullable
    @Override
    public TileEntity createTileEntity(World world, IBlockState state) {
        return new TileDirtCubeController();
    }
    */

    // Add other necessary block overrides if needed (e.g., onBlockActivated)
}

