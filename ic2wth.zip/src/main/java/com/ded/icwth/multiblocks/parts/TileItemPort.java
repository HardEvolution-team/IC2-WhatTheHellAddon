package com.ded.icwth.multiblocks.parts;

import com.ded.icwth.api.multiblock.AbstractMultiblockController;
import com.ded.icwth.api.multiblock.IMultiblockPart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.wrapper.SidedInvWrapper;

import javax.annotation.Nullable;

public class TileItemPort extends TileEntity implements IMultiblockPart, ISidedInventory, ITickable {

    private AbstractMultiblockController controller;
    private BlockPos controllerPos; // Store controller position for re-linking
    private boolean isFormed = false;

    // Configuration
    private ItemPortMode mode = ItemPortMode.INPUT; // Default to input
    protected NonNullList<ItemStack> inventory = NonNullList.withSize(1, ItemStack.EMPTY); // Single slot for buffer/filter?
    private String customName;

    // Capability handlers
    private final IItemHandler handlerTop = new SidedInvWrapper(this, EnumFacing.UP);
    private final IItemHandler handlerBottom = new SidedInvWrapper(this, EnumFacing.DOWN);
    private final IItemHandler handlerSide = new SidedInvWrapper(this, EnumFacing.NORTH); // Assuming sides are interchangeable

    public enum ItemPortMode {
        INPUT, OUTPUT, BOTH // Allow bidirectional?
    }

    public TileItemPort() {
        // Default constructor
    }

    public TileItemPort(ItemPortMode mode) {
        this.mode = mode;
    }

    // --- IMultiblockPart Implementation ---
    @Override
    public void setController(AbstractMultiblockController controller) {
        this.controller = controller;
        this.controllerPos = (controller != null) ? controller.getPos() : null;
        boolean previouslyFormed = this.isFormed;
        this.isFormed = (controller != null);
        if (this.isFormed != previouslyFormed) {
            markDirty();
            if (world != null && !world.isRemote) {
                world.notifyBlockUpdate(pos, world.getBlockState(pos), world.getBlockState(pos), 3);
            }
        }
    }

    @Override
    public AbstractMultiblockController getController() {
        if (controller == null && controllerPos != null && world != null && !world.isRemote && world.isBlockLoaded(controllerPos)) {
            TileEntity te = world.getTileEntity(controllerPos);
            if (te instanceof AbstractMultiblockController) {
                AbstractMultiblockController loadedController = (AbstractMultiblockController) te;
                if (loadedController.isAssembled()) { // Check if the controller thinks it's assembled
                    this.controller = loadedController;
                } else {
                    // Controller exists but is not assembled, invalidate our state
                    this.controllerPos = null;
                    this.isFormed = false;
                }
            } else {
                // Controller position points to a wrong TE or null, invalidate our state
                this.controllerPos = null;
                this.isFormed = false;
            }
        } else if (controller != null && (!controller.isAssembled() || controller.isInvalid())) {
            // Controller reference exists but structure is broken or TE is invalid
            this.controller = null;
            this.controllerPos = null;
            this.isFormed = false;
        }
        return this.controller;
    }

    @Override
    public void onStructureFormed(AbstractMultiblockController controller) {
        setController(controller);
        // Additional logic when structure is first formed
    }

    @Override
    public void onStructureBroken() {
        setController(null);
        // Additional logic when structure breaks
    }

    @Override
    public World getPartWorld() {
        return this.world;
    }

    @Override
    public BlockPos getPartPos() {
        return this.pos;
    }

    @Override
    public boolean isConnected() {
        // Check controller existence and assembly state
        return getController() != null; // Relies on getController() to validate assembly state
    }

    @Override
    public void onMachineAssembled(AbstractMultiblockController controller) {
        // Called when structure is saved or formed. Ensure controller is set.
        setController(controller);
    }

    @Override
    public void onMachineLoaded(AbstractMultiblockController controller) {
        // Called when structure is loaded from NBT. Ensure controller is set.
        setController(controller);
    }

    @Override
    public void onMachineBroken() {
        // Called when structure is broken or unloaded.
        setController(null);
    }

    @Override
    public void onMachinePaused() {
        // Called on chunk unload, etc.
        // No specific action needed for basic port?
    }

    @Override
    public void onMachineResumed() {
        // Called on chunk load, etc.
        // No specific action needed for basic port?
    }

    // --- ITickable Implementation ---
    @Override
    public void update() {
        if (!world.isRemote && isConnected() && getController() != null) {
            // Logic for transferring items between internal slot and controller
            IItemHandler controllerHandler = getController().getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null); // Adjust facing as needed

            if (controllerHandler != null) {
                // Push from internal slot to controller if INPUT mode
                if ((mode == ItemPortMode.INPUT || mode == ItemPortMode.BOTH) && !inventory.get(0).isEmpty()) {
                    ItemStack internalStack = inventory.get(0);
                    ItemStack remaining = net.minecraftforge.items.ItemHandlerHelper.insertItemStacked(controllerHandler, internalStack, false);
                    setInventorySlotContents(0, remaining);
                }

                // Pull from controller to internal slot if OUTPUT mode (for external extraction)
                if ((mode == ItemPortMode.OUTPUT || mode == ItemPortMode.BOTH)) {
                    ItemStack internalStack = inventory.get(0);
                    if (internalStack.isEmpty() || internalStack.getCount() < internalStack.getMaxStackSize()) {
                        // Find an item to extract from controller
                        for (int i = 0; i < controllerHandler.getSlots(); i++) {
                            ItemStack stackInController = controllerHandler.getStackInSlot(i);
                            if (!stackInController.isEmpty()) {
                                // Can we insert this into our slot?
                                if (internalStack.isEmpty() || (ItemStack.areItemsEqual(internalStack, stackInController) && ItemStack.areItemStackTagsEqual(internalStack, stackInController))) {
                                    int space = internalStack.isEmpty() ? getInventoryStackLimit() : internalStack.getMaxStackSize() - internalStack.getCount();
                                    int toExtract = Math.min(stackInController.getCount(), space);
                                    if (toExtract > 0) {
                                        ItemStack extracted = controllerHandler.extractItem(i, toExtract, false);
                                        if (!extracted.isEmpty()) {
                                            if (internalStack.isEmpty()) {
                                                setInventorySlotContents(0, extracted);
                                            } else {
                                                internalStack.grow(extracted.getCount());
                                                markDirty(); // Manually mark dirty as we modified the stack directly
                                            }
                                            break; // Extracted one item type for this tick
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // --- IInventory Implementation ---
    @Override
    public int getSizeInventory() {
        return inventory.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack itemstack : this.inventory) {
            if (!itemstack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getStackInSlot(int index) {
        return inventory.get(index);
    }

    @Override
    public ItemStack decrStackSize(int index, int count) {
        return ItemStackHelper.getAndSplit(inventory, index, count);
    }

    @Override
    public ItemStack removeStackFromSlot(int index) {
        return ItemStackHelper.getAndRemove(inventory, index);
    }

    @Override
    public void setInventorySlotContents(int index, ItemStack stack) {
        inventory.set(index, stack);
        if (stack.getCount() > this.getInventoryStackLimit()) {
            stack.setCount(this.getInventoryStackLimit());
        }
        markDirty();
    }

    @Override
    public int getInventoryStackLimit() {
        return 64;
    }

    @Override
    public boolean isUsableByPlayer(EntityPlayer player) {
        return this.world.getTileEntity(this.pos) == this && player.getDistanceSq((double)this.pos.getX() + 0.5D, (double)this.pos.getY() + 0.5D, (double)this.pos.getZ() + 0.5D) <= 64.0D;
    }

    @Override
    public void openInventory(EntityPlayer player) {}

    @Override
    public void closeInventory(EntityPlayer player) {}

    @Override
    public boolean isItemValidForSlot(int index, ItemStack stack) {
        // Allow insertion only in INPUT mode (or BOTH)
        // Potentially add filter logic here
        return mode == ItemPortMode.INPUT || mode == ItemPortMode.BOTH;
    }

    @Override
    public int getField(int id) { return 0; }

    @Override
    public void setField(int id, int value) {}

    @Override
    public int getFieldCount() { return 0; }

    @Override
    public void clear() {
        inventory.clear();
    }

    // --- ISidedInventory Implementation ---
    @Override
    public int[] getSlotsForFace(EnumFacing side) {
        // Allow access to the slot from all sides
        return new int[]{0};
    }

    @Override
    public boolean canInsertItem(int index, ItemStack itemStackIn, EnumFacing direction) {
        // Can insert if INPUT or BOTH mode
        return isItemValidForSlot(index, itemStackIn);
    }

    @Override
    public boolean canExtractItem(int index, ItemStack stack, EnumFacing direction) {
        // Can extract if OUTPUT or BOTH mode
        return mode == ItemPortMode.OUTPUT || mode == ItemPortMode.BOTH;
    }

    // --- NBT & Network ---
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        writeSyncableDataToNBT(compound); // Include sync data in main save
        ItemStackHelper.saveAllItems(compound, this.inventory);
        if (this.customName != null) {
            compound.setString("CustomName", this.customName);
        }
        return compound;
    }

    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        readSyncableDataFromNBT(compound);
        this.inventory = NonNullList.<ItemStack>withSize(this.getSizeInventory(), ItemStack.EMPTY);
        ItemStackHelper.loadAllItems(compound, this.inventory);
        if (compound.hasKey("CustomName", 8)) {
            this.customName = compound.getString("CustomName");
        }
    }

    private NBTTagCompound writeSyncableDataToNBT(NBTTagCompound compound) {
        compound.setInteger("Mode", mode.ordinal());
        compound.setBoolean("IsFormed", isFormed);
        if (controllerPos != null) {
            // Store controller position as long for NBT
            compound.setLong("ControllerPos", controllerPos.toLong());
        }
        return compound;
    }

    private void readSyncableDataFromNBT(NBTTagCompound compound) {
        mode = ItemPortMode.values()[compound.getInteger("Mode")];
        isFormed = compound.getBoolean("IsFormed");
        if (compound.hasKey("ControllerPos")) {
            // Read controller position from long
            controllerPos = BlockPos.fromLong(compound.getLong("ControllerPos"));
        } else {
            controllerPos = null;
        }
        // Clear controller reference on load, it will be re-established by getController() or onMachineLoaded()
        this.controller = null;
    }

    @Override
    @Nullable
    public SPacketUpdateTileEntity getUpdatePacket() {
        NBTTagCompound nbtTag = new NBTTagCompound();
        writeSyncableDataToNBT(nbtTag);
        return new SPacketUpdateTileEntity(this.pos, 2, nbtTag); // Use different desc packet id
    }

    @Override
    public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
        readSyncableDataFromNBT(pkt.getNbtCompound());
        world.markBlockRangeForRenderUpdate(pos, pos);
    }

    @Override
    public NBTTagCompound getUpdateTag() {
        return writeToNBT(new NBTTagCompound());
    }

    @Override
    public void handleUpdateTag(NBTTagCompound tag) {
        this.readFromNBT(tag);
    }

    // --- IWorldNameable Implementation (for GUI title) ---
    @Override
    public String getName() {
        return this.hasCustomName() ? this.customName : "container.icwth.item_port"; // Default name key
    }

    @Override
    public boolean hasCustomName() {
        return this.customName != null && !this.customName.isEmpty();
    }

    public void setCustomName(String name) {
        this.customName = name;
    }

    @Override
    public ITextComponent getDisplayName() {
        return this.hasCustomName() ? new TextComponentString(this.getName()) : new TextComponentTranslation(this.getName());
    }

    // --- Capabilities ---
    @Override
    public boolean hasCapability(Capability<?> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY || super.hasCapability(capability, facing);
    }

    @SuppressWarnings("unchecked")
    @Nullable
    @Override
    public <T> T getCapability(Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            if (facing == null) {
                return (T) handlerSide; // Default to side handler if facing is null
            }
            switch (facing) {
                case DOWN: return (T) handlerBottom;
                case UP: return (T) handlerTop;
                default: return (T) handlerSide;
            }
        }
        return super.getCapability(capability, facing);
    }

    // Method for GUI to get mode
    public ItemPortMode getMode() {
        return mode;
    }
}