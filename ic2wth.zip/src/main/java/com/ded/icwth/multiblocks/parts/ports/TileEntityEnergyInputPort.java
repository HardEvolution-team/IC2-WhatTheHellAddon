package com.ded.icwth.multiblocks.parts.ports;

import com.ded.icwth.api.multiblock.AbstractMultiblockController;
import com.ded.icwth.api.multiblock.TileEntityMultiblockPart;
import ic2.api.energy.EnergyNet;
import ic2.api.energy.tile.IEnergyEmitter;
import ic2.api.energy.tile.IEnergySink;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraftforge.fml.common.FMLCommonHandler;

import javax.annotation.Nullable;

public class TileEntityEnergyInputPort extends TileEntityMultiblockPart implements IEnergySink, ITickable {

    private boolean addedToEnergyNet = false;
    private static final int MAX_TIER = Integer.MAX_VALUE; // Accept any tier
    private static final double MAX_INPUT = Double.MAX_VALUE; // Accept any input amount (practically limited by tier/packet size)

    public TileEntityEnergyInputPort() {
        super();
    }

    // --- EnergyNet Handling ---
    private void addToEnergyNet() {
        if (world != null && !world.isRemote && !addedToEnergyNet && isConnected()) {
            // Ensure the tile is loaded and the chunk is active before adding
            if (world.isBlockLoaded(pos) && world.getChunk(pos).isLoaded()) {
                EnergyNet.instance.addTile(this);
                addedToEnergyNet = true;
            }
        }
    }

    private void removeFromEnergyNet() {
        if (world != null && !world.isRemote && addedToEnergyNet) {
            EnergyNet.instance.removeTile(this);
            addedToEnergyNet = false;
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        // Defer adding to EnergyNet until onMachineLoaded/Resumed or if loaded state is formed
        if (isFormed() && world != null && !world.isRemote) {
            // Use scheduled task to ensure EnergyNet is ready
            FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(this::addToEnergyNet);
        }
    }


    @Override
    public void invalidate() {
        super.invalidate();
        removeFromEnergyNet();
    }

    @Override
    public void onChunkUnload() {
        super.onChunkUnload();
        removeFromEnergyNet(); // Ensure removal on unload
    }

    // --- IMultiblockPart Overrides ---
    @Override
    public void onAttached(AbstractMultiblockController newController) {
        super.onAttached(newController);
        addToEnergyNet();
    }

    @Override
    public void onDetached(AbstractMultiblockController oldController) {
        super.onDetached(oldController);
        removeFromEnergyNet();
    }

    @Override
    public void onMachineAssembled(AbstractMultiblockController controller) {
        super.onMachineAssembled(controller);
        addToEnergyNet();
    }

    @Override
    public void onMachineBroken() {
        super.onMachineBroken();
        removeFromEnergyNet();
    }

    @Override
    public void onMachineLoaded(AbstractMultiblockController controller) {
        super.onMachineLoaded(controller);
        // Use scheduled task for safety on load
        if (world != null && !world.isRemote) {
            FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(this::addToEnergyNet);
        }
    }

    // --- ITickable Implementation ---
    @Override
    public void update() {
        // No ticking logic needed for a simple input port that directly injects into controller
        // Ensure it's added to the network if needed
        if (!world.isRemote && !addedToEnergyNet && isConnected()) {
            addToEnergyNet();
        }
    }

    // --- IEnergySink Implementation (Receiving Energy from Network) ---

    @Override
    public double getDemandedEnergy() {
        if (!isConnected() || getController() == null) {
            return 0; // Cannot demand if not connected
        }
        // Check if the controller itself is an IEnergySink
        TileEntity controllerTE = getController().getWorld().getTileEntity(getController().getPos());
        if (controllerTE instanceof IEnergySink) {
            // Demand what the controller demands, up to our max input capability
            return Math.min(((IEnergySink) controllerTE).getDemandedEnergy(), MAX_INPUT);
        }
        return 0; // Controller cannot accept energy
    }

    @Override
    public int getSinkTier() {
        // Accept energy of any tier
        return MAX_TIER;
    }

    @Override
    public double injectEnergy(EnumFacing directionFrom, double amount, double voltage) {
        if (!isConnected() || getController() == null) {
            return amount; // Cannot accept energy if not connected
        }

        // Try to inject directly into the controller
        TileEntity controllerTE = getController().getWorld().getTileEntity(getController().getPos());
        if (controllerTE instanceof IEnergySink) {
            IEnergySink controllerSink = (IEnergySink) controllerTE;

            // Check if the controller can accept the voltage
            if (voltage > EnergyNet.instance.getPowerFromTier(controllerSink.getSinkTier())) {
                 // Let the controller handle overvoltage if it wants, or just reject here?
                 // For simplicity, let's assume the controller handles its own tier checks.
                 // If we wanted the *port* to explode on overvoltage *for the controller*, we'd check here.
                 // return amount; // Reject if voltage is too high for the controller (optional)
            }

            // Inject into the controller, passing the original direction and voltage
            return controllerSink.injectEnergy(directionFrom, amount, voltage);
        } else {
            return amount; // Controller cannot accept energy
        }
    }

    @Override
    public boolean acceptsEnergyFrom(IEnergyEmitter emitter, EnumFacing side) {
        // Accept from any side if connected
        return isConnected();
    }

    // --- NBT & Network --- (Only need basic sync from TileEntityMultiblockPart)
    // No extra data to save/sync for this simple port

}

