package com.ded.icwth.multiblocks.dirtcube;

import com.ded.icwth.api.multiblock.AbstractMultiblockController;
import com.ded.icwth.api.multiblock.IMultiblockPart;
import com.ded.icwth.multiblocks.parts.ports.TileEntityFluidInputPort;
import com.ded.icwth.multiblocks.parts.ports.TileEntityFluidOutputPort;
import com.ded.icwth.multiblocks.parts.ports.TileEntityItemInputPort;
import com.ded.icwth.multiblocks.parts.ports.TileEntityItemOutputPort;
import com.ded.icwth.recipes.dirtcube.DirtCubeRecipe;
import com.ded.icwth.recipes.dirtcube.DirtCubeRecipeRegistry;
import ic2.api.energy.EnergyNet;
import ic2.api.energy.event.EnergyTileLoadEvent;
import ic2.api.energy.event.EnergyTileUnloadEvent;
import ic2.api.energy.tile.IEnergyAcceptor;
import ic2.api.energy.tile.IEnergyEmitter;
import ic2.api.energy.tile.IEnergySink;
import ic2.api.energy.tile.IEnergySource;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidTank;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.IFluidTankProperties;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class TileDirtCubeController extends AbstractMultiblockController implements ITickable, IEnergySink, IEnergySource, IFluidHandler {

    public static final String MULTIBLOCK_ID = "dirt_processor_cube";

    // Energy
    private double energy = 0;
    private final double maxStorage = 10000000; // 10M EU
    private final int tier = 5; // Example: EV tier for controller internal buffer
    private final double output = 8192; // Example: EV output rate (if used)
    private boolean addedToEnergyNet = false;

    // Items (Internal buffers for crafting logic)
    private final ItemStackHandler inputInventory = new ItemStackHandler(3);
    private final ItemStackHandler outputInventory = new ItemStackHandler(3);

    // Fluids (Internal tanks)
    private final FluidTank inputTank = new FluidTank(Fluid.BUCKET_VOLUME * 16);
    private final FluidTank outputTank = new FluidTank(Fluid.BUCKET_VOLUME * 16);

    // Crafting
    private int progress = 0;
    private int maxProgress = 0; // Set by current recipe
    private double energyPerTick = 0; // Set by current recipe
    @Nullable
    private DirtCubeRecipe currentRecipe = null;

    public TileDirtCubeController() {
        inputTank.setTileEntity(this);
        outputTank.setTileEntity(this);
    }

    // --- AbstractMultiblockController Implementation ---
    @Nonnull
    @Override
    public String getStructureDefinitionId() {
        return MULTIBLOCK_ID;
    }

    @Override
    public boolean onAssemble() {
        FMLLog.log.info("Dirt Cube Assembled at {}!", getPos());
        // Add to EnergyNet on assembly
        addToEnergyNet();
        markDirty();
        return true;
    }

    @Override
    public void onDisassemble() {
        FMLLog.log.info("Dirt Cube Disassembled at {}!", getPos());
        // Remove from EnergyNet on disassembly
        unloadFromEnergyNet();
        currentRecipe = null;
        progress = 0;
        maxProgress = 0;
        energyPerTick = 0;
        markDirty();
    }

    @Override
    public void updateServer() {
        // Main logic is in ITickable.update().
    }

    @Override
    public void onMachineStateChanged() {
        // Called when processing starts/stops.
        markDirty();
        // Update block state for visuals if needed
        // world.notifyBlockUpdate(pos, world.getBlockState(pos), world.getBlockState(pos), 3);
    }
    // --- End AbstractMultiblockController Implementation ---

    // ITickable update method - handles main server logic
    @Override
    public void update() {
        if (world == null || world.isRemote) {
            return;
        }

        // Ensure added to energy net if assembled
        if (isAssembled() && !addedToEnergyNet) {
            addToEnergyNet();
        }

        boolean needsMarkDirty = false;
        boolean wasProcessing = progress > 0;

        if (isAssembled()) {
            // --- Port Interaction --- (Do this every tick)
            needsMarkDirty |= handlePortInteractions();

            // --- Crafting Logic ---
            if (currentRecipe == null) {
                // Try to find a new recipe only if not currently crafting
                currentRecipe = DirtCubeRecipeRegistry.findMatchingRecipe(inputInventory);
                if (currentRecipe != null) {
                    maxProgress = currentRecipe.getDurationTicks();
                    energyPerTick = currentRecipe.getEnergyPerTick();
                    progress = 0;
                    needsMarkDirty = true;
                    FMLLog.log.debug("Found recipe for Dirt Cube: {}", currentRecipe.getOutput().getDisplayName());
                }
            }

            if (currentRecipe != null) {
                if (canCraft(currentRecipe)) {
                    if (energy >= energyPerTick) {
                        energy -= energyPerTick;
                        progress++;
                        needsMarkDirty = true;

                        if (progress >= maxProgress) {
                            craftItem(currentRecipe);
                            // Recipe finished, clear state for next check
                            currentRecipe = null;
                            progress = 0;
                            maxProgress = 0;
                            energyPerTick = 0;
                            FMLLog.log.debug("Dirt Cube finished crafting.");
                        }
                    } // else: Not enough energy, pause progress
                } else {
                    // Cannot craft (e.g., output full), reset progress if it was running
                    if (progress > 0) {
                        progress = 0;
                        // Don't clear currentRecipe, maybe output will clear next tick
                        needsMarkDirty = true;
                        FMLLog.log.debug("Dirt Cube crafting paused (cannot craft).");
                    }
                }
            } else {
                // No recipe currently active, ensure progress is 0
                if (progress > 0) {
                    progress = 0;
                    maxProgress = 0;
                    energyPerTick = 0;
                    needsMarkDirty = true;
                }
            }

        } else { // Not assembled
            // Reset crafting state if structure is broken
            if (currentRecipe != null || progress > 0) {
                currentRecipe = null;
                progress = 0;
                maxProgress = 0;
                energyPerTick = 0;
                needsMarkDirty = true;
            }
        }

        // Check if processing state changed
        boolean isProcessing = progress > 0;
        if (wasProcessing != isProcessing) {
            onMachineStateChanged(); // Calls markDirty internally
            needsMarkDirty = false; // Already marked dirty by onMachineStateChanged
        }

        if (needsMarkDirty) {
            markDirty();
        }
    }

    private boolean handlePortInteractions() {
        boolean changed = false;
        // Use the connectedParts field from the base class
        if (connectedParts == null || connectedParts.isEmpty()) return false;

        // Iterate through the BlockPos of connected parts
        for (BlockPos partPos : connectedParts) {
            // Get the TileEntity at the part's position
            TileEntity te = world.getTileEntity(partPos);
            if (te == null) continue; // Skip if TE is missing (shouldn't happen in a valid structure)

            // Check if the TileEntity is an IMultiblockPart (it should be)
            if (!(te instanceof IMultiblockPart)) continue;

            // --- Item Input Port --- (Pull from port to internal input buffer)
            if (te instanceof TileEntityItemInputPort) {
                IItemHandler portHandler = te.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
                if (portHandler != null) {
                    for (int i = 0; i < portHandler.getSlots(); i++) {
                        ItemStack stackInPort = portHandler.getStackInSlot(i);
                        if (!stackInPort.isEmpty()) {
                            ItemStack remaining = ItemHandlerHelper.insertItemStacked(inputInventory, stackInPort, false);
                            // If insertion was successful (partially or fully), update the port's inventory
                            if (remaining.getCount() < stackInPort.getCount()) {
                                // We need to extract the difference from the port
                                portHandler.extractItem(i, stackInPort.getCount() - remaining.getCount(), false);
                                changed = true;
                                // break; // Optional: Only pull one stack type per tick?
                            }
                        }
                    }
                }
            }
            // --- Item Output Port --- (Push from internal output buffer to port)
            else if (te instanceof TileEntityItemOutputPort) {
                IItemHandler portHandler = te.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
                if (portHandler != null) {
                    for (int i = 0; i < outputInventory.getSlots(); i++) {
                        ItemStack stackInOutput = outputInventory.getStackInSlot(i);
                        if (!stackInOutput.isEmpty()) {
                            ItemStack remaining = ItemHandlerHelper.insertItemStacked(portHandler, stackInOutput, false);
                            // Update our internal output buffer with the remainder
                            if (remaining.getCount() < stackInOutput.getCount()) {
                                outputInventory.setStackInSlot(i, remaining);
                                changed = true;
                                // break; // Optional: Only push one stack type per tick?
                            }
                        }
                    }
                }
            }
            // --- Fluid Input Port --- (Pull from port to internal input tank)
            else if (te instanceof TileEntityFluidInputPort) {
                IFluidHandler portHandler = te.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null);
                if (portHandler != null && inputTank.getFluidAmount() < inputTank.getCapacity()) {
                    int space = inputTank.getCapacity() - inputTank.getFluidAmount();
                    // Try draining from port
                    FluidStack drained = portHandler.drain(space, false); // Simulate drain
                    if (drained != null && drained.amount > 0) {
                        // Check if we can fill it
                        int filledSim = inputTank.fill(drained, false);
                        if (filledSim > 0) {
                            // Actually drain and fill
                            FluidStack actuallyDrained = portHandler.drain(filledSim, true);
                            if (actuallyDrained != null && actuallyDrained.amount > 0) {
                                inputTank.fill(actuallyDrained, true);
                                changed = true;
                                // break; // Optional: Only pull one fluid type per tick?
                            }
                        }
                    }
                }
            }
            // --- Fluid Output Port --- (Push from internal output tank to port)
            else if (te instanceof TileEntityFluidOutputPort) {
                IFluidHandler portHandler = te.getCapability(CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY, null);
                if (portHandler != null && outputTank.getFluidAmount() > 0) {
                    FluidStack fluidInOutTank = outputTank.getFluid();
                    // Try filling the port
                    int filled = portHandler.fill(fluidInOutTank, false); // Simulate fill
                    if (filled > 0) {
                        // Actually drain from output tank and fill port
                        FluidStack actuallyDrained = outputTank.drain(filled, true);
                        if (actuallyDrained != null && actuallyDrained.amount > 0) {
                            portHandler.fill(actuallyDrained, true);
                            changed = true;
                            // break; // Optional: Only push one fluid type per tick?
                        }
                    }
                }
            }
            // Energy Input Port is handled by the port itself injecting into us (IEnergySink)
        }
        return changed;
    }

    private boolean canCraft(@Nonnull DirtCubeRecipe recipe) {
        if (energy < energyPerTick) return false;
        // Check if inputs match (already done by findMatchingRecipe, but double check counts?)
        if (!recipe.matches(inputInventory)) return false; // Check again in case items were removed

        // Check if output has space
        ItemStack result = recipe.getOutput();
        ItemStack remaining = ItemHandlerHelper.insertItemStacked(outputInventory, result, true); // Simulate insert
        return remaining.isEmpty(); // Can craft if simulation shows full insertion is possible
    }

    private void craftItem(@Nonnull DirtCubeRecipe recipe) {
        consumeInputs(recipe.getInputs());
        ItemStack result = recipe.getOutput();
        ItemHandlerHelper.insertItemStacked(outputInventory, result, false); // Actual insert
        markDirty();
    }

    private void consumeInputs(List<Ingredient> inputs) {
        // Basic consumption - assumes recipe.matches already confirmed quantities
        // TODO: Handle recipes needing >1 of an ingredient or different counts
        for (Ingredient ingredient : inputs) {
            int needed = 1; // Assuming 1 for now, recipe should specify count
            for (int i = 0; i < inputInventory.getSlots(); i++) {
                ItemStack stackInSlot = inputInventory.getStackInSlot(i);
                if (ingredient.apply(stackInSlot)) {
                    inputInventory.extractItem(i, needed, false);
                    break; // Consume only one stack matching the ingredient
                }
            }
        }
    }

    // --- EnergyNet Handling ---
    private void addToEnergyNet() {
        if (!addedToEnergyNet && world != null && !world.isRemote) {
            // Post event to add to network
            MinecraftForge.EVENT_BUS.post(new EnergyTileLoadEvent(this));
            addedToEnergyNet = true;
            FMLLog.log.debug("Added Dirt Cube Controller to EnergyNet");
        }
    }

    private void unloadFromEnergyNet() {
        if (addedToEnergyNet && world != null && !world.isRemote) {
            MinecraftForge.EVENT_BUS.post(new EnergyTileUnloadEvent(this));
            addedToEnergyNet = false;
            FMLLog.log.debug("Removed Dirt Cube Controller from EnergyNet");
        }
    }

    @Override
    public void invalidate() {
        super.invalidate();
        unloadFromEnergyNet();
    }

    @Override
    public void onChunkUnload() {
        super.onChunkUnload();
        unloadFromEnergyNet();
    }

    // --- IEnergySink ---
    @Override
    public double getDemandedEnergy() {
        if (!isAssembled()) return 0;
        // Demand energy needed for internal buffer
        return Math.max(0, maxStorage - energy);
    }

    @Override
    public int getSinkTier() {
        // Controller's internal buffer tier
        return tier;
    }

    @Override
    public double injectEnergy(EnumFacing directionFrom, double amount, double voltage) {
        if (!isAssembled()) return amount; // Cannot accept if not formed

        // Check voltage against controller's tier
        if (voltage > EnergyNet.instance.getPowerFromTier(tier)) {
            // Optional: Explode controller on overvoltage?
            // world.createExplosion(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 1.0f, true);
            // invalidate();
            return amount; // Reject energy if voltage too high
        }

        double accepted = Math.min(amount, maxStorage - energy);
        energy += accepted;
        markDirty();
        return amount - accepted; // Return unaccepted amount
    }

    @Override
    public boolean acceptsEnergyFrom(IEnergyEmitter emitter, EnumFacing side) {
        // Accept energy only if assembled
        return isAssembled();
    }

    // --- IEnergySource --- (Optional, if controller provides power)
    @Override
    public double getOfferedEnergy() {
        // Only offer energy if assembled and has stored energy
        if (!isAssembled() || energy <= 0) return 0;
        // Offer up to the defined output rate
        return Math.min(energy, output);
    }

    @Override
    public void drawEnergy(double amount) {
        if (!isAssembled()) return;
        energy = Math.max(0, energy - amount);
        markDirty();
    }

    @Override
    public int getSourceTier() {
        // Tier at which the controller outputs energy
        return tier;
    }

    @Override
    public boolean emitsEnergyTo(IEnergyAcceptor receiver, EnumFacing side) {
        // Allow output only if assembled (and maybe only from specific sides?)
        // Currently false as no energy output port was requested.
        return false;
    }

    // --- IFluidHandler --- (For internal tanks)
    @Override
    public IFluidTankProperties[] getTankProperties() {
        // Expose both input and output tank properties? Or just one combined?
        // Let's expose both for now, maybe useful for inspection.
        return new IFluidTankProperties[]{inputTank.getTankProperties()[0], outputTank.getTankProperties()[0]};
    }

    @Override
    public int fill(FluidStack resource, boolean doFill) {
        // Allow filling the input tank (e.g., manually with buckets?)
        int filled = inputTank.fill(resource, doFill);
        if (filled > 0 && doFill) markDirty();
        return filled;
    }

    @Nullable
    @Override
    public FluidStack drain(FluidStack resource, boolean doDrain) {
        // Allow draining from the output tank
        FluidStack drained = outputTank.drain(resource, doDrain);
        if (drained != null && drained.amount > 0 && doDrain) markDirty();
        return drained;
    }

    @Nullable
    @Override
    public FluidStack drain(int maxDrain, boolean doDrain) {
        // Allow draining from the output tank
        FluidStack drained = outputTank.drain(maxDrain, doDrain);
        if (drained != null && drained.amount > 0 && doDrain) markDirty();
        return drained;
    }

    // --- Capabilities --- (Expose internal handlers/tanks)
    @Override
    public boolean hasCapability(@Nonnull Capability<?> capability, @Nullable EnumFacing facing) {
        return capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY
            || capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY
            || super.hasCapability(capability, facing);
    }

    @SuppressWarnings("unchecked")
    @Nullable
    @Override
    public <T> T getCapability(@Nonnull Capability<T> capability, @Nullable EnumFacing facing) {
        if (capability == CapabilityItemHandler.ITEM_HANDLER_CAPABILITY) {
            // Which handler to expose? Input, Output, or combined?
            // Let's expose input for now for recipe checking/insertion?
            // Or maybe no external item access directly to controller?
            // Let's NOT expose item handler directly, force use of ports.
            // return (T) inputInventory; // Or outputInventory, or a combined wrapper
            return null; // Force interaction via ports
        } else if (capability == CapabilityFluidHandler.FLUID_HANDLER_CAPABILITY) {
            // Expose the controller itself as the fluid handler for its internal tanks
            return (T) this;
        }
        return super.getCapability(capability, facing);
    }

    // --- NBT Saving/Loading ---
    @Override
    public void readFromNBT(NBTTagCompound compound) {
        super.readFromNBT(compound);
        energy = compound.getDouble("Energy");
        inputInventory.deserializeNBT(compound.getCompoundTag("InputInventory"));
        outputInventory.deserializeNBT(compound.getCompoundTag("OutputInventory"));
        inputTank.readFromNBT(compound.getCompoundTag("InputTank"));
        outputTank.readFromNBT(compound.getCompoundTag("OutputTank"));
        progress = compound.getInteger("Progress");
        // Re-validate recipe on load
        if (progress > 0) {
            maxProgress = compound.getInteger("MaxProgress");
            energyPerTick = compound.getDouble("EnergyPerTick");
            currentRecipe = DirtCubeRecipeRegistry.findMatchingRecipe(inputInventory); // Re-find recipe
            // If recipe not found or doesn't match saved state, reset progress
            if (currentRecipe == null || currentRecipe.getDurationTicks() != maxProgress || currentRecipe.getEnergyPerTick() != energyPerTick) {
                progress = 0;
                maxProgress = 0;
                energyPerTick = 0;
                currentRecipe = null;
            }
        } else {
            currentRecipe = null;
            maxProgress = 0;
            energyPerTick = 0;
        }
        // Re-link tanks
        inputTank.setTileEntity(this);
        outputTank.setTileEntity(this);
    }

    @Nonnull
    @Override
    public NBTTagCompound writeToNBT(NBTTagCompound compound) {
        super.writeToNBT(compound);
        compound.setDouble("Energy", energy);
        compound.setTag("InputInventory", inputInventory.serializeNBT());
        compound.setTag("OutputInventory", outputInventory.serializeNBT());
        compound.setTag("InputTank", inputTank.writeToNBT(new NBTTagCompound()));
        compound.setTag("OutputTank", outputTank.writeToNBT(new NBTTagCompound()));
        compound.setInteger("Progress", progress);
        compound.setInteger("MaxProgress", maxProgress); // Save maxProgress
        compound.setDouble("EnergyPerTick", energyPerTick); // Save energyPerTick
        return compound;
    }

    // --- Getters for GUI/Interaction ---
    public ItemStackHandler getInputInventory() {
        return inputInventory;
    }

    public ItemStackHandler getOutputInventory() {
        return outputInventory;
    }

    public FluidTank getInputTank() {
        return inputTank;
    }

    public FluidTank getOutputTank() {
        return outputTank;
    }

    public double getEnergy() {
        return energy;
    }

    public double getMaxStorage() {
        return maxStorage;
    }

    public int getProgress() {
        return progress;
    }

    public int getMaxProgress() {
        // Return maxProgress from the current recipe if active
        return currentRecipe != null ? maxProgress : 0;
    }
}

