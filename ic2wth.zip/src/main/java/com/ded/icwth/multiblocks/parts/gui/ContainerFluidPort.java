package com.ded.icwth.multiblocks.parts.gui; // Assuming a gui subpackage

import com.ded.icwth.multiblocks.parts.TileFluidPort;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.*; // Import InventoryHelper
import net.minecraft.item.ItemStack;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fluids.capability.CapabilityFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandlerItem;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.SlotItemHandler;

import javax.annotation.Nonnull;

public class ContainerFluidPort extends Container {

    private final TileFluidPort tileEntity;
    private final ItemStackHandler fluidItemSlots = new ItemStackHandler(2); // 0: Input slot, 1: Output slot

    // Cached values for client sync
    private int cachedFluidAmount = -1;
    private int cachedTankCapacity = -1;
    private Fluid cachedFluid = null;

    public ContainerFluidPort(InventoryPlayer playerInventory, TileFluidPort tileEntity) {
        this.tileEntity = tileEntity;

        // Add fluid container slots (e.g., for buckets)
        // Input slot (for filling the tank)
        this.addSlotToContainer(new SlotItemHandler(fluidItemSlots, 0, 44, 35) { // Adjust coords as needed
            @Override
            public boolean isItemValid(@Nonnull ItemStack stack) {
                // Allow items that can provide fluid (e.g., filled buckets)
                return stack.hasCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY, null);
            }
        });
        // Output slot (for draining the tank)
        this.addSlotToContainer(new SlotItemHandler(fluidItemSlots, 1, 116, 35) { // Adjust coords as needed
             @Override
             public boolean isItemValid(@Nonnull ItemStack stack) {
                 // Allow items that can accept fluid (e.g., empty buckets)
                 // Prevent automation from inserting non-empty containers here
                 IFluidHandlerItem handler = stack.getCapability(CapabilityFluidHandler.FLUID_HANDLER_ITEM_CAPABILITY, null);
                 return handler != null && handler.drain(Integer.MAX_VALUE, false) == null; // Only allow if empty
             }
             @Override
             public ItemStack getStack() {
                 // Prevent automation from inserting into output slot?
                 return super.getStack();
             }
             @Override
             public boolean canTakeStack(EntityPlayer playerIn) {
                 return true; // Allow player to take output
             }
        });

        // Player Inventory Slots
        int playerInvY = 84;
        int playerInvX = 8;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlotToContainer(new Slot(playerInventory, j + i * 9 + 9, playerInvX + j * 18, playerInvY + i * 18));
            }
        }

        // Player Hotbar Slots
        int hotbarY = 142;
        for (int k = 0; k < 9; ++k) {
            this.addSlotToContainer(new Slot(playerInventory, k, playerInvX + k * 18, hotbarY));
        }
    }

    @Override
    public void detectAndSendChanges() {
        super.detectAndSendChanges();

        // Sync fluid tank data to client
        FluidStack currentFluid = tileEntity.getTank().getFluid();
        int currentAmount = currentFluid != null ? currentFluid.amount : 0;
        Fluid fluidType = currentFluid != null ? currentFluid.getFluid() : null;
        int currentCapacity = tileEntity.getTank().getCapacity();

        for (IContainerListener listener : this.listeners) {
            if (this.cachedFluidAmount != currentAmount || this.cachedFluid != fluidType) {
                // Send fluid type and amount (more complex sync needed for full FluidStack NBT)
                // For simplicity, sending amount and a fluid ID (if fluids are registered)
                // A more robust method uses custom packets or syncs the full NBT
                listener.sendWindowProperty(this, 0, currentAmount); // Property 0: Amount
                // Property 1: Fluid ID (requires a registry mapping or sending name)
                // listener.sendWindowProperty(this, 1, getFluidId(fluidType));
            }
            if (this.cachedTankCapacity != currentCapacity) {
                 listener.sendWindowProperty(this, 2, currentCapacity); // Property 2: Capacity
            }
        }

        this.cachedFluidAmount = currentAmount;
        this.cachedFluid = fluidType;
        this.cachedTankCapacity = currentCapacity;
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void updateProgressBar(int id, int data) {
        // Called on client to update based on detectAndSendChanges
        switch (id) {
            case 0: // Amount
                FluidStack current = tileEntity.getTank().getFluid();
                if (current != null) {
                    current.amount = data;
                } else if (data > 0 && cachedFluid != null) {
                    // If amount > 0 but tank was empty, try to reconstruct based on cached fluid type
                    // This part is tricky without proper fluid type sync
                    tileEntity.getTank().setFluid(new FluidStack(cachedFluid, data));
                } else if (data == 0 && current != null) {
                    // Amount is zero, clear the tank
                    tileEntity.getTank().setFluid(null);
                }
                break;
            case 1: // Fluid ID (requires client-side mapping)
                // Fluid fluid = getFluidById(data);
                // this.cachedFluid = fluid; // Update cached fluid type
                // Update tank fluid type if amount > 0
                break;
            case 2: // Capacity
                tileEntity.getTank().setCapacity(data);
                break;
        }
    }

    @Override
    public boolean canInteractWith(EntityPlayer playerIn) {
        return this.tileEntity.isUsableByPlayer(playerIn);
    }

    @Override
    public ItemStack transferStackInSlot(EntityPlayer playerIn, int index) {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = this.inventorySlots.get(index);

        if (slot != null && slot.getHasStack()) {
            ItemStack stackInSlot = slot.getStack();
            itemstack = stackInSlot.copy();

            int fluidSlots = 2;
            int playerInvStart = fluidSlots;
            int playerInvEnd = fluidSlots + 36;

            if (index < fluidSlots) {
                // --- Transfer from Fluid Slots to Player Inventory ---
                if (!this.mergeItemStack(stackInSlot, playerInvStart, playerInvEnd, true)) {
                    return ItemStack.EMPTY;
                }
                slot.onSlotChange(stackInSlot, itemstack);
            } else {
                // --- Transfer from Player Inventory to Fluid Slots ---
                ItemStack stackToProcess = stackInSlot.copy(); // Work with a copy
                stackToProcess.setCount(1); // Process one item at a time for fluid handlers

                IFluidHandlerItem handlerItem = FluidUtil.getFluidHandler(stackToProcess);
                boolean mergedToFluidSlot = false;

                if (handlerItem != null) {
                    // Try filling the tank (Slot 0)
                    FluidStack containedFluid = handlerItem.drain(Integer.MAX_VALUE, false);
                    if (containedFluid != null && containedFluid.amount > 0) {
                        if (tileEntity.fill(containedFluid, false) > 0) { // Check if tank can accept
                            if (this.mergeItemStack(stackInSlot, 0, 1, false)) { // Try merge to input slot
                                mergedToFluidSlot = true;
                            }
                        }
                    }

                    // Try draining the tank (Slot 1) - only if not already merged to input
                    if (!mergedToFluidSlot) {
                        FluidStack tankFluid = tileEntity.getTank().getFluid();
                        if (tankFluid != null && tankFluid.amount > 0) {
                            if (handlerItem.fill(tankFluid, false) > 0) { // Check if item can accept
                                if (this.mergeItemStack(stackInSlot, 1, 2, false)) { // Try merge to output slot
                                    mergedToFluidSlot = true;
                                }
                            }
                        }
                    }
                }

                // If not handled by fluid slots, merge within player inventory
                if (!mergedToFluidSlot) {
                    if (index >= playerInvStart && index < playerInvStart + 27) { // Main inventory
                        if (!this.mergeItemStack(stackInSlot, playerInvStart + 27, playerInvEnd, false)) {
                            return ItemStack.EMPTY;
                        }
                    } else if (index >= playerInvStart + 27 && index < playerInvEnd) { // Hotbar
                        if (!this.mergeItemStack(stackInSlot, playerInvStart, playerInvStart + 27, false)) {
                            return ItemStack.EMPTY;
                        }
                    }
                }
            }

            if (stackInSlot.isEmpty()) {
                slot.putStack(ItemStack.EMPTY);
            } else {
                slot.onSlotChanged();
            }

            if (stackInSlot.getCount() == itemstack.getCount()) {
                return ItemStack.EMPTY;
            }

            slot.onTake(playerIn, stackInSlot);
        }

        return itemstack;
    }

    // Handle fluid item interactions when slots are clicked
    @Override
    public void onContainerClosed(EntityPlayer playerIn) {
        super.onContainerClosed(playerIn);
        // Drop items in the temporary fluid slots when GUI is closed
        // Replace ItemHandlerHelper.dropInventoryItems
        if (!playerIn.world.isRemote) { // Ensure server side
            for (int i = 0; i < fluidItemSlots.getSlots(); ++i) {
                ItemStack itemstack = fluidItemSlots.getStackInSlot(i);
                if (!itemstack.isEmpty()) {
                    InventoryHelper.spawnItemStack(playerIn.world, tileEntity.getPos().getX(), tileEntity.getPos().getY(), tileEntity.getPos().getZ(), itemstack);
                }
            }
        }
    }

    // Correct return type for slotClick
    @Override
    public ItemStack slotClick(int slotId, int dragType, net.minecraft.inventory.ClickType clickTypeIn, EntityPlayer player) {
        // Handle fluid transfer logic when clicking the fluid slots
        // Using FluidUtil.interactWithFluidHandler might be complex here and relies on player state.
        // It's often better handled by the item's right-click behavior or specific buttons.
        // For basic container functionality, let the superclass handle clicks.
        // If custom logic is needed, ensure it returns the correct ItemStack.

        // Example: If trying to interact with fluid slots, maybe prevent default action?
        // if (slotId == 0 || slotId == 1) {
             // Attempt custom fluid interaction here...
             // If interaction happens, return ItemStack.EMPTY or the cursor stack?
             // return player.inventory.getItemStack(); // Or ItemStack.EMPTY;
        // }

        // Default behavior: let the container handle the click
        return super.slotClick(slotId, dragType, clickTypeIn, player);
    }
}

