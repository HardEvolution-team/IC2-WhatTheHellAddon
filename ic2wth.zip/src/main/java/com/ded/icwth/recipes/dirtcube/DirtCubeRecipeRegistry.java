package com.ded.icwth.recipes.dirtcube;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraftforge.items.IItemHandler;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DirtCubeRecipeRegistry {

    private static final List<DirtCubeRecipe> RECIPES = new ArrayList<>();

    public static void registerRecipes() {
        // Clear existing recipes before adding new ones (important for reloading)
        RECIPES.clear();

        // Example Recipe 1: 64 Dirt -> 1 Diamond (High energy cost, long duration)
        registerRecipe(
                Arrays.asList(Ingredient.fromStacks(new ItemStack(Blocks.DIRT, 64))),
                new ItemStack(Items.DIAMOND, 1),
                10000000, // 10 Million EU
                1200 // 60 seconds (1200 ticks)
        );

        // Example Recipe 2: 16 Cobblestone + 1 Iron Ingot -> 1 Iron Block (Lower cost, shorter duration)
        registerRecipe(
                Arrays.asList(
                        Ingredient.fromStacks(new ItemStack(Blocks.COBBLESTONE, 16)),
                        Ingredient.fromStacks(new ItemStack(Items.IRON_INGOT, 1))
                ),
                new ItemStack(Blocks.IRON_BLOCK, 1),
                50000, // 50k EU
                200 // 10 seconds
        );

        // Add more recipes here...

        System.out.println("Registered " + RECIPES.size() + " Dirt Cube recipes.");
    }

    public static void registerRecipe(List<Ingredient> inputs, ItemStack output, double energyCost, int duration) {
        try {
            DirtCubeRecipe recipe = new DirtCubeRecipe(inputs, output, energyCost, duration);
            RECIPES.add(recipe);
        } catch (IllegalArgumentException e) {
            System.err.println("Failed to register Dirt Cube recipe: " + e.getMessage());
        }
    }

    @Nullable
    public static DirtCubeRecipe findMatchingRecipe(IItemHandler inputInventory) {
        for (DirtCubeRecipe recipe : RECIPES) {
            // TODO: Replace recipe.matches with a more robust check here or within the recipe itself
            // that properly handles stack sizes and avoids consuming items prematurely.
            if (recipe.matches(inputInventory)) { // Use the simplified check for now
                return recipe;
            }
        }
        return null;
    }

    public static List<DirtCubeRecipe> getRecipes() {
        return new ArrayList<>(RECIPES); // Return a copy
    }
}

