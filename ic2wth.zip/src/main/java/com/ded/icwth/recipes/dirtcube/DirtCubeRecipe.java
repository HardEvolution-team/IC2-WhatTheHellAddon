package com.ded.icwth.recipes.dirtcube;

import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraftforge.items.IItemHandler;

import javax.annotation.Nonnull;
import java.util.List;

public class DirtCubeRecipe {

    private final List<Ingredient> inputs; // Use List<Ingredient> for flexibility (OreDict, multiple items)
    private final ItemStack output;
    private final double energyCostTotal; // Total EU required for the craft
    private final int durationTicks; // Duration in ticks

    public DirtCubeRecipe(@Nonnull List<Ingredient> inputs, @Nonnull ItemStack output, double energyCostTotal, int durationTicks) {
        // Basic validation
        if (inputs.isEmpty() || output.isEmpty() || energyCostTotal <= 0 || durationTicks <= 0) {
            throw new IllegalArgumentException("Invalid Dirt Cube Recipe parameters");
        }
        this.inputs = inputs;
        this.output = output;
        this.energyCostTotal = energyCostTotal;
        this.durationTicks = durationTicks;
    }

    @Nonnull
    public List<Ingredient> getInputs() {
        return inputs;
    }

    @Nonnull
    public ItemStack getOutput() {
        // Return a copy to prevent modification
        return output.copy();
    }

    public double getEnergyCostTotal() {
        return energyCostTotal;
    }

    public int getDurationTicks() {
        return durationTicks;
    }

    public double getEnergyPerTick() {
        return energyCostTotal / (double) durationTicks;
    }

    /**
     * Checks if the provided inventory contains the required input ingredients.
     * Note: This is a simplified check. A real implementation needs to handle stack sizes
     * and potentially multiple slots matching the same ingredient.
     *
     * @param inputInventory The inventory to check.
     * @return True if the inventory potentially matches the recipe inputs, false otherwise.
     */
    public boolean matches(IItemHandler inputInventory) {
        // TODO: Implement a robust matching logic that considers stack sizes and avoids using the same stack for multiple ingredients.
        // This basic version just checks if each ingredient finds at least one match.
        int slots = inputInventory.getSlots();
        boolean[] matchedSlots = new boolean[slots]; // Track used slots

        for (Ingredient required : inputs) {
            boolean foundIngredient = false;
            for (int i = 0; i < slots; i++) {
                if (!matchedSlots[i]) {
                    ItemStack stackInSlot = inputInventory.getStackInSlot(i);
                    if (required.apply(stackInSlot)) {
                        // Found a match, mark slot as potentially used (needs refinement for stack sizes)
                        // For now, just mark as found and break inner loop
                        foundIngredient = true;
                        // matchedSlots[i] = true; // Don't mark yet, need size check
                        break; 
                    }
                }
            }
            if (!foundIngredient) {
                return false; // One required ingredient was not found
            }
        }
        // If we reach here, all ingredients have at least one potential match (ignoring stack sizes for now)
        return true; 
    }

    // TODO: Add methods for consuming inputs and checking output space if needed outside the TileEntity.
}

