package com.ded.icwth.init;

import com.ded.icwth.api.multiblock.MultiblockDefinition;
import com.ded.icwth.api.multiblock.MultiblockRegistry;
import com.ded.icwth.api.multiblock.StructurePart;
import com.ded.icwth.blocks.ModBlocks; // Import ModBlocks to access registered blocks
import com.ded.icwth.multiblocks.dirtcube.BlockDirtCubeController; // Import controller block
import com.ded.icwth.multiblocks.dirtcube.TileDirtCubeController; // Import controller tile entity
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.FMLLog;

import java.util.ArrayList;
import java.util.List;

/**
 * Class responsible for defining and registering multiblock structures.
 */
public class ModMultiblocks {

    // Store the definition for potential static access
    public static MultiblockDefinition DIRT_CUBE_DEFINITION;

    public static void registerDefinitions() {
        // Ensure the controller block is registered before getting its state
        // Find the controller block - assuming it's registered in ModBlocks or similar
        // For now, let's assume a block named DIRT_CUBE_CONTROLLER exists in ModBlocks
        // If not, this needs adjustment based on actual registration
        Block dirtCubeControllerBlock = net.minecraftforge.fml.common.registry.ForgeRegistries.BLOCKS.getValue(new net.minecraft.util.ResourceLocation("icwth", BlockDirtCubeController.NAME));

        if (dirtCubeControllerBlock == null || dirtCubeControllerBlock == Blocks.AIR) {
            FMLLog.log.error("Dirt Cube Controller block ('icwth:{}') not found during multiblock registration! Using placeholder.", BlockDirtCubeController.NAME);
            dirtCubeControllerBlock = Blocks.DIAMOND_BLOCK; // Fallback placeholder
        }
        if (ModBlocks.ITEM_INPUT_PORT == null || ModBlocks.ITEM_OUTPUT_PORT == null || ModBlocks.FLUID_INPUT_PORT == null || ModBlocks.FLUID_OUTPUT_PORT == null || ModBlocks.ENERGY_INPUT_PORT == null) {
             FMLLog.log.error("One or more port blocks are null during multiblock registration! Check ModBlocks initialization.");
             // Cannot proceed without port blocks
             return;
        }

        // --- Definition: 5x5x5 Dirt Cube ---
        {
            IBlockState controllerState = dirtCubeControllerBlock.getDefaultState();
            IBlockState casingState = Blocks.DIRT.getDefaultState();
            // Get states for the registered port blocks
            IBlockState itemInputState = ModBlocks.ITEM_INPUT_PORT.getDefaultState();
            IBlockState itemOutputState = ModBlocks.ITEM_OUTPUT_PORT.getDefaultState();
            IBlockState fluidInputState = ModBlocks.FLUID_INPUT_PORT.getDefaultState();
            IBlockState fluidOutputState = ModBlocks.FLUID_OUTPUT_PORT.getDefaultState();
            IBlockState energyInputState = ModBlocks.ENERGY_INPUT_PORT.getDefaultState();

            List<StructurePart> parts = new ArrayList<>();
            BlockPos minPos = BlockPos.ORIGIN; // Relative origin
            BlockPos maxPos = new BlockPos(4, 4, 4);
            BlockPos controllerRelPos = new BlockPos(2, 0, 2); // Controller at bottom center

            // Define port locations (relative to minPos)
            BlockPos itemInputRelPos = new BlockPos(0, 2, 2);   // Left face center
            BlockPos itemOutputRelPos = new BlockPos(4, 2, 2);  // Right face center
            BlockPos fluidInputRelPos = new BlockPos(2, 2, 0);  // Front face center
            BlockPos fluidOutputRelPos = new BlockPos(2, 2, 4); // Back face center
            BlockPos energyInputRelPos = new BlockPos(2, 4, 2); // Top face center

            for (int x = 0; x < 5; x++) {
                for (int y = 0; y < 5; y++) {
                    for (int z = 0; z < 5; z++) {
                        BlockPos relPos = new BlockPos(x, y, z);
                        IBlockState currentState;

                        if (relPos.equals(controllerRelPos)) {
                            currentState = controllerState;
                        } else if (relPos.equals(itemInputRelPos)) {
                            currentState = itemInputState;
                        } else if (relPos.equals(itemOutputRelPos)) {
                            currentState = itemOutputState;
                        } else if (relPos.equals(fluidInputRelPos)) {
                            currentState = fluidInputState;
                        } else if (relPos.equals(fluidOutputRelPos)) {
                            currentState = fluidOutputState;
                        } else if (relPos.equals(energyInputRelPos)) {
                            currentState = energyInputState;
                        } else {
                            // Check if it's an edge/corner/face block - make it dirt
                            boolean isEdgeX = (x == 0 || x == 4);
                            boolean isEdgeY = (y == 0 || y == 4);
                            boolean isEdgeZ = (z == 0 || z == 4);
                            // If it's on the boundary of the 5x5x5 cube, it's casing
                            if (isEdgeX || isEdgeY || isEdgeZ) {
                                currentState = casingState;
                            } else {
                                // Inner blocks (not controller, not ports, not frame) - make them air or keep dirt?
                                // Let's make the frame dirt and the inside air for now.
                                currentState = Blocks.AIR.getDefaultState(); // Inner blocks are air
                            }
                        }

                        // Add the part to the list, skip air blocks
                        if (currentState.getBlock() != Blocks.AIR) {
                            parts.add(new StructurePart(relPos, currentState));
                        }
                    }
                }
            }

            BlockPos dimensions = new BlockPos(maxPos.getX() - minPos.getX() + 1, maxPos.getY() - minPos.getY() + 1, maxPos.getZ() - minPos.getZ() + 1);
            BlockPos controllerOffset = controllerRelPos.subtract(minPos);

            // Get actual ItemStack from the registered controller block
            ItemStack controllerStack = new ItemStack(dirtCubeControllerBlock);

            DIRT_CUBE_DEFINITION = new MultiblockDefinition(
                    TileDirtCubeController.MULTIBLOCK_ID, // Use the MULTIBLOCK_ID defined in TileDirtCubeController
                    controllerStack,
                    parts,
                    controllerOffset,
                    dimensions
            );
            MultiblockRegistry.registerMultiblock(DIRT_CUBE_DEFINITION);
            FMLLog.log.info("Registered Dirt Cube multiblock definition with ID: {}", TileDirtCubeController.MULTIBLOCK_ID); // Use MULTIBLOCK_ID here too
        }
    }
}

