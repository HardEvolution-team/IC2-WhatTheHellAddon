package com.ded.icwth.integration.jei;

import com.ded.icwth.api.multiblock.MultiblockDefinition;
import com.ded.icwth.api.multiblock.StructurePart;
import mezz.jei.api.ingredients.IIngredients;
import mezz.jei.api.recipe.IRecipeWrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextFormatting;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MultiblockStructureWrapper implements IRecipeWrapper {

    private final MultiblockDefinition definition;
    private final MultiblockRendererDrawable rendererDrawable;

    // Define render area constants matching drawInfo
    private static final int RENDER_X = 30;
    private static final int RENDER_Y = 10;
    // Width/Height depend on recipeWidth/Height, calculated dynamically

    public MultiblockStructureWrapper(@Nonnull MultiblockDefinition definition) {
        this.definition = definition;
        this.rendererDrawable = new MultiblockRendererDrawable(definition);
    }

    @Nonnull
    public MultiblockDefinition getDefinition() {
        return definition;
    }

    @Override
    public void getIngredients(@Nonnull IIngredients ingredients) {
        // Set the controller as the primary input/catalyst display
        ingredients.setInput(ItemStack.class, definition.getControllerStack());

        // Group required blocks for informational display
        Map<ItemStack, Integer> requiredBlocks = definition.getParts().stream()
                .map(part -> {
                    // Create ItemStack trying to preserve metadata
                    ItemStack stack = new ItemStack(part.getBlockState().getBlock(), 1, part.getBlockState().getBlock().getMetaFromState(part.getBlockState()));
                    // TODO: Handle potential NBT data if necessary for block identity
                    return stack;
                })
                // Use a custom key or string representation if ItemStacks with different NBT need differentiation
                .collect(Collectors.groupingBy(ItemStack::copy, () -> new NonNullComparableItemStackMap<>(), Collectors.summingInt(ItemStack::getCount)));

        List<ItemStack> blockInputs = new ArrayList<>();
        requiredBlocks.forEach((stack, count) -> {
            ItemStack displayStack = stack.copy();
            displayStack.setCount(count);
            blockInputs.add(displayStack);
        });
        ingredients.setInputs(ItemStack.class, blockInputs);
    }

    @Override
    public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight, int mouseX, int mouseY) {
        // Calculate dynamic render area size
        int renderWidth = recipeWidth - RENDER_X - 10;
        int renderHeight = recipeHeight - RENDER_Y - 10;

        // Delegate rendering the 3D structure
        rendererDrawable.draw(minecraft, RENDER_X, RENDER_Y, renderWidth, renderHeight, mouseX, mouseY);

        // Draw dimensions
        String dimString = String.format("%dx%dx%d", definition.getDimensions().getX(), definition.getDimensions().getY(), definition.getDimensions().getZ());
        minecraft.fontRenderer.drawString(dimString, recipeWidth - minecraft.fontRenderer.getStringWidth(dimString) - 2, 2, 0x404040, false);

        // Tooltips are now handled by getTooltipStrings
    }

    @Nonnull
    @Override
    public List<String> getTooltipStrings(int mouseX, int mouseY) {
        // Assuming recipeWidth and recipeHeight are relatively constant or accessible
        // For simplicity, let's estimate typical values. A better approach might involve caching from drawInfo if possible.
        // Or, JEI might provide width/height context here? Checking JEI API... No, it doesn't.
        // We'll use estimated typical values, might be slightly inaccurate at edges.
        int recipeWidth = 160; // Typical background width from Category
        int recipeHeight = 120; // Typical background height from Category
        int renderWidth = recipeWidth - RENDER_X - 10;
        int renderHeight = recipeHeight - RENDER_Y - 10;

        if (mouseX >= RENDER_X && mouseX < RENDER_X + renderWidth && mouseY >= RENDER_Y && mouseY < RENDER_Y + renderHeight) {
            List<String> tooltip = new ArrayList<>();
            tooltip.add(TextFormatting.GRAY + I18n.format("jei.ic2wth.multiblock_structure.tooltip.rotate"));
            tooltip.add(TextFormatting.GRAY + I18n.format("jei.ic2wth.multiblock_structure.tooltip.zoom"));
            return tooltip;
        }
        return Collections.emptyList();
    }

    // Helper class for Map key comparison if needed (basic example)
    private static class NonNullComparableItemStackMap<V> extends java.util.HashMap<ItemStack, V> {
        @Override
        public V get(Object key) {
            if (!(key instanceof ItemStack)) return null;
            ItemStack stackKey = (ItemStack) key;
            for (Map.Entry<ItemStack, V> entry : entrySet()) {
                if (ItemStack.areItemStacksEqual(entry.getKey(), stackKey)) {
                    return entry.getValue();
                }
            }
            return null;
        }
        // Implement other methods like put, containsKey similarly if needed
    }

    // Call this when JEI closes or resources are reloaded to clean up VBO
    // Maybe needs to be triggered from JEI plugin lifecycle?
    public void dispose() {
        if (rendererDrawable != null) {
            rendererDrawable.dispose();
        }
    }
}

