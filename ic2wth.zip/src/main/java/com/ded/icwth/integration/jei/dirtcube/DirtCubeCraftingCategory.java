package com.ded.icwth.integration.jei.dirtcube;

import com.ded.icwth.Tags;
import com.ded.icwth.recipes.dirtcube.DirtCubeRecipe;
import mezz.jei.api.IGuiHelper;
import mezz.jei.api.gui.IDrawable;
import mezz.jei.api.gui.IGuiItemStackGroup;
import mezz.jei.api.gui.IRecipeLayout;
import mezz.jei.api.ingredients.IIngredients;
import mezz.jei.api.recipe.IRecipeCategory;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.List;

public class DirtCubeCraftingCategory implements IRecipeCategory<DirtCubeCraftingWrapper> {

    public static final String UID = Tags.MODID + ".dirt_cube_crafting";
    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation(Tags.MODID, "textures/gui/jei_dirt_cube_crafting.png"); // TODO: Create this texture

    private final IDrawable background;
    private final IDrawable icon;
    private final String title;
    private final IDrawable energyBarEmpty; // Empty energy bar
    private final IDrawable progressArrowEmpty; // Empty progress arrow

    // Slot positions (example values, adjust based on GUI texture)
    private static final int INPUT_SLOT_X = 20;
    private static final int INPUT_SLOT_Y = 25;
    private static final int OUTPUT_SLOT_X = 100;
    private static final int OUTPUT_SLOT_Y = 25;
    private static final int ENERGY_BAR_X = 5;
    private static final int ENERGY_BAR_Y = 5;
    private static final int ENERGY_BAR_WIDTH = 10;
    private static final int ENERGY_BAR_HEIGHT = 50;
    private static final int ARROW_X = 60;
    private static final int ARROW_Y = 26;
    private static final int ARROW_WIDTH = 24;
    private static final int ARROW_HEIGHT = 17;


    public DirtCubeCraftingCategory(IGuiHelper guiHelper) {
        // Background size needs to accommodate slots, energy bar, arrow, text
        int width = 140;
        int height = 60;
        // Use a texture slice for the background
        this.background = guiHelper.createDrawable(GUI_TEXTURE, 0, 0, width, height);
        // Use the controller block as the icon
        // TODO: Ensure ModBlocks.DIRT_CUBE_CONTROLLER is correctly registered and accessible
        // this.icon = guiHelper.createDrawableIngredient(new ItemStack(ModBlocks.DIRT_CUBE_CONTROLLER));
        this.icon = guiHelper.createBlankDrawable(16, 16); // Placeholder icon

        this.title = I18n.format("jei." + UID + ".title"); // Requires lang entry: "Dirt Cube Crafting"

        // Create drawables for energy bar and progress arrow (empty states)
        this.energyBarEmpty = guiHelper.createDrawable(GUI_TEXTURE, 140, 0, ENERGY_BAR_WIDTH, ENERGY_BAR_HEIGHT); // Position in texture file
        this.progressArrowEmpty = guiHelper.createDrawable(GUI_TEXTURE, 140, 50, ARROW_WIDTH, ARROW_HEIGHT); // Position in texture file
    }

    @Nonnull
    @Override
    public String getUid() {
        return UID;
    }

    @Nonnull
    @Override
    public String getTitle() {
        return title;
    }

    @Nonnull
    @Override
    public String getModName() {
        return Tags.MODNAME;
    }

    @Nonnull
    @Override
    public IDrawable getBackground() {
        return background;
    }

    @Nullable
    @Override
    public IDrawable getIcon() {
        return icon;
    }

    @Override
    public void setRecipe(@Nonnull IRecipeLayout recipeLayout, @Nonnull DirtCubeCraftingWrapper recipeWrapper, @Nonnull IIngredients ingredients) {
        IGuiItemStackGroup guiItemStacks = recipeLayout.getItemStacks();

        // Initialize slots
        // Inputs (handle multiple inputs, maybe arrange in a grid?)
        // For simplicity, assuming max 3 inputs for now, matching controller inventory
        List<List<ItemStack>> inputs = ingredients.getInputs(ItemStack.class);
        for (int i = 0; i < inputs.size(); i++) {
            // Adjust positions if more than one input slot is needed
            guiItemStacks.init(i, true, INPUT_SLOT_X + (i % 2 * 18), INPUT_SLOT_Y + (i / 2 * 18));
            guiItemStacks.set(i, inputs.get(i));
        }

        // Output
        guiItemStacks.init(inputs.size(), false, OUTPUT_SLOT_X, OUTPUT_SLOT_Y);
        guiItemStacks.set(inputs.size(), ingredients.getOutputs(ItemStack.class).get(0));

        // TODO: Add handling for energy display (maybe via tooltip or drawn text)
    }

    @Override
    public void drawExtras(@Nonnull Minecraft minecraft) {
        // Draw static elements like the empty progress arrow and energy bar background
        progressArrowEmpty.draw(minecraft, ARROW_X, ARROW_Y);
        energyBarEmpty.draw(minecraft, ENERGY_BAR_X, ENERGY_BAR_Y);
    }
}

