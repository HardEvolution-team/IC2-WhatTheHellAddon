package com.ded.icwth.integration.jei;

import com.ded.icwth.api.multiblock.MultiblockDefinition;
import com.ded.icwth.api.multiblock.MultiblockRegistry;
import com.ded.icwth.integration.jei.dirtcube.DirtCubeCraftingCategory;
import com.ded.icwth.integration.jei.dirtcube.DirtCubeCraftingWrapper;
import com.ded.icwth.recipes.dirtcube.DirtCubeRecipe;
import com.ded.icwth.recipes.dirtcube.DirtCubeRecipeRegistry;
import mezz.jei.api.*;
import mezz.jei.api.ingredients.IIngredientRegistry;
import mezz.jei.api.recipe.IRecipeCategoryRegistration;
import net.minecraft.item.ItemStack;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@JEIPlugin
public class IC2WTHJeiPlugin implements IModPlugin {

    private static final Logger LOGGER = LogManager.getLogger("IC2WTH-JEI");
    public static IJeiRuntime jeiRuntime;

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        LOGGER.info("Registering JEI categories for IC2WTH");
        IGuiHelper guiHelper = registration.getJeiHelpers().getGuiHelper();

        // Register Multiblock Structure Category
        registration.addRecipeCategories(new MultiblockStructureCategory(guiHelper));

        // Register Dirt Cube Crafting Category
        registration.addRecipeCategories(new DirtCubeCraftingCategory(guiHelper));
    }

    @Override
    public void register(IModRegistry registry) {
        LOGGER.info("Registering JEI recipes and catalysts for IC2WTH");
        IIngredientRegistry ingredientRegistry = registry.getIngredientRegistry();
        IGuiHelper guiHelper = registry.getJeiHelpers().getGuiHelper();

        // --- Multiblock Structures ---
        List<MultiblockStructureWrapper> structureWrappers = MultiblockRegistry.getAllDefinitions().stream()
                .map(def -> new MultiblockStructureWrapper(def))
                .collect(Collectors.toList());

        if (!structureWrappers.isEmpty()) {
            registry.addRecipes(structureWrappers, MultiblockStructureCategory.UID);
            LOGGER.info("Registered {} multiblock structure recipes with JEI.", structureWrappers.size());
        } else {
            LOGGER.warn("No multiblock definitions found to register with JEI.");
        }

        // Register Structure Catalysts
        for (MultiblockDefinition definition : MultiblockRegistry.getAllDefinitions()) {
            ItemStack controllerStack = definition.getControllerStack();
            if (!controllerStack.isEmpty()) {
                registry.addRecipeCatalyst(controllerStack, MultiblockStructureCategory.UID);
            } else {
                LOGGER.warn("Could not register JEI catalyst for multiblock {} as controller stack is empty.", definition.getUniqueId());
            }
        }

        // --- Dirt Cube Crafting Recipes ---
        // Ensure recipes are registered before accessing them
        DirtCubeRecipeRegistry.registerRecipes(); // Call registration here or ensure it's called earlier

        List<DirtCubeRecipe> dirtCubeRecipes = DirtCubeRecipeRegistry.getRecipes();
        List<DirtCubeCraftingWrapper> craftingWrappers = dirtCubeRecipes.stream()
                .map(recipe -> new DirtCubeCraftingWrapper(recipe, guiHelper))
                .collect(Collectors.toList());

        if (!craftingWrappers.isEmpty()) {
            registry.addRecipes(craftingWrappers, DirtCubeCraftingCategory.UID);
            LOGGER.info("Registered {} Dirt Cube crafting recipes with JEI.", craftingWrappers.size());
        } else {
            LOGGER.warn("No Dirt Cube crafting recipes found to register with JEI.");
        }

        // Register Dirt Cube Crafting Catalyst
        // TODO: Ensure ModBlocks.DIRT_CUBE_CONTROLLER is correctly registered and accessible
        // ItemStack dirtCubeControllerStack = new ItemStack(ModBlocks.DIRT_CUBE_CONTROLLER);
        // if (!dirtCubeControllerStack.isEmpty()) {
        //     registry.addRecipeCatalyst(dirtCubeControllerStack, DirtCubeCraftingCategory.UID);
        // } else {
        //     LOGGER.warn("Could not register JEI catalyst for Dirt Cube Crafting as controller stack is empty or block not found.");
        // }

        // Potentially add information tabs for blocks/items here if needed
    }

    @Override
    public void onRuntimeAvailable(@Nonnull IJeiRuntime jeiRuntime) {
        IC2WTHJeiPlugin.jeiRuntime = jeiRuntime;
        LOGGER.info("JEI Runtime available.");
        // Could perform actions requiring the runtime here, like hiding items
    }
}

