package com.ded.icwth.integration.jei.dirtcube;

import com.ded.icwth.recipes.dirtcube.DirtCubeRecipe;
import mezz.jei.api.IGuiHelper;
import mezz.jei.api.gui.IDrawableAnimated;
import mezz.jei.api.gui.IDrawableStatic;
import mezz.jei.api.ingredients.IIngredients;
import mezz.jei.api.recipe.IRecipeWrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class DirtCubeCraftingWrapper implements IRecipeWrapper {

    private final DirtCubeRecipe recipe;
    private final IDrawableAnimated progressArrow;
    private final IDrawableAnimated energyBar;
    private final String energyTooltip;
    private final String durationTooltip;

    // Texture location from Category
    private static final ResourceLocation GUI_TEXTURE = new ResourceLocation(com.ded.icwth.Tags.MODID, "textures/gui/jei_dirt_cube_crafting.png");

    // Positions and dimensions from Category (or constants file)
    private static final int ENERGY_BAR_X = 5;
    private static final int ENERGY_BAR_Y = 5;
    private static final int ENERGY_BAR_WIDTH = 10;
    private static final int ENERGY_BAR_HEIGHT = 50;
    private static final int ARROW_X = 60;
    private static final int ARROW_Y = 26;
    private static final int ARROW_WIDTH = 24;
    private static final int ARROW_HEIGHT = 17;

    // Texture coordinates for filled parts
    private static final int ENERGY_BAR_FULL_U = 150; // Example U coord for filled energy bar
    private static final int ENERGY_BAR_FULL_V = 0;  // Example V coord for filled energy bar
    private static final int ARROW_FULL_U = 150; // Example U coord for filled arrow
    private static final int ARROW_FULL_V = 50; // Example V coord for filled arrow

    public DirtCubeCraftingWrapper(DirtCubeRecipe recipe, IGuiHelper guiHelper) {
        this.recipe = recipe;

        // Create animated drawables
        IDrawableStatic energyBarFull = guiHelper.createDrawable(GUI_TEXTURE, ENERGY_BAR_FULL_U, ENERGY_BAR_FULL_V, ENERGY_BAR_WIDTH, ENERGY_BAR_HEIGHT);
        // Duration for energy bar animation can be constant or linked to recipe duration
        this.energyBar = guiHelper.createAnimatedDrawable(energyBarFull, 200, IDrawableAnimated.StartDirection.BOTTOM, false);

        IDrawableStatic progressArrowFull = guiHelper.createDrawable(GUI_TEXTURE, ARROW_FULL_U, ARROW_FULL_V, ARROW_WIDTH, ARROW_HEIGHT);
        this.progressArrow = guiHelper.createAnimatedDrawable(progressArrowFull, recipe.getDurationTicks(), IDrawableAnimated.StartDirection.LEFT, false);

        // Pre-calculate tooltips
        this.energyTooltip = TextFormatting.GRAY + I18n.format("jei.ic2wth.dirt_cube_crafting.tooltip.energy", String.format("%,.0f", recipe.getEnergyCostTotal()));
        this.durationTooltip = TextFormatting.GRAY + I18n.format("jei.ic2wth.dirt_cube_crafting.tooltip.duration", recipe.getDurationTicks() / 20.0);
    }

    @Override
    public void getIngredients(@Nonnull IIngredients ingredients) {
        // Convert List<Ingredient> to List<List<ItemStack>> for JEI
        List<List<ItemStack>> inputLists = new ArrayList<>();
        for (Ingredient ing : recipe.getInputs()) {
            inputLists.add(java.util.Arrays.asList(ing.getMatchingStacks()));
        }
        ingredients.setInputLists(ItemStack.class, inputLists);
        ingredients.setOutput(ItemStack.class, recipe.getOutput());
    }

    @Override
    public void drawInfo(@Nonnull Minecraft minecraft, int recipeWidth, int recipeHeight, int mouseX, int mouseY) {
        // Draw the animated progress arrow and energy bar
        energyBar.draw(minecraft, ENERGY_BAR_X, ENERGY_BAR_Y);
        progressArrow.draw(minecraft, ARROW_X, ARROW_Y);

        // Draw energy cost and duration text (optional, can rely on tooltips)
        // String energyText = String.format("%,.0f EU", recipe.getEnergyCostTotal());
        // minecraft.fontRenderer.drawString(energyText, ..., ..., 0x404040);
        // String timeText = String.format("%.1f s", recipe.getDurationTicks() / 20.0);
        // minecraft.fontRenderer.drawString(timeText, ..., ..., 0x404040);
    }

    @Nonnull
    @Override
    public List<String> getTooltipStrings(int mouseX, int mouseY) {
        // Tooltip for energy bar
        if (mouseX >= ENERGY_BAR_X && mouseX < ENERGY_BAR_X + ENERGY_BAR_WIDTH && mouseY >= ENERGY_BAR_Y && mouseY < ENERGY_BAR_Y + ENERGY_BAR_HEIGHT) {
            return Collections.singletonList(energyTooltip);
        }
        // Tooltip for progress arrow
        if (mouseX >= ARROW_X && mouseX < ARROW_X + ARROW_WIDTH && mouseY >= ARROW_Y && mouseY < ARROW_Y + ARROW_HEIGHT) {
            return Collections.singletonList(durationTooltip);
        }
        return Collections.emptyList();
    }
}

