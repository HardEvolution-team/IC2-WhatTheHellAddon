package com.ded.icwth.integration.jei;


import com.ded.icwth.Tags;
import com.ded.icwth.api.multiblock.MultiblockDefinition;
import mezz.jei.api.IGuiHelper;
import mezz.jei.api.gui.IDrawable;
import mezz.jei.api.gui.IRecipeLayout;
import mezz.jei.api.ingredients.IIngredients;
import mezz.jei.api.recipe.IRecipeCategory;
import mezz.jei.api.recipe.IRecipeWrapper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

public class MultiblockStructureCategory implements IRecipeCategory<MultiblockStructureWrapper> {

    public static final String UID = Tags.MODID + ".multiblock_structure";
    private static final Logger LOGGER = LogManager.getLogger("IC2WTH-JEI-Category");

    private final IDrawable background;
    private final IDrawable icon; // Optional: Use controller block icon?
    private final String title;

    public MultiblockStructureCategory(IGuiHelper guiHelper) {
        // Define the background size. This needs to be large enough for the 3D preview.
        // Dimensions might need adjustment based on the renderer design.
        int width = 160;
        int height = 120;
        // Use a blank background or a custom texture
        this.background = guiHelper.createBlankDrawable(width, height);
        // TODO: Create a proper icon, maybe from a representative block or item
        this.icon = guiHelper.createBlankDrawable(16, 16);
        this.title = I18n.format("jei." + UID + ".title"); // Requires lang entry
    }

    @Nonnull
    @Override
    public String getUid() {
        return UID;
    }

    @Nonnull
    @Override
    public String getTitle() {
        return this.title;
    }

    @Nonnull
    @Override
    public String getModName() {
        return Tags.MODNAME; // Assumes IC2WTH.NAME holds the mod name
    }

    @Nonnull
    @Override
    public IDrawable getBackground() {
        return this.background;
    }

    @Nullable
    @Override
    public IDrawable getIcon() {
        return this.icon;
    }

    @Override
    public void setRecipe(@Nonnull IRecipeLayout recipeLayout, @Nonnull MultiblockStructureWrapper recipeWrapper, @Nonnull IIngredients ingredients) {
        LOGGER.debug("Setting recipe layout for multiblock: {}", recipeWrapper.getDefinition().getUniqueId());
        // Set up the controller item stack display
        // The position (e.g., 0, 0) needs adjustment based on desired layout
        recipeLayout.getItemStacks().init(0, true, 0, 0);
        recipeLayout.getItemStacks().set(ingredients);

        // The actual 3D rendering will be handled within the wrapper's drawInfo method,
        // potentially using a custom drawable managed here or within the wrapper itself.
        // No standard ingredient slots are needed for the structure itself.
    }
}

