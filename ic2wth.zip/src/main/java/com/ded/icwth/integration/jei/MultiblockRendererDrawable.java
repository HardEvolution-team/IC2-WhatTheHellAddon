package com.ded.icwth.integration.jei;

import com.ded.icwth.api.multiblock.MultiblockDefinition;
import com.ded.icwth.api.multiblock.StructurePart;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.vertex.VertexBuffer;
import net.minecraft.client.renderer.vertex.VertexFormat;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.model.obj.OBJLoader;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import javax.annotation.Nonnull;

/**
 * Handles the 3D rendering of a multiblock structure within a JEI recipe category.
 */
public class MultiblockRendererDrawable {

    private final MultiblockDefinition definition;

    // Rendering State
    private float rotationX = 20.0f;
    private float rotationY = -45.0f;
    private float zoom = 1.0f; // Keep base zoom at 1.0 for mouse wheel logic
    private float targetZoom = 1.0f;

    // Mouse Drag State
    private boolean isDragging = false;
    private int lastMouseX = 0;
    private int lastMouseY = 0;

    // VBO for rendering optimization
    private VertexBuffer structureVbo;
    private final VertexFormat vertexFormat = DefaultVertexFormats.BLOCK;
    private boolean vboNeedsRebuild = true;
    // Removed structureSize calculation as it's no longer needed for centering
    // private BlockPos structureSize = BlockPos.ORIGIN;

    public MultiblockRendererDrawable(@Nonnull MultiblockDefinition definition) {
        this.definition = definition;
        // No need to calculate structureSize for centering anymore
        this.vboNeedsRebuild = true;
    }

    private void compileStructure() {
        if (this.structureVbo == null) {
            this.structureVbo = new VertexBuffer(this.vertexFormat);
        }

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(GL11.GL_QUADS, this.vertexFormat);

        Minecraft mc = Minecraft.getMinecraft();
        BlockRendererDispatcher blockRenderer = mc.getBlockRendererDispatcher();

        for (StructurePart part : definition.getParts()) {
            IBlockState state = part.getBlockState();
            BlockPos pos = part.getRelativePos(); // Position relative to controller (assumed 0,0,0)
            bufferBuilder.setTranslation(pos.getX(), pos.getY(), pos.getZ());
            try {
                for (BlockRenderLayer layer : BlockRenderLayer.values()) {
                    if (state.getBlock().canRenderInLayer(state, layer)) {
                        ForgeHooksClient.setRenderLayer(layer);
                        IBakedModel model = blockRenderer.getModelForState(state);
                        blockRenderer.getBlockModelRenderer().renderModel(mc.world, model, state, pos, bufferBuilder, false);
                    }
                }
                ForgeHooksClient.setRenderLayer(null);
            } catch (Exception e) {
                System.err.println("Error rendering block " + state + " at " + pos + ": " + e.getMessage());
            }
        }

        bufferBuilder.setTranslation(0, 0, 0);
        bufferBuilder.finishDrawing();
        this.structureVbo.bufferData(bufferBuilder.getByteBuffer());
        this.vboNeedsRebuild = false;
    }

    public void draw(@Nonnull Minecraft minecraft, int x, int y, int width, int height, int mouseX, int mouseY) {
        handleMouseInput(x, y, width, height, mouseX, mouseY);

        if (vboNeedsRebuild) {
            compileStructure();
        }

        // Calculate scale based on *some* dimension, maybe max distance from controller?
        // For now, let's use a fixed base scale factor combined with zoom.
        // This might need adjustment depending on structure size.
        float baseScaleFactor = 10.0f; // Adjust this value to control initial size
        float scale = baseScaleFactor * zoom;

        GlStateManager.pushMatrix();
        GlStateManager.enableDepth();
        GlStateManager.enableRescaleNormal();
        RenderHelper.enableGUIStandardItemLighting();

        // Center the drawing area and move camera back
        GlStateManager.translate(x + width / 2.0f, y + height / 2.0f, 150.0f); // Keep Z at 150 for now
        GlStateManager.scale(scale, -scale, scale);

        GlStateManager.rotate(rotationX, 1.0f, 0.0f, 0.0f);
        GlStateManager.rotate(rotationY, 0.0f, 1.0f, 0.0f);

        // Removed the translation that centered the bounding box.
        // Rotation and scaling now happen around the origin (0,0,0),
        // which should be the controller's position.
        // GlStateManager.translate(-structureSize.getX() / 2.0f, -structureSize.getY() / 2.0f, -structureSize.getZ() / 2.0f);

        if (this.structureVbo != null) {
            minecraft.getTextureManager().bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
            ForgeHooksClient.setRenderLayer(BlockRenderLayer.SOLID);
            this.structureVbo.bindBuffer();
            setupVertexAttributes();
            this.structureVbo.drawArrays(GL11.GL_QUADS);
            this.structureVbo.unbindBuffer();
            GlStateManager.resetColor();
            ForgeHooksClient.setRenderLayer(null);
        }

        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.disableDepth();
        GlStateManager.popMatrix();
    }

    private void setupVertexAttributes() {
        GlStateManager.glVertexPointer(3, GL11.GL_FLOAT, 28, 0);
        GlStateManager.glColorPointer(4, GL11.GL_UNSIGNED_BYTE, 28, 12);
        GlStateManager.glTexCoordPointer(2, GL11.GL_FLOAT, 28, 16);
        OpenGlHelper.setClientActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.glTexCoordPointer(2, GL11.GL_SHORT, 28, 24);
        OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
        GlStateManager.glEnableClientState(GL11.GL_VERTEX_ARRAY);
        GlStateManager.glEnableClientState(GL11.GL_COLOR_ARRAY);
        GlStateManager.glEnableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
        OpenGlHelper.setClientActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.glEnableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
        OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
    }

    private void handleMouseInput(int x, int y, int width, int height, int mouseX, int mouseY) {
        boolean isHovering = mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;

        if (isHovering) {
            int dWheel = Mouse.getDWheel();
            if (dWheel != 0) {
                targetZoom *= (dWheel > 0) ? 1.1f : (1.0f / 1.1f);
                // Adjusted zoom limits slightly, might need further tuning
                targetZoom = Math.max(0.05f, Math.min(targetZoom, 10.0f));
            }
        }
        zoom += (targetZoom - zoom) * 0.1f;

        if (isHovering && Mouse.isButtonDown(0)) {
            if (!isDragging) {
                isDragging = true;
            } else {
                float dx = mouseX - lastMouseX;
                float dy = mouseY - lastMouseY;
                rotationY += dx * 0.5f;
                rotationX -= dy * 0.5f;
                rotationX = Math.max(-89.0f, Math.min(89.0f, rotationX));
            }
            lastMouseX = mouseX;
            lastMouseY = mouseY;
        } else {
            isDragging = false;
        }
    }

    public void dispose() {
        if (this.structureVbo != null) {
            this.structureVbo.deleteGlBuffers();
            this.structureVbo = null;
        }
        this.vboNeedsRebuild = true;
    }
}

