package com.ded.icwth.blocks;

import com.ded.icwth.Tags;
// Import existing blocks
import com.ded.icwth.blocks.panels.ChinaSolar.BlockChinaSolarPanel;
import com.ded.icwth.blocks.trash.BlockEnergyTrashCan;
// Import NEW port blocks
import com.ded.icwth.blocks.ports.BlockEnergyInputPort;
import com.ded.icwth.blocks.ports.BlockFluidInputPort;
import com.ded.icwth.blocks.ports.BlockFluidOutputPort;
import com.ded.icwth.blocks.ports.BlockItemInputPort;
import com.ded.icwth.blocks.ports.BlockItemOutputPort;
// Import NEW port Tile Entities for registration
import com.ded.icwth.multiblocks.parts.ports.TileEntityEnergyInputPort;
import com.ded.icwth.multiblocks.parts.ports.TileEntityFluidInputPort;
import com.ded.icwth.multiblocks.parts.ports.TileEntityFluidOutputPort;
import com.ded.icwth.multiblocks.parts.ports.TileEntityItemInputPort;
import com.ded.icwth.multiblocks.parts.ports.TileEntityItemOutputPort;

import ic2.core.IC2;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

public class ModBlocks {

    // Existing Blocks
    public static Block EnergyTrash;
    public static Block ChinaSolar;

    // --- NEW Multiblock Port Blocks ---
    public static Block ITEM_INPUT_PORT;
    public static Block ITEM_OUTPUT_PORT;
    public static Block FLUID_INPUT_PORT;
    public static Block FLUID_OUTPUT_PORT;
    public static Block ENERGY_INPUT_PORT;
    // No energy output port requested

    public static void init() {
        // Existing
        EnergyTrash = new BlockEnergyTrashCan(Material.IRON).setTranslationKey("energy_trash").setCreativeTab(IC2.tabIC2);
        ChinaSolar = new BlockChinaSolarPanel(Material.IRON).setTranslationKey("china_solar").setCreativeTab(IC2.tabIC2);

        // --- NEW Multiblock Port Blocks ---
        ITEM_INPUT_PORT = new BlockItemInputPort().setTranslationKey("item_input_port").setCreativeTab(IC2.tabIC2);
        ITEM_OUTPUT_PORT = new BlockItemOutputPort().setTranslationKey("item_output_port").setCreativeTab(IC2.tabIC2);
        FLUID_INPUT_PORT = new BlockFluidInputPort().setTranslationKey("fluid_input_port").setCreativeTab(IC2.tabIC2);
        FLUID_OUTPUT_PORT = new BlockFluidOutputPort().setTranslationKey("fluid_output_port").setCreativeTab(IC2.tabIC2);
        ENERGY_INPUT_PORT = new BlockEnergyInputPort().setTranslationKey("energy_input_port").setCreativeTab(IC2.tabIC2);
    }

    public static void InGameRegister() {
        // Existing
        registerBlock(EnergyTrash, "energy_trash");
        registerBlock(ChinaSolar, "china_solar");

        // --- NEW Multiblock Port Blocks ---
        registerBlock(ITEM_INPUT_PORT, "item_input_port");
        registerBlock(ITEM_OUTPUT_PORT, "item_output_port");
        registerBlock(FLUID_INPUT_PORT, "fluid_input_port");
        registerBlock(FLUID_OUTPUT_PORT, "fluid_output_port");
        registerBlock(ENERGY_INPUT_PORT, "energy_input_port");

        // --- Register Tile Entities ---
        // It's common practice to register TEs here or in a proxy
        // Use MODID:name format for the registry name string
        GameRegistry.registerTileEntity(TileEntityItemInputPort.class, new ResourceLocation(Tags.MODID, "tile_item_input_port"));
        GameRegistry.registerTileEntity(TileEntityItemOutputPort.class, new ResourceLocation(Tags.MODID, "tile_item_output_port"));
        GameRegistry.registerTileEntity(TileEntityFluidInputPort.class, new ResourceLocation(Tags.MODID, "tile_fluid_input_port"));
        GameRegistry.registerTileEntity(TileEntityFluidOutputPort.class, new ResourceLocation(Tags.MODID, "tile_fluid_output_port"));
        GameRegistry.registerTileEntity(TileEntityEnergyInputPort.class, new ResourceLocation(Tags.MODID, "tile_energy_input_port"));
    }

    @SideOnly(Side.CLIENT)
    public static void Render() {
        // Existing
        registerRender(EnergyTrash);
        registerRender(ChinaSolar);

        // --- NEW Multiblock Port Blocks ---
        registerRender(ITEM_INPUT_PORT);
        registerRender(ITEM_OUTPUT_PORT);
        registerRender(FLUID_INPUT_PORT);
        registerRender(FLUID_OUTPUT_PORT);
        registerRender(ENERGY_INPUT_PORT);
    }

    // --- Registration Helper Methods (Keep existing ones, ensure they work) ---
    public static Block registerBlock(Block block, String name) {
        ResourceLocation registryName = new ResourceLocation(Tags.MODID, name);
        block.setRegistryName(registryName);
        ForgeRegistries.BLOCKS.register(block);

        ItemBlock itemBlock = new ItemBlock(block);
        itemBlock.setRegistryName(registryName);
        ForgeRegistries.ITEMS.register(itemBlock);
        return block;
    }

    @SideOnly(Side.CLIENT)
    public static void registerRender(Block block) {
        Item item = Item.getItemFromBlock(block);
        if (item != Items.AIR) {
            // Use default state for inventory model
            ModelResourceLocation model = new ModelResourceLocation(block.getRegistryName(), "inventory");
            registerModel(item, model);
        } else {
            FMLLog.log.warn("Could not find Item for Block {} to register render.", block.getRegistryName());
        }
    }

    @SideOnly(Side.CLIENT)
    private static void registerModel(Item item, ModelResourceLocation model) {
        // Ensure this runs only on the client
        Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, model);
    }

    // Removed unused/complex registration methods and initModels
}

