package com.ded.icwth.blocks.ports;

import com.ded.icwth.multiblocks.parts.ports.TileEntityEnergyInputPort;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;

public class BlockEnergyInputPort extends BlockContainer {

    // No GUI needed for a simple energy input port

    public BlockEnergyInputPort() {
        super(Material.IRON);
        setHardness(5.0F);
        setResistance(10.0F);
        // setTranslationKey and setCreativeTab will be done in ModBlocks
    }

    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileEntityEnergyInputPort();
    }

    // No onBlockActivated needed unless we add configuration

    // No special break logic needed, TileEntity invalidation handles controller notification and EnergyNet removal
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        super.breakBlock(worldIn, pos, state);
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    // Assuming MODEL rendering type
    @Override
    public net.minecraft.util.EnumBlockRenderType getRenderType(IBlockState state) {
        return net.minecraft.util.EnumBlockRenderType.MODEL;
    }
}

