package com.ded.icwth.blocks.ports;

import com.ded.icwth.MyMod;
import com.ded.icwth.multiblocks.parts.ports.TileEntityItemOutputPort;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nullable;

public class BlockItemOutputPort extends BlockContainer {

    public static final int GUI_ID = 4; // Assign a new unique GUI ID

    public BlockItemOutputPort() {
        super(Material.IRON);
        setHardness(5.0F);
        setResistance(10.0F);
        // setTranslationKey and setCreativeTab will be done in ModBlocks
    }

    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileEntityItemOutputPort();
    }

    @Override
    public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (!worldIn.isRemote) {
            TileEntity tileEntity = worldIn.getTileEntity(pos);
            if (tileEntity instanceof TileEntityItemOutputPort) {
                // Open the GUI
                playerIn.openGui(MyMod.instance, GUI_ID, worldIn, pos.getX(), pos.getY(), pos.getZ());
                return true;
            }
        }
        return true; // Prevent item usage on client
    }

    // Output ports usually need to drop their buffer contents when broken
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        TileEntity tileentity = worldIn.getTileEntity(pos);
        if (tileentity instanceof TileEntityItemOutputPort) {
            ((TileEntityItemOutputPort) tileentity).dropInventory(); // Add a helper method in TE
        }
        super.breakBlock(worldIn, pos, state);
    }

    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    // Assuming MODEL rendering type
    @Override
    public net.minecraft.util.EnumBlockRenderType getRenderType(IBlockState state) {
        return net.minecraft.util.EnumBlockRenderType.MODEL;
    }
}

