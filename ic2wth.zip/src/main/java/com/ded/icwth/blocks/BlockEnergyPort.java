package com.ded.icwth.blocks; // Assuming this is the correct package

import com.ded.icwth.multiblocks.parts.TileEnergyPort;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;

import javax.annotation.Nullable;

public class BlockEnergyPort extends BlockContainer {

    public BlockEnergyPort() {
        super(Material.IRON);
        // Set other properties like hardness, resistance, sound type, etc.
        setHardness(5.0F);
        setResistance(10.0F);
    }

    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileEnergyPort(); // Return instance of the new TileEntity
    }

    // Optional: Override methods like getRenderType, onBlockActivated, etc. if needed
    // By default, BlockContainer uses TESR or invisible model. Set appropriate model/state mapping.
    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false; // Adjust if your block model is not a full cube
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false; // Adjust if your block model is not a full cube
    }

    // If not using TESR, ensure block state maps to a model
    // @Override
    // public net.minecraft.util.EnumBlockRenderType getRenderType(IBlockState state) {
    //     return net.minecraft.util.EnumBlockRenderType.MODEL;
    // }
}

