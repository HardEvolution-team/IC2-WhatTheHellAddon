package com.ded.icwth.blocks;

// Import new port classes and their GUIs/Containers
import com.ded.icwth.blocks.BlockFluidPort;
import com.ded.icwth.blocks.BlockItemPort;
import com.ded.icwth.multiblocks.parts.TileFluidPort;
import com.ded.icwth.multiblocks.parts.TileItemPort;
import com.ded.icwth.multiblocks.parts.gui.ContainerFluidPort;
import com.ded.icwth.multiblocks.parts.gui.ContainerItemPort;
import com.ded.icwth.multiblocks.parts.gui.GuiFluidPort;
import com.ded.icwth.multiblocks.parts.gui.GuiItemPort;
// Existing imports
import com.ded.icwth.blocks.hyperstorage.TileHyperStorage;
import com.ded.icwth.blocks.hyperstorage.gui.ContainerHyperStorage;
import com.ded.icwth.blocks.hyperstorage.gui.GuiHyperStorage;
import com.ded.icwth.blocks.panels.TileEntitySolarBase;
import com.ded.icwth.blocks.panels.gui.ContainerSolarBase;
import com.ded.icwth.blocks.panels.gui.GuiSolarBase;
import com.ded.icwth.blocks.batbox.TileMFSUBase;
import com.ded.icwth.blocks.batbox.gui.ContainerMFSUBase;
import com.ded.icwth.blocks.batbox.gui.GuiMFSUBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

public class CommonGuiHandler implements IGuiHandler {
    @Override
    public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        BlockPos pos = new BlockPos(x, y, z);
        TileEntity te = world.getTileEntity(pos);
        System.out.println("[Common GUI Handler] Server side GUI requested for ID: " + ID + " at " + pos);

        if (te instanceof TileEntitySolarBase) {
            System.out.println("Creating ContainerSolarBase for SolarPanel");
            return new ContainerSolarBase(player.inventory, (TileEntitySolarBase) te);
        } else if (te instanceof TileHyperStorage) {
            System.out.println("Creating ContainerHyperStorage for HyperStorage");
            return new ContainerHyperStorage(player.inventory, (TileHyperStorage) te);
        } else if (te instanceof TileMFSUBase) {
            System.out.println("Creating ContainerMFSUBase for MFSU");
            return new ContainerMFSUBase(player.inventory, (TileMFSUBase) te);
        } else if (te instanceof TileItemPort && ID == BlockItemPort.GUI_ID) { // Check for Item Port
            System.out.println("Creating ContainerItemPort for Item Port");
            return new ContainerItemPort(player.inventory, (TileItemPort) te);
        } else if (te instanceof TileFluidPort && ID == BlockFluidPort.GUI_ID) { // Check for Fluid Port
            System.out.println("Creating ContainerFluidPort for Fluid Port");
            return new ContainerFluidPort(player.inventory, (TileFluidPort) te);
        }
        System.out.println("No valid TileEntity or matching GUI ID found for ID: " + ID);
        return null;
    }

    @Override
    public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
        BlockPos pos = new BlockPos(x, y, z);
        TileEntity te = world.getTileEntity(pos);
        System.out.println("[Common GUI Handler] Client side GUI requested for ID: " + ID + " at " + pos);

        if (te instanceof TileEntitySolarBase) {
            System.out.println("Creating GuiSolarBase for SolarPanel");
            TileEntitySolarBase tile = (TileEntitySolarBase) te;
            return new GuiSolarBase(new ContainerSolarBase(player.inventory, tile), tile);
        } else if (te instanceof TileHyperStorage) {
            System.out.println("Creating GuiHyperStorage for HyperStorage");
            TileHyperStorage tile = (TileHyperStorage) te;
            return new GuiHyperStorage(new ContainerHyperStorage(player.inventory, tile), tile);
        } else if (te instanceof TileMFSUBase) {
            System.out.println("Creating GuiMFSUBase for MFSU");
            TileMFSUBase tile = (TileMFSUBase) te;
            return new GuiMFSUBase(new ContainerMFSUBase(player.inventory, tile), tile);
        } else if (te instanceof TileItemPort && ID == BlockItemPort.GUI_ID) { // Check for Item Port
            System.out.println("Creating GuiItemPort for Item Port");
            TileItemPort tile = (TileItemPort) te;
            return new GuiItemPort(player.inventory, tile);
        } else if (te instanceof TileFluidPort && ID == BlockFluidPort.GUI_ID) { // Check for Fluid Port
            System.out.println("Creating GuiFluidPort for Fluid Port");
            TileFluidPort tile = (TileFluidPort) te;
            return new GuiFluidPort(player.inventory, tile);
        }
        System.out.println("No valid TileEntity or matching GUI ID found for ID: " + ID);
        return null;
    }
}

