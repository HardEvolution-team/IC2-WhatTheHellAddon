package com.ded.icwth.blocks; // Assuming this is the correct package

import com.ded.icwth.MyMod; // Assuming MyMod has MODID and instance
import com.ded.icwth.multiblocks.parts.TileFluidPort;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fluids.FluidUtil;

import javax.annotation.Nullable;

public class BlockFluidPort extends BlockContainer {

    public static final int GUI_ID = 2; // Assign a unique GUI ID for this block

    public BlockFluidPort() {
        super(Material.IRON);
        setHardness(5.0F);
        setResistance(10.0F);
        // setTranslationKey and setCreativeTab should be done in ModBlocks
    }

    @Nullable
    @Override
    public TileEntity createNewTileEntity(World worldIn, int meta) {
        return new TileFluidPort();
    }

    @Override
    public boolean onBlockActivated(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
        if (!worldIn.isRemote) {
            TileEntity tileEntity = worldIn.getTileEntity(pos);
            if (tileEntity instanceof TileFluidPort) {
                // Try fluid interaction first (e.g., with buckets)
                boolean interacted = FluidUtil.interactWithFluidHandler(playerIn, hand, worldIn, pos, facing);
                if (interacted) {
                    return true; // Fluid interaction successful
                }
                // If no fluid interaction, open the GUI
                playerIn.openGui(MyMod.instance, GUI_ID, worldIn, pos.getX(), pos.getY(), pos.getZ());
                return true;
            }
        }
        return true; // Return true even on client
    }

    // Corrected breakBlock: No need to manually call anything on the TileEntity here.
    // The TileEntity's invalidate() method is called automatically by Minecraft,
    // and we placed the controller notification logic there.
    @Override
    public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
        // TileEntity invalidation and controller notification is handled in TileFluidPort.invalidate()
        super.breakBlock(worldIn, pos, state); // Just call super
    }

    // --- Standard BlockContainer settings ---
    @Override
    public boolean isOpaqueCube(IBlockState state) {
        return false;
    }

    @Override
    public boolean isFullCube(IBlockState state) {
        return false;
    }

    // If not using TESR, ensure block state maps to a model
    // @Override
    // public net.minecraft.util.EnumBlockRenderType getRenderType(IBlockState state) {
    //     return net.minecraft.util.EnumBlockRenderType.MODEL;
    // }
}

